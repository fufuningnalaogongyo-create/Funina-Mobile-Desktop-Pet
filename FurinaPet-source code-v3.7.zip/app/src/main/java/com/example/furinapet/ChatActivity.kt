package com.example.furinapet

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** 和芙宁娜聊天：本地模型生成回答，人设随好感度/饱食度变化；可选联网搜索。 */
open class ChatActivity : Activity() {

    /** 工作模式（WorkActivity 会改成 true）：独立的聊天记录、独立的记忆分区、严谨的回答风格 */
    protected open val workMode: Boolean get() = false

    private val memScope: String get() = if (workMode) AiMemory.WORK else AiMemory.CHAT
    @Volatile
    private var lastHits: List<WebSearch.Hit>? = null

    private lateinit var prefs: SharedPreferences
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var statusText: TextView
    private lateinit var pageHost: PageHost

    private val history = ArrayList<LocalAi.Turn>()
    private var generating = false
    private var awaiting = false
    private var lastHadExtra = false
    private var ready = false
    private var loadError: String? = null
    private var lastPartial = ""
    private var pendingUser: String? = null
    private var pendingUserBubble: TextView? = null
    private var currentBot: TextView? = null
    private var lastPersist = 0L

    private val cGold = 0xFFE5C26B.toInt()
    private val cText = 0xFFEAF1FF.toInt()
    private val cSub = 0xFF9FB0DC.toInt()
    private val cNavy = 0xFF0B1230.toInt()
    private val cBot = 0xFF1B2A66.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
        return d
    }

    // 记下最近点击的位置，弹窗会从这里弹出来
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Ui.noteTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    // 关闭时的页面动画
    override fun finish() {
        super.finish()
        Ui.closeTransition(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        Assistant.memoryScope = memScope
        Bond.ensureInit(prefs)
        buildUi()

        history.addAll(ChatStore.load(this, memScope))
        for (t in history) {
            val b = addBubble(t.text, t.fromUser, t)
            if (!t.fromUser) addAiTag(b)
        }
        if (history.isEmpty()) {
            addNote("轻轻戳一下输入框，跟她说点什么吧。她的语气会随着好感度和饱食度变化。")
        }

        if (!LocalAi.hasModel(this)) {
            addNote("还没有模型。点上面的状态栏可以下载默认模型（约 2.6GB，需要联网下载一次）。")
            updateStatus()
            updateInputState()
            promptDownload()
        } else {
            startLoad()
        }
    }

    /** 把「已有记录 + 正在进行的这一轮（含生成到一半的回复）」写到存档里 */
    private fun persistPending() {
        val u = pendingUser ?: return
        val list = ArrayList<LocalAi.Turn>(history)
        list.add(LocalAi.Turn(true, u))
        val part = lastPartial.trim()
        if (generating && part.isNotEmpty()) list.add(LocalAi.Turn(false, part + ChatStore.INTERRUPTED))
        ChatStore.save(this, list, memScope)
        lastPersist = System.currentTimeMillis()
    }

    private fun persistThrottled() {
        if (System.currentTimeMillis() - lastPersist > 2000L) persistPending()
    }

    // 退到后台时先存一次：后台东西多了被系统清掉进程，是最容易丢记录的时候
    override fun onPause() {
        Speaker.stop()
        persistPending()
        pageHost.pauseVideo()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        Assistant.memoryScope = memScope
        pageHost.resumeVideo()
    }

    override fun onStop() {
        persistPending()
        super.onStop()
    }

    override fun onDestroy() {
        Speaker.stop()
        pageHost.release()
        // 模型很占内存，离开聊天就释放；如果正在生成，会等生成结束后再释放
        Thread { LocalAi.release() }.start()
        super.onDestroy()
    }

    // ------------------------------------------------------------ 界面

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(16), dp(14), dp(10))

        // 顶栏
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = if (workMode) "工作模式" else "和芙宁娜聊天"
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        title.setTextColor(if (workMode) 0xFF8FD3FF.toInt() else cGold)
        title.typeface = Typeface.DEFAULT_BOLD
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clear = TextView(this)
        clear.text = "清空"
        clear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        clear.setTextColor(cSub)
        clear.setPadding(dp(10), dp(6), dp(10), dp(6))
        clear.setOnClickListener { confirmClear() }
        val ttsBtn = TextView(this)
        fun ttsLabel(): String = "朗读：" + (if (prefs.getBoolean(Prefs.AI_TTS, false)) "开" else "关")
        ttsBtn.text = ttsLabel()
        ttsBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        ttsBtn.setTextColor(cSub)
        ttsBtn.setPadding(dp(10), dp(6), dp(10), dp(6))
        ttsBtn.setOnClickListener {
            val on = !prefs.getBoolean(Prefs.AI_TTS, false)
            prefs.edit().putBoolean(Prefs.AI_TTS, on).apply()
            if (!on) Speaker.stop()
            ttsBtn.text = ttsLabel()
            Toast.makeText(
                this,
                if (on) "之后她的每条回复会自动朗读（括号里的动作不会读）" else "已关闭自动朗读",
                Toast.LENGTH_SHORT
            ).show()
        }
        Ui.press(ttsBtn)
        top.addView(ttsBtn)
        val mem = TextView(this)
        mem.text = "记忆"
        mem.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        mem.setTextColor(cGold)
        mem.setPadding(dp(10), dp(6), dp(10), dp(6))
        mem.setOnClickListener {
            val i = Intent(this, MemoryActivity::class.java)
            i.putExtra("scope", memScope)
            startActivity(i, Ui.pageOptions(this))
        }
        Ui.press(mem)
        if (!workMode) {
            val work = TextView(this)
            work.text = "工作模式"
            work.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            work.setTextColor(0xFF8FD3FF.toInt())
            work.setPadding(dp(10), dp(6), dp(10), dp(6))
            work.setOnClickListener {
                startActivity(Intent(this, WorkActivity::class.java), Ui.pageOptions(this))
            }
            Ui.press(work)
            top.addView(work)
        }
        top.addView(mem)
        Ui.press(clear)
        top.addView(clear)
        root.addView(top)

        statusText = TextView(this)
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        statusText.setTextColor(cSub)
        statusText.setPadding(0, dp(4), 0, dp(2))
        statusText.setOnClickListener {
            if (!LocalAi.hasModel(this)) {
                promptDownload()
            } else if (generating) {
                Toast.makeText(this, "她正在回答，等回答完再切换模型", Toast.LENGTH_SHORT).show()
            } else {
                // 切换 / 删除 / 下载模型；换了模型就重新加载
                ModelManager.show(this) { onModelChanged() }
            }
        }
        root.addView(statusText)

        val sw = Switch(this)
        sw.text = if (workMode) "联网查资料（推荐开启：回答依据搜索结果并附上来源）" else "联网搜索（需要网络，搜索引擎在设置里选）"
        sw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        sw.setTextColor(cText)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cGold, 0xFF8C98C0.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x66E5C26B, 0x44FFFFFF))
        val searchKey = if (workMode) Prefs.AI_WORK_SEARCH else Prefs.AI_SEARCH
        sw.isChecked = prefs.getBoolean(searchKey, workMode)
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(searchKey, checked).apply() }
        sw.setPadding(0, dp(6), 0, dp(6))
        root.addView(sw)

        // 深度思考：只对 DeepSeek 有效。开：先想后答，更准但很慢；关：直接回答，尽量快
        val dsw = Switch(this)
        dsw.text = "深度思考（仅 DeepSeek 模型：开=更准但很慢；关=快速回复）"
        dsw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        dsw.setTextColor(cText)
        dsw.thumbTintList = ColorStateList(states, intArrayOf(cGold, 0xFF8C98C0.toInt()))
        dsw.trackTintList = ColorStateList(states, intArrayOf(0x66E5C26B, 0x44FFFFFF))
        dsw.isChecked = prefs.getBoolean(Prefs.AI_DEEP, false)
        dsw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.AI_DEEP, checked).apply()
            Toast.makeText(this, if (checked) "深度思考已开启：回答会更慢，但更有条理" else "深度思考已关闭：直接快速回复", Toast.LENGTH_SHORT).show()
        }
        dsw.setPadding(0, dp(2), 0, dp(6))
        root.addView(dsw)

        // 消息区
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, dp(8))
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // 输入区
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "说点什么…"
        input.setTextColor(cText)
        input.setHintTextColor(0xFF6E7DAA.toInt())
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        input.background = Ui.glass(this, 18, 0xB0)
        input.setPadding(dp(14), dp(10), dp(14), dp(10))
        input.maxLines = 4
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        sendBtn = Button(this)
        sendBtn.text = "发送"
        sendBtn.transformationMethod = null
        sendBtn.stateListAnimator = null
        sendBtn.typeface = Typeface.DEFAULT_BOLD
        sendBtn.setTextColor(cNavy)
        sendBtn.background = Ui.goldFill(this, 20)
        sendBtn.setOnClickListener { send() }
        Ui.press(sendBtn)
        val lpS = LinearLayout.LayoutParams(dp(64), dp(42))
        lpS.leftMargin = dp(8)
        bar.addView(sendBtn, lpS)
        val lpBar = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpBar.topMargin = dp(6)
        root.addView(bar, lpBar)

        pageHost = PageHost(this)
        pageHost.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(pageHost)
        updateStatus()
    }

    private fun addBubble(text: String, user: Boolean, turn: LocalAi.Turn? = null): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.tag = turn
        tv.setOnLongClickListener {
            showBubbleMenu(tv, user)
            true
        }
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tv.setLineSpacing(0f, 1.1f)
        tv.setTextColor(if (user) cNavy else cText)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.background = if (user) Ui.goldFill(this, 16) else Ui.glass(this, 16, 0xC0)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.topMargin = dp(8)
        list.addView(tv, lp)
        scrollDown()
        return tv
    }

    /** 每条 AI 回复下面固定的小提示（不是聊天内容，不会存进记录，也不会喂给模型），让人一眼就知道是 AI 生成的 */
    private val aiTags = HashMap<View, TextView>()

    private fun addAiTag(after: View) {
        if (aiTags.containsKey(after)) return
        val tv = TextView(this)
        tv.text = "⚠ 以上由 AI 生成，并非真人"
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tv.setTextColor(cSub)
        tv.setPadding(dp(14), dp(2), dp(12), 0)
        val idx = list.indexOfChild(after)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.START
        list.addView(tv, if (idx >= 0) idx + 1 else list.childCount, lp)
        aiTags[after] = tv
    }

    /** 拟真模式下，用户说“我叫……我喜欢……”这类关于自己的话，自动记进记忆（可在记忆管理里查看、删除），她就是这样一步步了解你的 */
    private fun learnFrom(userText: String) {
        if (workMode || !prefs.getBoolean(Prefs.AI_HUMAN, true)) return
        val t = userText.trim()
        if (t.length < 4 || t.length > 40) return
        if (Regex("[？?]|吗$|呢$|什么|怎么|为什么").containsMatchIn(t)) return
        if (!Regex("^我(叫|是|喜欢|爱|讨厌|怕|在|住|今年|养了|有|最近|平时|每天|从事|读|学|做|的生日|不吃|爱吃|想)").containsMatchIn(t)) return
        try {
            AiMemory.add(this, AiMemory.splitFact(t), memScope)
        } catch (e: Exception) {
        }
    }

    private fun addNote(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        tv.setTextColor(cSub)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(12), dp(10), dp(12), dp(2))
        list.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        scrollDown()
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStatus() {
        val a = Bond.aff(prefs)
        val l = Bond.level(a)
        val f = Bond.fullness(prefs).toInt()
        val mn = if (LocalAi.hasModel(this)) Models.active(this).shortName + " · " else ""
        val model = when {
            !LocalAi.hasModel(this) -> "未导入模型（点这里下载）"
            loadError != null -> mn + "模型加载失败（点这里切换）"
            !ready -> mn + "模型加载中…"
            LocalAi.usingGpu -> mn + "就绪（GPU，点这里切换模型）"
            else -> mn + "就绪（CPU，点这里切换模型）"
        }
        if (workMode) {
            statusText.text = "工作模式 · " + model
            return
        }
        val heart = if (Persona.romanceActive(prefs)) " · 心动模式" else ""
        statusText.text = "Lv." + (l + 1) + " " + Bond.levelNames[l] + heart + " · 好感 " + a + " · 饱食 " + f + "% · " + model
    }

    private fun updateInputState() {
        val on = ready && !generating && !awaiting
        input.isEnabled = on
        sendBtn.isEnabled = on
        sendBtn.alpha = if (on) 1f else 0.5f
        input.hint = when {
            !LocalAi.hasModel(this) -> "请先导入模型"
            loadError != null -> "模型没能加载"
            !ready -> "正在加载模型…"
            awaiting -> "请先确认或取消上面的操作"
            generating -> "她正在想…"
            else -> "说点什么…"
        }
    }

    // ------------------------------------------------------------ 逻辑

    /** 模型被切换 / 删除 / 下载之后：没模型了就提示，有就重新加载当前模型 */
    private fun onModelChanged() {
        if (!LocalAi.hasModel(this)) {
            ready = false
            loadError = null
            addNote("现在没有可用的模型了。点上面的状态栏可以下载或导入。")
            updateStatus()
            updateInputState()
            return
        }
        addNote("正在加载「" + Models.active(this).shortName + "」…")
        startLoad()
    }

    private fun promptDownload() {
        ModelDownloader.show(this) { ok ->
            if (ok) {
                addNote("模型下载完成，正在加载…")
                startLoad()
            }
        }
    }

    private fun startLoad() {
        ready = false
        loadError = null
        updateStatus()
        updateInputState()
        Thread {
            var err: String? = null
            try {
                LocalAi.ensureEngine(this)
            } catch (t: Throwable) {
                err = t.message ?: t.toString()
            }
            runOnUiThread {
                if (err == null) {
                    ready = true
                } else {
                    loadError = err
                    addNote(
                        "模型加载失败：" + err + "\n常见原因：模型文件和运行库版本不匹配、手机内存不足、文件没下载完整。" +
                            "可以试试关闭设置里的 GPU 加速，或重新下载模型。"
                    )
                }
                updateStatus()
                updateInputState()
            }
        }.start()
    }

    private fun send() {
        Speaker.stop()
        val text = input.text.toString().trim()
        if (text.isEmpty() || generating || !ready) return
        input.setText("")
        pendingUserBubble = addBubble(text, true)
        generating = true
        lastPartial = ""
        // 先把这句话存下来：就算马上被后台清理掉，聊天内容也不会丢
        pendingUser = text
        persistPending()
        updateInputState()

        // 工作模式：问某个网站的官网/网址，直接用内置网址库准确回答，不经过模型
        if (workMode) {
            val direct = WorkKnowledge.answer(text)
            if (direct != null) {
                directAnswer(text, direct)
                return
            }
            if (WorkKnowledge.isUrlQuestion(text)) {
                lookupUrl(text)
                return
            }
        }
        if (!prefs.getBoolean(Prefs.AI_ACTIONS, true)) {
            runChat(text, null)
            return
        }
        val action = try {
            Assistant.parse(this, text)
        } catch (e: Exception) {
            null
        }
        when (action) {
            null -> runChat(text, null)
            is Assistant.Note -> runChat(text, action.text)
            is Assistant.Torch -> runChat(text, Assistant.execute(this, action))
            is Assistant.OpenApp -> runChat(text, Assistant.execute(this, action))
            is Assistant.Alarm -> askConfirm(text, action)
            is Assistant.Timer -> askConfirm(text, action)
            is Assistant.ShareIm -> askConfirm(text, action)
            is Assistant.Browse -> runChat(text, Assistant.execute(this, action))
            is Assistant.PlayMusic -> runChat(text, Assistant.execute(this, action))
            is Assistant.Remember -> runChat(text, Assistant.execute(this, action))
            is Assistant.Forget -> askConfirm(text, action)
            is Assistant.ListMemory -> showMemoryList(text)
            is Assistant.Sms -> resolveContact(text, action, action.name, action.number)
            is Assistant.Dial -> resolveContact(text, action, action.name, action.number)
            is Assistant.FindFiles -> doFind(text, action)
        }
    }

    /** 改变手机状态的操作先让用户确认 */
    private fun askConfirm(userText: String, a: Assistant.Action) {
        awaiting = true
        updateInputState()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.glass(this, 14, 0xC8)
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        val tv = TextView(this)
        tv.text = Assistant.describe(a)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tv.setTextColor(cText)
        card.addView(tv)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ok = Button(this)
        ok.text = "确认"
        ok.transformationMethod = null
        ok.setTextColor(cNavy)
        ok.background = Ui.goldFill(this, 18)
        Ui.press(ok)
        val no = Button(this)
        no.text = "取消"
        no.transformationMethod = null
        no.setTextColor(cText)
        no.background = Ui.ghost(this, 18)
        Ui.press(no)
        val lp1 = LinearLayout.LayoutParams(0, dp(40), 1f)
        lp1.rightMargin = dp(6)
        val lp2 = LinearLayout.LayoutParams(0, dp(40), 1f)
        lp2.leftMargin = dp(6)
        row.addView(ok, lp1)
        row.addView(no, lp2)
        val lpr = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpr.topMargin = dp(10)
        card.addView(row, lpr)
        val lpc = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpc.topMargin = dp(8)
        list.addView(card, lpc)
        scrollDown()

        ok.setOnClickListener {
            card.removeView(row)
            awaiting = false
            val note = Assistant.execute(this, a)
            runChat(userText, note)
        }
        no.setOnClickListener {
            card.removeView(row)
            tv.text = tv.text.toString() + "（已取消）"
            awaiting = false
            runChat(userText, "用户取消了刚才的操作，什么都没有执行。")
        }
    }

    /** 发短信/打电话：先把名字换成号码（需要通讯录权限），再让用户确认 */
    private fun resolveContact(userText: String, a: Assistant.Action, name: String, number: String?) {
        if (number != null) {
            askConfirm(userText, a)
            return
        }
        if (!ContactFinder.hasPermission(this)) {
            askContactsPermission()
            runChat(userText, "用户想联系「" + name + "」，但应用还没有读取通讯录的权限，已经弹窗引导用户授权。请告诉用户授权后再说一次，或者直接把号码告诉你。")
            return
        }
        addNote("正在通讯录里找「" + name + "」…")
        Thread {
            var hits: List<ContactFinder.Hit> = emptyList()
            try {
                hits = ContactFinder.find(this, name)
            } catch (e: Exception) {
            }
            runOnUiThread {
                if (hits.isEmpty()) {
                    runChat(userText, "通讯录里没有找到叫「" + name + "」的联系人。请告诉用户，并让用户直接说出号码。")
                } else {
                    val h = hits[0]
                    val resolved: Assistant.Action = if (a is Assistant.Sms) Assistant.Sms(h.name, h.number, a.body)
                    else Assistant.Dial(h.name, h.number)
                    askConfirm(userText, resolved)
                }
            }
        }.start()
    }

    private fun askContactsPermission() {
        GlassDialog(this)
            .setTitle("需要通讯录权限")
            .setMessage("给联系人发短信、打电话时，需要按名字在通讯录里查号码。只在你让她联系某人时才会查，不会上传。\n\n现在授权吗？")
            .setPositiveButton("授权") { _, _ ->
                requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), 2)
            }
            .setNegativeButton("暂时不要", null)
            .show()
    }

    private fun showMemoryList(userText: String) {
        val items = AiMemory.load(this, memScope)
        if (items.isEmpty()) {
            runChat(userText, "现在还没有任何记忆。用户可以对你说“记住……”来让你记事情。")
            return
        }
        val tv = TextView(this)
        val sb = StringBuilder("她记得的事（共 " + items.size + " 条）：")
        for (i in items.indices) sb.append("\n").append(i + 1).append(". ").append(items[i].text)
        sb.append("\n\n想删除可以说“删除第N条记忆”或“忘掉xxx”，也可以到设置页管理。")
        tv.text = sb.toString()
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setTextColor(cText)
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.background = Ui.glass(this, 12, 0xC0)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        list.addView(tv, lp)
        scrollDown()
        runChat(userText, "已经把记忆列表列在聊天里了，一共 " + items.size + " 条。请简短说一句即可，不要再逐条复述。")
    }

    private fun doFind(userText: String, a: Assistant.FindFiles) {
        if (!FileFinder.hasAccess(this)) {
            askFilePermission()
            runChat(userText, "用户想找文件，但应用还没有“所有文件访问”权限，已经弹窗引导用户去开启。请告诉用户开启后再说一次要找什么。")
            return
        }
        addNote("正在手机里找文件…")
        Thread {
            var files: List<java.io.File> = emptyList()
            var err: String? = null
            try {
                files = FileFinder.search(a.keywords, a.exts, 8)
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                val note: String
                if (err != null) {
                    note = "找文件时出错了：" + err
                } else if (files.isEmpty()) {
                    note = "在手机里没有找到名字匹配的" + a.typeName + "（关键词：" + a.keywords.joinToString("、") + "）。"
                } else {
                    showFiles(files)
                    val sb = StringBuilder("找到了 " + files.size + " 个，已经列在聊天里，点一下就能打开。最新的是：" + files[0].name)
                    note = sb.toString()
                }
                runChat(userText, note)
            }
        }.start()
    }

    private fun showFiles(files: List<java.io.File>) {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
        for (f in files) {
            val tv = TextView(this)
            val sizeKb = f.length() / 1024L
            val size = if (sizeKb >= 1024L) (sizeKb / 1024L).toString() + " MB" else sizeKb.toString() + " KB"
            tv.text = f.name + "\n" + (f.parent ?: "") + "\n" + size + " · " + fmt.format(java.util.Date(f.lastModified()))
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            tv.setTextColor(cText)
            tv.setPadding(dp(12), dp(8), dp(12), dp(8))
            tv.background = Ui.glass(this, 12, 0xC0)
            tv.setOnClickListener { openFile(f) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            list.addView(tv, lp)
        }
        scrollDown()
    }

    private fun openFile(f: java.io.File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, packageName + ".files", f)
            val ext = f.extension.lowercase()
            val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "手机上没有能打开这种文件的应用", Toast.LENGTH_LONG).show()
        }
    }

    private fun askFilePermission() {
        GlassDialog(this)
            .setTitle("需要文件访问权限")
            .setMessage("找文件需要「所有文件访问」权限。只有你让她找文件时，才会按文件名在手机里查找；不会读取文件内容，也不会上传。\n\n现在去开启吗？")
            .setPositiveButton("去开启") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        try {
                            startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:$packageName")
                                )
                            )
                        } catch (e: Exception) {
                            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        }
                    } else {
                        requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "打不开权限设置页，请到系统设置里手动开启", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("暂时不要", null)
            .show()
    }

    /** 真正调用模型生成回答；extra 是刚执行的操作的真实结果（有的话就不再联网搜索） */
    /** 内置库里没有的网址：联网查，直接给搜索结果里的真实链接（不经过模型） */
    private fun lookupUrl(text: String) {
        addNote("正在联网查官方网址…")
        val prev = history.filter { it.fromUser }.map { it.text }
        Thread {
            val ans = try {
                WorkKnowledge.searchUrl(prefs, text, prev)
            } catch (e: Exception) {
                "联网查询失败了：" + (e.message ?: "未知原因") + "。请检查网络后再试一次。"
            }
            runOnUiThread { directAnswer(text, ans) }
        }.start()
    }

    /** 不经过模型的准确回答：直接显示、保存 */
    private fun directAnswer(userText: String, answer: String) {
        val bot = addBubble(answer, false)
        val ut = LocalAi.Turn(true, userText)
        val bt = LocalAi.Turn(false, answer)
        history.add(ut)
        history.add(bt)
        pendingUserBubble?.tag = ut
        bot.tag = bt
        pendingUserBubble = null
        pendingUser = null
        generating = false
        ChatStore.save(this, history, memScope)
        updateInputState()
        scrollDown()
    }

    private fun runChat(text: String, extra: String?) {
        generating = true
        lastPartial = ""
        lastHadExtra = extra != null
        updateInputState()
        val bot = addBubble("…", false)
        currentBot = bot

        val useSearch = extra == null && prefs.getBoolean(if (workMode) Prefs.AI_WORK_SEARCH else Prefs.AI_SEARCH, workMode)
        lastHits = null
        val snapshot = ArrayList<LocalAi.Turn>(history)

        Thread {
            var hits: List<WebSearch.Hit>? = null
            var failed = false
            var failMsg = ""
            if (useSearch) {
                runOnUiThread { bot.text = "（正在联网搜索…）" }
                try {
                    val prevUser = snapshot.filter { it.fromUser }.map { it.text }.takeLast(2)
                    hits = WebSearch.searchDeep(prefs, WebSearch.buildQuery(text, prevUser))
                } catch (e: Exception) {
                    failed = true
                    failMsg = e.message ?: e.toString()
                }
            }
            lastHits = hits
            val mems = AiMemory.forPrompt(this, memScope)
            val small = Models.active(this).id == Models.DEEPSEEK
            val system = if (workMode) WorkPersona.systemPrompt(prefs, if (useSearch) hits else null, failed, extra, mems, small)
            else Persona.systemPrompt(prefs, hits, failed, extra, mems, small, Models.active(this).label)
            runOnUiThread { bot.text = "…" }
            LocalAi.generate(
                this, system, snapshot, text,
                { partial ->
                    runOnUiThread {
                        lastPartial = partial
                        bot.text = if (partial.isBlank()) "（正在思考…）" else Simplify.toSimplified(partial)
                        scrollDown()
                        persistThrottled()
                    }
                },
                { err -> runOnUiThread { onFinished(text, bot, err, if (failed) failMsg else null) } },
                if (workMode) 0.3 else 0.7
            )
        }.start()
    }

    private fun onFinished(userText: String, bot: TextView, err: Throwable?, searchError: String?) {
        generating = false
        var reply = Persona.cleanReply(lastPartial.trim())
        val spokenText = reply
        if (workMode && reply.isNotEmpty() && !lastHadExtra) {
            val hs = lastHits
            reply += if (hs != null && hs.isNotEmpty()) WorkPersona.sourcesBlock(hs) else WorkPersona.NO_SOURCE_NOTE
        }
        val userTurn = LocalAi.Turn(true, userText)
        history.add(userTurn)
        pendingUserBubble?.tag = userTurn
        if (reply.isNotEmpty()) {
            val botTurn = LocalAi.Turn(false, reply)
            history.add(botTurn)
            bot.tag = botTurn
        }
        pendingUserBubble = null
        currentBot = null
        pendingUser = null
        ChatStore.save(this, history, memScope)
        if (reply.isEmpty()) {
            bot.text = if (err != null) "（出错了：" + (err.message ?: err.toString()) + "）"
            else "……（她好像在发呆，再说一次试试？）"
        } else {
            // 像真人连发微信：回复里用换行分开的几句，拆成几个气泡，间隔一会儿再冒出来
            val parts = ArrayList(reply.split('\n').map { it.trim() }.filter { it.isNotEmpty() }.take(3))
            // 拟真：偶尔“打错字”，过一会儿自己更正（只是显示效果，保存的聊天记录是正确的）
            if (!workMode && err == null && parts.isNotEmpty() && prefs.getBoolean(Prefs.AI_HUMAN, true) && Math.random() < 0.07) {
                val t = makeTypo(parts[0])
                if (t != null) {
                    parts[0] = t.first
                    parts.add(1, t.second)
                }
            }
            if (!workMode && parts.size >= 2) {
                bot.text = parts[0]
                var delay = 0L
                val turn = bot.tag as? LocalAi.Turn
                for (i in 1 until parts.size) {
                    delay += 500L + minOf(1400L, parts[i].length * 45L)
                    val txt = parts[i]
                    val last = i == parts.size - 1
                    list.postDelayed({
                        if (!isFinishing) {
                            val nb = addBubble(txt, false, turn)
                            if (last) addAiTag(nb)
                        }
                    }, delay)
                }
            } else {
                bot.text = reply
                addAiTag(bot)
            }
            if (!lastHadExtra) learnFrom(userText)
            if (prefs.getBoolean(Prefs.AI_TTS, false) && err == null) {
                Speaker.speak(this, spokenText)
                if (Speaker.unavailable()) addNote("朗读失败：手机上没有可用的中文语音引擎，请到设置里点「系统朗读设置」安装或选择。")
            }
            if (!lastHadExtra && Regex("(已经|已|帮你|帮您|给你).{0,8}(打开|启动|设好|设置好|定好)|(打开|启动)了").containsMatchIn(reply)) {
                addNote("提示：她刚才说的操作其实没有执行（这句话没被识别成手机操作）。可以换个说法，比如“打开微信”。")
            }
            if (!workMode && Bond.chatAff(prefs)) {
                val lv = Bond.levelNames[Bond.level(Bond.aff(prefs))]
                addNote("好感度提升了！你们现在是「" + lv + "」的关系。")
            }
        }
        if (searchError != null) addNote("联网搜索失败：" + searchError + "\n这次是凭记忆回答的。可以到设置页点「测试联网搜索」排查。")
        updateStatus()
        updateInputState()
        scrollDown()
    }

    private val typoPairs = listOf(
        "在" to "再", "再" to "在", "那" to "哪", "哪" to "那", "做" to "作", "以" to "已", "已" to "以", "像" to "象"
    )

    /** 在句子里挑一个容易打错的字换成同音字；返回（带错字的句子, 更正的话），找不到合适的位置返回 null */
    private fun makeTypo(s: String): Pair<String, String>? {
        var depth = 0
        for (i in s.indices) {
            val ch = s[i]
            if (ch == '（' || ch == '(') depth++
            if (ch == '）' || ch == ')') depth = maxOf(0, depth - 1)
            if (depth > 0 || i < 3) continue
            val pair = typoPairs.firstOrNull { it.first[0] == ch } ?: continue
            val wrong = s.substring(0, i) + pair.second + s.substring(i + 1)
            val fixes = listOf("打错字了…是“" + ch + "”啦", "*" + ch, "诶打错了，是“" + ch + "”")
            return Pair(wrong, fixes[(Math.random() * fixes.size).toInt().coerceIn(0, fixes.size - 1)])
        }
        return null
    }

    /** 长按气泡：选择文字 / 复制 / 删除这条（我的和她的都可以删） */
    private fun showBubbleMenu(tv: TextView, user: Boolean) {
        val text = tv.text.toString()
        GlassDialog(this)
            .setTitle(if (user) "我的消息" else "她的消息")
            .setItems(arrayOf("选择文字", "复制全文", "删除这条消息")) { _, which ->
                when (which) {
                    0 -> showSelectable(text)
                    1 -> copyText(text)
                    2 -> confirmDeleteBubble(tv)
                }
            }
            .show()
    }

    private fun showSelectable(text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextIsSelectable(true)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t.setTextColor(cText)
        t.setLineSpacing(0f, 1.15f)
        t.setPadding(dp(22), dp(10), dp(22), dp(10))
        val sv = ScrollView(this)
        sv.addView(t)
        GlassDialog(this)
            .setTitle("选择文字（长按文字可以选中一部分）")
            .setView(sv)
            .setPositiveButton("复制全文") { _, _ -> copyText(text) }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun copyText(text: String) {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("chat", text))
            Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDeleteBubble(tv: TextView) {
        if (generating && (tv === pendingUserBubble || tv === currentBot)) {
            Toast.makeText(this, "她正在回复这条，等回复完再删吧", Toast.LENGTH_SHORT).show()
            return
        }
        val preview = tv.text.toString().let { if (it.length > 40) it.substring(0, 40) + "…" else it }
        GlassDialog(this)
            .setTitle("删除这条消息？")
            .setMessage(preview)
            .setPositiveButton("删除") { _, _ ->
                val turn = tv.tag as? LocalAi.Turn
                if (turn != null) {
                    history.removeAll { it === turn }
                    ChatStore.save(this, history, memScope)
                }
                list.removeView(tv)
                aiTags.remove(tv)?.let { list.removeView(it) }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmClear() {
        if (generating) return
        GlassDialog(this)
            .setTitle("清空对话")
            .setMessage("会删除本机保存的聊天记录。")
            .setPositiveButton("清空") { _, _ ->
                history.clear()
                ChatStore.clear(this, memScope)
                list.removeAllViews()
                addNote("对话已清空。")
            }
            .setNegativeButton("取消", null)
            .show()
    }
}

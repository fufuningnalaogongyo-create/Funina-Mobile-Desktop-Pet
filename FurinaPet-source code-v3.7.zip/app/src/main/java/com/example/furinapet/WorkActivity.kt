package com.example.furinapet

/**
 * 工作模式：独立的页面，和普通聊天分开——
 * 独立的聊天记录、独立的记忆分区、严谨准确的回答方式（查网址走内置网址库，其他资料走联网搜索并附上来源）。
 */
class WorkActivity : ChatActivity() {
    override val workMode: Boolean get() = true
}

package com.example.furinapet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.view.Choreographer
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * 桌宠本体：把一张立绘做出呼吸、跳跃、转圈、摇晃、贴边歪头、拖拽摆动等动作。
 * 所有动作都是对整张图做变形，不改动图片内容本身。
 */
class PetView(context: Context) : View(context) {

    interface Listener {
        fun onTap()
        fun onDoubleTap()
        fun onLongPress()
        fun onDragStart()
        fun onDragMove(dx: Float, dy: Float)
        fun onDragEnd()
    }

    private class Particle(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val maxLife: Float, val size: Float, val color: Int,
        val kind: Int = 0
    )

    var listener: Listener? = null
    var hapticEnabled = true

    // ---------- 尺寸 ----------
    private var bmp: Bitmap? = null
    private var aspect = 0.73f
    private val density = context.resources.displayMetrics.density

    var drawW = 0f; private set
    var drawH = 0f; private set
    var padX = 0f; private set
    var padY = 0f; private set
    var windowW = 1; private set
    var windowH = 1; private set

    private val src = Rect()
    private val dst = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val heartPath = Path()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    fun setBitmap(b: Bitmap) {
        bmp = b
        aspect = b.width.toFloat() / b.height.toFloat()
        src.set(0, 0, b.width, b.height)
        invalidate()
    }

    fun getAspect(): Float = aspect

    /** 按高度（像素）重新计算窗口大小，之后读取 windowW/windowH。 */
    fun configure(heightPx: Int) {
        val h = heightPx.toFloat()
        padY = h * 0.08f
        drawH = h - 2f * padY
        drawW = drawH * aspect
        padX = h * 0.2f
        windowW = (drawW + 2f * padX).toInt()
        windowH = heightPx
        invalidate()
    }

    fun setAlphaPct(pct: Int) {
        paint.alpha = (pct.coerceIn(10, 100) * 255) / 100
        invalidate()
    }

    // ---------- 动画状态 ----------
    private var time = 0f
    private var lastFrame = 0.0
    private var attached = false

    var tiltTarget = 0f
    private var tilt = 0f
    private var dockSide = -1
    private var swing = 0f
    private var dragVx = 0f
    private var squash = 0f
    private var jumpT = -1f
    private var jumpDur = 0.5f
    private var jumpH = 0f
    private var spinT = -1f
    private var shakeT = -1f
    private var walking = false
    private var facing = 1f
    private var hanging = false

    private val particles = ArrayList<Particle>()
    private var eatEmoji: String? = null
    private var eatT = -1f

    fun eat(emoji: String) {
        eatEmoji = emoji
        eatT = 0f
    }

    fun burstHearts(count: Int) {
        val cx = padX + drawW * 0.47f
        val cy = padY + drawH * 0.30f
        val colors = intArrayOf(0xFFFF8FB1.toInt(), 0xFFFFB3C9.toInt(), 0xFFFF6B9A.toInt())
        for (i in 0 until count) {
            particles.add(
                Particle(
                    cx + (Random.nextFloat() - 0.5f) * drawW * 0.6f,
                    cy + Random.nextFloat() * drawH * 0.1f,
                    (Random.nextFloat() - 0.5f) * 40f * density,
                    -(40f + Random.nextFloat() * 70f) * density,
                    1.2f + Random.nextFloat() * 0.6f, 1.8f,
                    (5f + Random.nextFloat() * 5f) * density,
                    colors[Random.nextInt(colors.size)],
                    1
                )
            )
        }
        while (particles.size > 60) particles.removeAt(0)
    }

    /** side: -1 不贴边，0 贴左边，1 贴右边；deg 为歪头角度。头总是朝屏幕内侧歪。 */
    fun setDock(side: Int, deg: Float) {
        dockSide = side
        tiltTarget = when (side) {
            0 -> deg
            1 -> -deg
            else -> 0f
        }
        invalidate()
    }

    fun setWalking(w: Boolean) { walking = w }
    fun setFacing(dir: Int) { facing = if (dir < 0) -1f else 1f }
    fun setHanging(h: Boolean) { hanging = h }

    fun jump(heightDp: Float = 16f) {
        jumpT = 0f
        jumpDur = 0.5f
        jumpH = heightDp * density
    }

    fun spin() { spinT = 0f }
    fun shake() { shakeT = 0f }

    fun burst(count: Int) {
        val cx = padX + drawW / 2f
        val cy = padY + drawH * 0.35f
        val colors = intArrayOf(0xFFFFD66B.toInt(), 0xFF7CD8FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF9BB8FF.toInt())
        for (i in 0 until count) {
            val ang = Random.nextFloat() * (2f * PI.toFloat())
            val sp = (40f + Random.nextFloat() * 90f) * density
            particles.add(
                Particle(
                    cx + (Random.nextFloat() - 0.5f) * drawW * 0.5f,
                    cy + (Random.nextFloat() - 0.5f) * drawH * 0.3f,
                    cos(ang) * sp, sin(ang) * sp - 30f * density,
                    0.9f + Random.nextFloat() * 0.5f, 1.3f,
                    (4f + Random.nextFloat() * 6f) * density,
                    colors[Random.nextInt(colors.size)]
                )
            )
        }
        if (particles.size > 60) {
            while (particles.size > 60) particles.removeAt(0)
        }
    }

    private fun isBusy(): Boolean {
        return dragging || hanging || jumpT >= 0f || spinT >= 0f || shakeT >= 0f || eatT >= 0f || walking ||
            particles.isNotEmpty() || abs(tilt - tiltTarget) > 0.2f || abs(swing) > 0.2f || squash > 0.01f
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!attached) return
            val now = frameTimeNanos / 1_000_000_000.0
            if (lastFrame == 0.0) lastFrame = now
            val dt = (now - lastFrame).toFloat()
            val minDt = if (isBusy()) 0f else 0.05f
            if (dt >= minDt) {
                lastFrame = now
                step(if (dt > 0.05f) 0.05f else dt)
                invalidate()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        lastFrame = 0.0
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onDetachedFromWindow() {
        attached = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        super.onDetachedFromWindow()
    }

    private fun lerpK(dt: Float, speed: Float): Float {
        val k = dt * speed
        return if (k > 1f) 1f else k
    }

    private fun step(dt: Float) {
        time += dt
        tilt += (tiltTarget - tilt) * lerpK(dt, 9f)

        val swingTarget = if (dragging) (-dragVx * 0.012f).coerceIn(-22f, 22f) else 0f
        swing += (swingTarget - swing) * lerpK(dt, 8f)
        if (!dragging) dragVx *= 0.8f

        if (jumpT >= 0f) {
            jumpT += dt
            if (jumpT >= jumpDur) {
                jumpT = -1f
                squash = 0.16f
            }
        }
        squash += (0f - squash) * lerpK(dt, 9f)

        if (spinT >= 0f) {
            spinT += dt
            if (spinT >= 0.7f) spinT = -1f
        }
        if (shakeT >= 0f) {
            shakeT += dt
            if (shakeT >= 0.5f) shakeT = -1f
        }
        if (eatT >= 0f) {
            eatT += dt
            if (eatT >= 1.5f) {
                eatT = -1f
                eatEmoji = null
            }
        }

        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= dt
            if (p.life <= 0f) {
                it.remove()
            } else {
                p.x += p.vx * dt
                p.y += p.vy * dt
                p.vx *= 0.96f
                p.vy *= 0.96f
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        val breath = sin(time * 2.2f)

        var offY = 0f
        if (jumpT >= 0f) {
            val p = jumpT / jumpDur
            offY -= 4f * jumpH * p * (1f - p)
        }
        if (walking) offY -= abs(sin(time * 9f)) * 4f * density

        var offX = 0f
        if (shakeT >= 0f) {
            offX = sin(shakeT * 60f) * 5f * density * (1f - shakeT / 0.5f)
        }

        val idleSway = if (dockSide >= 0) sin(time * 1.3f) * 2.5f else sin(time * 1.1f) * 1.0f
        val walkWobble = if (walking) sin(time * 9f) * 4f else 0f
        val rot = tilt + idleSway + swing + walkWobble

        var spinX = 1f
        if (spinT >= 0f) spinX = cos(spinT / 0.7f * 2f * PI.toFloat())
        if (abs(spinX) < 0.05f) spinX = if (spinX < 0f) -0.05f else 0.05f

        var sy = 1f + 0.015f * breath - squash * 0.9f
        var sx = 1f - 0.008f * breath + squash * 0.6f
        if (hanging || dragging) {
            sy += 0.04f
            sx -= 0.02f
        }
        if (eatT >= 0.5f) {
            val m = sin((eatT - 0.5f) * 38f) * 0.025f
            sy += m
            sx -= m * 0.5f
        }
        sx *= facing * spinX

        val cx = padX + drawW / 2f
        val pivotY = padY + drawH * 0.78f
        val bottom = padY + drawH

        dst.set(padX, padY, padX + drawW, padY + drawH)

        canvas.save()
        canvas.translate(offX, offY)
        canvas.rotate(rot, cx, pivotY)
        canvas.scale(sx, sy, cx, bottom)
        canvas.drawBitmap(b, src, dst, paint)
        canvas.restore()

        val em = eatEmoji
        if (em != null && eatT >= 0f && eatT < 0.5f) {
            val q = eatT / 0.5f
            textPaint.textSize = drawH * (0.16f - 0.08f * q)
            canvas.drawText(em, padX + drawW * (0.72f - 0.25f * q), padY + drawH * (0.06f + 0.40f * q), textPaint)
        }

        for (p in particles) {
            val a = (p.life / p.maxLife).coerceIn(0f, 1f)
            starPaint.color = p.color
            starPaint.alpha = (a * 255f).toInt()
            if (p.kind == 1) {
                drawHeart(canvas, p.x, p.y, p.size * (0.6f + 0.4f * a))
            } else {
                drawStar(canvas, p.x, p.y, p.size * (0.5f + 0.5f * a))
            }
        }
    }

    private fun drawHeart(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        heartPath.reset()
        heartPath.moveTo(cx, cy + r * 0.9f)
        heartPath.cubicTo(cx - r * 1.6f, cy - r * 0.2f, cx - r * 0.9f, cy - r * 1.4f, cx, cy - r * 0.5f)
        heartPath.cubicTo(cx + r * 0.9f, cy - r * 1.4f, cx + r * 1.6f, cy - r * 0.2f, cx, cy + r * 0.9f)
        heartPath.close()
        canvas.drawPath(heartPath, starPaint)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        starPath.reset()
        starPath.moveTo(cx, cy - r)
        starPath.quadTo(cx, cy, cx + r, cy)
        starPath.quadTo(cx, cy, cx, cy + r)
        starPath.quadTo(cx, cy, cx - r, cy)
        starPath.quadTo(cx, cy, cx, cy - r)
        starPath.close()
        canvas.drawPath(starPath, starPaint)
    }

    // ---------- 触摸 ----------
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var lastRawX = 0f
    private var lastMoveTime = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (hapticEnabled) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            listener?.onTap()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (hapticEnabled) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            listener?.onDoubleTap()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (!dragging) {
                if (hapticEnabled) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                listener?.onLongPress()
            }
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                lastRawX = e.rawX
                lastMoveTime = SystemClock.uptimeMillis()
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                    dragging = true
                    listener?.onDragStart()
                }
                if (dragging) {
                    val now = SystemClock.uptimeMillis()
                    val dtMs = now - lastMoveTime
                    if (dtMs > 0) {
                        val v = (e.rawX - lastRawX) / dtMs * 1000f
                        dragVx = dragVx * 0.6f + v * 0.4f
                        lastRawX = e.rawX
                        lastMoveTime = now
                    }
                    listener?.onDragMove(dx, dy)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    listener?.onDragEnd()
                }
            }
        }
        return true
    }
}

package com.example.furinapet

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** 一键下载模型（默认 Gemma 4 E2B，也可以下 DeepSeek 手机轻量版，都是 .litertlm）。支持断点续传：网络断了再点一次会从断点继续。 */
object ModelDownloader {

    const val OFFICIAL =
        "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm"
    const val MIRROR =
        "https://hf-mirror.com/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm"

    private const val UA = "FurinaPet/3.1 (Android desktop pet)"

    @Volatile
    private var cancel = false

    @Volatile
    private var running = false

    /** 阻塞下载，请在后台线程调用。下完后这个模型会自动成为当前使用的模型 */
    fun download(ctx: Context, spec: Models.Spec, url: String, onProgress: (Long, Long) -> Unit) {
        if (!url.startsWith("https://")) throw IOException("下载地址必须以 https:// 开头")
        val d = LocalAi.dir(ctx)
        d.mkdirs()
        val part = Models.partFile(ctx, spec)
        var have = if (part.isFile) part.length() else 0L

        var expected = -1L
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            if (have > 0L) c.setRequestProperty("Range", "bytes=$have-")

            val code = c.responseCode
            var total = -1L
            when (code) {
                200 -> {
                    // 服务器没按断点返回，只能从头来
                    have = 0L
                    part.delete()
                    total = c.contentLengthLong
                }
                206 -> {
                    val cr = c.getHeaderField("Content-Range")
                    total = cr?.substringAfter('/', "")?.trim()?.toLongOrNull() ?: -1L
                }
                416 -> {
                    part.delete()
                    throw IOException("之前的下载记录已失效，请再点一次下载")
                }
                else -> throw IOException("服务器返回 HTTP $code")
            }
            if (total > 0L && d.usableSpace < (total - have) + 256L * 1024L * 1024L) {
                throw IOException("手机存储空间不足，需要至少 " + ((total - have) / 1048576L + 256L) + " MB 可用空间")
            }

            expected = total
            FileOutputStream(part, have > 0L).use { out ->
                c.inputStream.use { ins ->
                    val buf = ByteArray(256 * 1024)
                    var done = have
                    var last = 0L
                    while (true) {
                        if (cancel) throw IOException("已暂停，再点一次下载会从断点继续")
                        val r = ins.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        done += r
                        val now = System.currentTimeMillis()
                        if (now - last > 500L) {
                            last = now
                            onProgress(done, total)
                        }
                    }
                    onProgress(done, total)
                }
            }
        } finally {
            c.disconnect()
        }

        val size = part.length()
        if (size < 1024L * 1024L) {
            part.delete()
            throw IOException("下载到的文件太小，可能地址不对")
        }
        if (expected > 0L && size != expected) {
            throw IOException("下载不完整（" + (size / 1048576L) + " / " + (expected / 1048576L) + " MB）")
        }
        // 换上新模型前，如果正在用的就是要被覆盖的这个，先卸载
        if (Models.active(ctx).id == spec.id) LocalAi.release()
        val dst = Models.file(ctx, spec)
        dst.delete()
        if (!part.renameTo(dst)) {
            part.copyTo(dst, true)
            part.delete()
        }
        Models.setActive(ctx, spec.id)
    }

    private fun fmt(b: Long): String =
        if (b >= 1024L * 1024L * 1024L) String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        else String.format(Locale.US, "%.0f MB", b / 1048576.0)

    /** 弹出确认框 → 下载默认模型 → 回调是否成功（在主线程） */
    fun show(act: Activity, onFinished: (Boolean) -> Unit) {
        show(act, Models.byId(Models.GEMMA), onFinished)
    }

    /** 弹出确认框 → 下载指定模型 → 回调是否成功（在主线程） */
    fun show(act: Activity, spec: Models.Spec, onFinished: (Boolean) -> Unit) {
        if (!spec.downloadable) return
        if (running) {
            Toast.makeText(act, "正在下载中", Toast.LENGTH_SHORT).show()
            return
        }
        // 已经装好了：默认不重复下载，要重新下载必须明确确认
        if (Models.installed(act, spec)) {
            val size = Models.file(act, spec).length()
            val isActive = Models.active(act).id == spec.id
            val b = GlassDialog(act)
                .setTitle("模型已经安装")
                .setMessage(
                    "「" + spec.shortName + "」已经在手机里了（" + fmt(size) + "）" +
                        (if (isActive) "，正在使用。" else "，但现在用的是别的模型。") + "\n\n" +
                        "重新下载会再消耗 " + spec.sizeText + " 流量和存储空间，下载完成后才会替换旧文件。"
                )
                .setPositiveButton("不用了", null)
                .setNegativeButton("仍然重新下载") { _, _ ->
                    confirmDownload(act, spec, onFinished)
                }
            if (!isActive) {
                b.setNeutralButton("切换到它") { _, _ ->
                    Models.setActive(act, spec.id)
                    Thread { LocalAi.release() }.start()
                    Toast.makeText(act, "已切换到「" + spec.shortName + "」", Toast.LENGTH_SHORT).show()
                    onFinished(true)
                }
            }
            b.show()
            return
        }
        confirmDownload(act, spec, onFinished)
    }

    private fun confirmDownload(act: Activity, spec: Models.Spec, onFinished: (Boolean) -> Unit) {
        val p = Prefs.get(act)
        // 设置里的自定义下载地址只用于默认模型
        val custom = if (spec.id == Models.GEMMA) (p.getString(Prefs.AI_MODEL_URL, "") ?: "").trim() else ""
        val resume = Models.partFile(act, spec).let { it.isFile && it.length() > 0L }

        val sb = StringBuilder()
        sb.append("将下载「").append(spec.label).append("」（").append(spec.sizeText).append("），下载后就能离线聊天，并自动切换为当前模型。\n")
        sb.append(spec.intro).append("\n")
        sb.append("建议连接 Wi-Fi，并保证有 3GB 以上空闲存储；下载期间请保持本应用在前台。")
        if (resume) sb.append("\n检测到没下完的文件，会从断点继续。")
        if (custom.isNotEmpty()) sb.append("\n（使用你在设置里填的自定义下载地址）")

        val b = GlassDialog(act)
            .setTitle("下载 AI 模型")
            .setMessage(sb.toString())
            .setNegativeButton("取消", null)
        if (custom.isNotEmpty()) {
            b.setPositiveButton("开始下载") { _, _ -> run(act, spec, custom, onFinished) }
        } else {
            b.setPositiveButton("官方源") { _, _ -> run(act, spec, spec.official, onFinished) }
            b.setNeutralButton("国内镜像") { _, _ -> run(act, spec, spec.mirror, onFinished) }
        }
        b.show()
    }

    private fun run(act: Activity, spec: Models.Spec, url: String, onFinished: (Boolean) -> Unit) {
        running = true
        cancel = false
        act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val dlg = GlassDialog(act)
            .setMessage("正在连接…")
            .setCancelable(false)
            .setNegativeButton("暂停", null)
            .create()
        dlg.show()
        // 点「暂停」只发暂停信号，不直接关窗口，等下载线程收尾
        dlg.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener {
            cancel = true
            dlg.setMessage("正在暂停…")
        }

        Thread {
            var err: String? = null
            var lastT = System.currentTimeMillis()
            var lastB = -1L
            var speed = 0.0
            try {
                download(act, spec, url) { done, total ->
                    val now = System.currentTimeMillis()
                    if (lastB < 0L) {
                        lastB = done
                        lastT = now
                    } else if (now - lastT >= 1500L) {
                        speed = (done - lastB) * 1000.0 / (now - lastT) / 1048576.0
                        lastB = done
                        lastT = now
                    }
                    val s = speed
                    act.runOnUiThread {
                        val pct = if (total > 0L) " (" + (done * 100L / total) + "%)" else ""
                        val t = if (total > 0L) " / " + fmt(total) else ""
                        dlg.setMessage(
                            "正在下载「" + spec.shortName + "」…\n已下载 " + fmt(done) + t + pct +
                                (if (s > 0.0) String.format(Locale.US, "\n速度 %.1f MB/s", s) else "")
                        )
                    }
                }
            } catch (e: Throwable) {
                err = e.message ?: e.toString()
            }
            running = false
            act.runOnUiThread {
                try {
                    dlg.dismiss()
                } catch (e: Exception) {
                }
                act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (err == null) {
                    Toast.makeText(act, "「" + spec.shortName + "」下载完成，已设为当前模型", Toast.LENGTH_LONG).show()
                    onFinished(true)
                } else {
                    Toast.makeText(act, "没有下载完：$err\n网络恢复后再点一次下载，会从断点继续", Toast.LENGTH_LONG).show()
                    onFinished(false)
                }
            }
        }.start()
    }
}

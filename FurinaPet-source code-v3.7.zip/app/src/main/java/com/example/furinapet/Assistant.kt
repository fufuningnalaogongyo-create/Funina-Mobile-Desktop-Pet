package com.example.furinapet

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Environment
import android.provider.AlarmClock
import java.io.File
import java.util.Calendar

/**
 * 手机助手：把「定闹钟 / 倒计时 / 找文件 / 打开应用 / 手电筒」这类说法，用规则识别成具体操作。
 * 刻意不让小模型自己发指令（容易乱来）：识别和执行都由程序完成，改变手机状态的操作会先让用户确认，
 * 模型只负责用芙宁娜的口吻转述真实的执行结果。
 */
object Assistant {

    sealed class Action
    class Alarm(val hour: Int, val minute: Int, val label: String, val dayText: String) : Action()
    class Timer(val seconds: Int, val label: String) : Action()
    class FindFiles(val keywords: List<String>, val exts: Set<String>?, val typeName: String) : Action()
    class OpenApp(val label: String, val pkg: String, val scheme: String = "") : Action()
    class Torch(val on: Boolean) : Action()
    class Browse(val url: String, val desc: String) : Action()
    class Sms(val name: String, val number: String?, val body: String) : Action()
    class Dial(val name: String, val number: String?) : Action()
    class ShareIm(val app: String, val pkg: String, val body: String, val to: String) : Action()
    class PlayMusic(val label: String, val pkg: String, val query: String) : Action()
    class Remember(val text: String) : Action()
    class ListMemory : Action()

    /** 要删的记忆（ids 和 texts 一一对应）；clearAll 表示清空全部 */
    class Forget(val ids: List<Long>, val texts: List<String>, val clearAll: Boolean) : Action()

    /** 没法执行时，给模型的一句真实情况说明（比如没说几点、时间不支持） */
    class Note(val text: String) : Action()

    private const val NUM = "[0-9零〇一二两三四五六七八九十]{1,3}"

    // ------------------------------------------------------------------ 识别

    /** 当前记忆分区：普通聊天 / 工作模式（由聊天界面设置） */
    @Volatile
    var memoryScope: String = AiMemory.CHAT

    private val scope: String get() = memoryScope
    private val workMode: Boolean get() = memoryScope == AiMemory.WORK

    fun parse(ctx: Context, raw: String): Action? {
        val t = raw.trim()
        if (t.isEmpty() || t.length > 300) return null
        parseMemory(ctx, t)?.let { return it }
        if (t.length > 80) return null
        parseTorch(t)?.let { return it }
        // “提醒我明早打开微信”这类是定闹钟，不是马上打开应用
        val alarmish = Regex("提醒|叫我|喊我|叫醒|闹钟|倒计时|计时").containsMatchIn(t)
        if (!alarmish) {
            // 工作模式要的是准确的回答，“百度一下……”之类不直接开浏览器、也不放音乐
            if (!workMode) {
                parseBrowse(t)?.let { return it }
            }
            parseComm(t)?.let { return it }
            if (!workMode) {
                parseMusic(ctx, t)?.let { return it }
            }
            parseOpenApp(ctx, t)?.let { return it }
        }
        parseTimerOrAlarm(t)?.let { return it }
        parseFiles(t)?.let { return it }
        return null
    }

    /** 给确认卡片用的一句话 */
    fun describe(a: Action): String = when (a) {
        is Alarm -> "要我帮你定一个 " + a.dayText + " " + two(a.hour) + ":" + two(a.minute) + " 的闹钟" +
            (if (a.label.isNotEmpty()) "（" + a.label + "）" else "") + "吗？"
        is Timer -> "要我帮你定一个 " + durText(a.seconds) + " 的倒计时" +
            (if (a.label.isNotEmpty()) "（" + a.label + "）" else "") + "吗？"
        is Sms -> "要给「" + a.name + "」（" + (a.number ?: "") + "）发短信吗？\n内容：" + a.body +
            "\n（只会打开短信界面并填好内容，需要你自己点发送）"
        is Dial -> "要拨打「" + a.name + "」（" + (a.number ?: "") + "）吗？\n（只会打开拨号界面，需要你自己按拨号键）"
        is ShareIm -> "要把下面这句话发到「" + a.app + "」吗？\n内容：" + a.body +
            (if (a.to.isNotEmpty()) "\n你想发给「" + a.to + "」，请在" + a.app + "里自己选择他" else "") +
            "\n（只会打开" + a.app + "的选人界面，需要你自己选人并点发送）"
        is Forget -> if (a.clearAll) "要清空她记住的全部 " + a.texts.size + " 条记忆吗？（无法恢复）"
        else "要让她忘掉这些记忆吗？\n" + a.texts.mapIndexed { i, x -> (i + 1).toString() + ". " + x }.joinToString("\n")
        else -> ""
    }

    private fun two(n: Int): String = if (n < 10) "0$n" else n.toString()

    private fun durText(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val sb = StringBuilder()
        if (h > 0) sb.append(h).append("小时")
        if (m > 0) sb.append(m).append("分钟")
        if (s > 0) sb.append(s).append("秒")
        return sb.toString()
    }

    private fun cnNum(s0: String): Int? {
        val s = s0.trim()
        if (s.isEmpty()) return null
        s.toIntOrNull()?.let { return it }
        val d = mapOf(
            '零' to 0, '〇' to 0, '一' to 1, '二' to 2, '两' to 2, '三' to 3, '四' to 4,
            '五' to 5, '六' to 6, '七' to 7, '八' to 8, '九' to 9
        )
        if (s == "十") return 10
        val i = s.indexOf('十')
        if (i >= 0) {
            val a = if (i == 0) 1 else (d[s[0]] ?: return null)
            val b = if (i == s.length - 1) 0 else (d[s[i + 1]] ?: return null)
            return a * 10 + b
        }
        return if (s.length == 1) d[s[0]] else null
    }

    // ---- 手电筒

    private fun parseTorch(t: String): Action? {
        if (!Regex("手电筒|手电|闪光灯").containsMatchIn(t)) return null
        val off = Regex("关|熄|灭").containsMatchIn(t)
        val on = Regex("开|亮").containsMatchIn(t)
        return when {
            off && !on -> Torch(false)
            on -> Torch(true)
            else -> null
        }
    }

    // ---- 倒计时 / 闹钟

    private fun parseDuration(t: String): Int? {
        var sec = 0
        var found = false
        val hh = Regex("($NUM)\\s*个半\\s*(?:小时|钟头)").find(t)
        if (hh != null) {
            cnNum(hh.groupValues[1])?.let { sec += it * 3600 + 1800; found = true }
        } else {
            Regex("($NUM)\\s*(?:个)?\\s*(?:小时|钟头)").find(t)?.let { m ->
                cnNum(m.groupValues[1])?.let { sec += it * 3600; found = true }
            }
            if (Regex("半\\s*(?:个)?\\s*(?:小时|钟头)").containsMatchIn(t)) {
                sec += 1800
                found = true
            }
        }
        Regex("($NUM)\\s*分(?:钟)?").find(t)?.let { m ->
            cnNum(m.groupValues[1])?.let { sec += it * 60; found = true }
        }
        Regex("($NUM)\\s*秒").find(t)?.let { m ->
            cnNum(m.groupValues[1])?.let { sec += it; found = true }
        }
        return if (found && sec > 0) sec else null
    }

    private class Abs(val hour: Int, val minute: Int, val dayText: String, val error: String?, val matched: String)

    private fun parseAbsolute(t: String): Abs? {
        val m = Regex("($NUM)\\s*(?:点钟|点|时|[:：])\\s*(半|一刻|三刻|(?:$NUM)\\s*分?)?").find(t) ?: return null
        val h0 = cnNum(m.groupValues[1]) ?: return null
        val mm = m.groupValues[2].trim()
        val minute = when {
            mm.isEmpty() -> 0
            mm == "半" -> 30
            mm == "一刻" -> 15
            mm == "三刻" -> 45
            else -> cnNum(mm.removeSuffix("分").trim()) ?: return null
        }
        if (h0 > 23 || minute > 59) return null

        val dayWord = when {
            Regex("大后天").containsMatchIn(t) -> 3
            Regex("后天").containsMatchIn(t) -> 2
            Regex("明天|明早|明晨|明晚").containsMatchIn(t) -> 1
            Regex("今天|今早|今晨|今晚").containsMatchIn(t) -> 0
            else -> -1
        }
        val period = when {
            Regex("凌晨").containsMatchIn(t) -> "dawn"
            Regex("半夜|深夜").containsMatchIn(t) -> "midnight"
            Regex("早上|早晨|清晨|上午|明早|今早|明晨|今晨").containsMatchIn(t) -> "am"
            Regex("中午").containsMatchIn(t) -> "noon"
            Regex("下午|傍晚").containsMatchIn(t) -> "pm"
            Regex("晚上|夜里|晚间|今晚|明晚").containsMatchIn(t) -> "eve"
            else -> ""
        }

        val now = Calendar.getInstance()
        fun at(hour: Int, addDays: Int): Calendar {
            val c = now.clone() as Calendar
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_YEAR, addDays)
            return c
        }

        val h24: Int? = when (period) {
            "dawn" -> if (h0 == 12) 0 else h0
            "midnight" -> if (h0 == 12) 0 else h0
            "am" -> h0
            "noon" -> if (h0 in 1..4) h0 + 12 else h0
            "pm" -> if (h0 in 1..11) h0 + 12 else h0
            "eve" -> if (h0 == 12) 0 else if (h0 in 1..11) h0 + 12 else h0
            else -> if (h0 in 1..12) null else h0 // 没说上午下午：1~12 点时间接近哪个就是哪个
        }

        val target: Calendar
        if (h24 != null) {
            var c = at(h24, if (dayWord > 0) dayWord else 0)
            if (dayWord <= 0 && !c.after(now)) {
                if (dayWord == 0) {
                    return Abs(h0, minute, "", "这个时间今天已经过去了", m.value)
                }
                c = at(h24, 1)
            }
            target = c
        } else {
            val a = at(h0 % 12, if (dayWord > 0) dayWord else 0)
            val b = at(h0 % 12 + 12, if (dayWord > 0) dayWord else 0)
            if (dayWord > 0) {
                target = if (a.before(b)) a else b // 明天/后天又没说上下午：默认较早的那个
            } else {
                if (!a.after(now)) a.add(Calendar.DAY_OF_YEAR, 1)
                if (!b.after(now)) b.add(Calendar.DAY_OF_YEAR, 1)
                target = if (a.before(b)) a else b
            }
        }

        val hour = target.get(Calendar.HOUR_OF_DAY)
        val days = daysBetween(now, target)
        val dayText: String
        when {
            days == 0 -> dayText = "今天"
            days == 1 -> {
                // 系统闹钟只能设「下一次会响」的时间，所以明天的时间必须是今天已经过了的时间
                val todayCand = at(hour, 0)
                if (todayCand.after(now)) {
                    return Abs(hour, minute, "", "系统闹钟只能设“下一次会响”的时间，明天的这个时间今天还没到，没法只设明天", m.value)
                }
                dayText = "明天"
            }
            else -> return Abs(hour, minute, "", "系统闹钟只能设“下一次会响”的时间，没法设后天及更远的日子", m.value)
        }
        return Abs(hour, minute, dayText, null, m.value)
    }

    private fun daysBetween(a: Calendar, b: Calendar): Int {
        fun mid(c: Calendar): Long {
            val x = c.clone() as Calendar
            x.set(Calendar.HOUR_OF_DAY, 12)
            x.set(Calendar.MINUTE, 0)
            x.set(Calendar.SECOND, 0)
            x.set(Calendar.MILLISECOND, 0)
            return x.timeInMillis
        }
        return Math.round((mid(b) - mid(a)) / 86400000.0).toInt()
    }

    private val dayPeriodWords = Regex("凌晨|半夜|深夜|早上|早晨|清晨|上午|中午|下午|傍晚|晚上|夜里|晚间|今天|今早|今晨|今晚|明天|明早|明晨|明晚|大后天|后天")

    private val labelStops = listOf(
        "帮我", "给我", "替我", "麻烦", "请", "设置", "创建", "新建", "添加", "定个", "订个", "设个",
        "一个", "一条", "定", "订", "设", "加", "个", "条", "的", "吧", "啊", "呀", "哦", "呢", "吗",
        "闹钟", "倒计时", "后", "再", "，", "。", ",", ".", "！", "!", "？", "?", "、", "：", ":", " "
    )

    /** 去掉两头的口头语和动词（“帮我订一个”“的闹钟”这类），剩下的才是名称 */
    private fun tidyLabel(raw: String): String {
        var s = raw.trim()
        var changed = true
        while (changed && s.isNotEmpty()) {
            changed = false
            for (w in labelStops) {
                if (s.startsWith(w)) {
                    s = s.substring(w.length).trim()
                    changed = true
                }
                if (s.endsWith(w)) {
                    s = s.substring(0, s.length - w.length).trim()
                    changed = true
                }
            }
        }
        return if (s.length in 1..10) s else ""
    }

    /**
     * 提取闹钟/倒计时的名称：
     *  “订一个6点的闹钟” → 没有名称；“订个上班的闹钟” → 上班；“明早7点叫我起床” → 起床；“备注吃药” → 吃药
     */
    private fun cleanLabel(t: String, matched: String): String {
        var s = if (matched.isEmpty()) t else t.replace(matched, " ")
        s = s.replace(dayPeriodWords, " ")

        Regex("(?:备注|标签|名称|名字叫|叫做|名为)[:：是为\\s]*(.+)$").find(s)?.let { m ->
            val l = tidyLabel(m.groupValues[1])
            if (l.isNotEmpty()) return l
        }
        Regex("(?:叫醒我|唤醒我|叫我|喊我|提醒我|通知我|提醒)(.+)$").find(s)?.let { m ->
            val l = tidyLabel(m.groupValues[1])
            if (l.isNotEmpty()) return l
        }
        Regex("(?:定|订|设置|设|创建|新建|添加|加)\\s*(?:一个|个|条|一条)?(.*?)(?:的)?(?:闹钟|倒计时)").find(s)?.let { m ->
            val l = tidyLabel(m.groupValues[1])
            if (l.isNotEmpty()) return l
        }
        Regex("(.+?)(?:的)?(?:闹钟|倒计时)").find(s)?.let { m ->
            val l = tidyLabel(m.groupValues[1])
            if (l.isNotEmpty()) return l
        }
        return ""
    }

    private fun parseTimerOrAlarm(t: String): Action? {
        val timerWord = Regex("倒计时|计时器|计时").containsMatchIn(t)
        val callWord = Regex("叫我|喊我|提醒|闹钟|通知我|唤醒|叫醒").containsMatchIn(t)
        val dur = if (t.contains("后") || timerWord) parseDuration(t) else null
        if (dur != null && (timerWord || callWord)) {
            if (dur > 86400) return Note("用户想定的倒计时超过了 24 小时，没法设置，请告诉用户倒计时最长 24 小时。")
            val label = Regex("($NUM)\\s*(?:个半|个)?\\s*(?:小时|钟头|分钟|分|秒)(?:钟)?|半\\s*(?:个)?\\s*(?:小时|钟头)").replace(t, " ")
            return Timer(dur, cleanLabel(label, ""))
        }
        if (Regex("闹钟|叫我|喊我|叫醒|唤醒|提醒我|提醒").containsMatchIn(t)) {
            val abs = parseAbsolute(t)
            if (abs == null) {
                return if (t.contains("闹钟")) Note("用户想定闹钟，但没有说清楚具体几点，请追问几点。") else null
            }
            if (abs.error != null) {
                return Note("用户想定闹钟，但没法设置：" + abs.error + "。请如实告诉用户，并建议换个说法。")
            }
            return Alarm(abs.hour, abs.minute, cleanLabel(t, abs.matched), abs.dayText)
        }
        return null
    }

    // ---- 找文件

    private class FileType(val name: String, val words: Regex, val exts: Set<String>)

    private val fileTypes = listOf(
        FileType("图片", Regex("图片|照片|相片|截图"), setOf("jpg", "jpeg", "png", "webp", "heic", "gif", "bmp")),
        FileType("视频", Regex("视频|录像|影片"), setOf("mp4", "mkv", "mov", "avi", "webm", "3gp")),
        FileType("音乐", Regex("音乐|歌曲|音频|录音"), setOf("mp3", "flac", "m4a", "wav", "ogg", "aac", "amr")),
        FileType("PDF", Regex("pdf|PDF"), setOf("pdf")),
        FileType("文档", Regex("word|Word|WORD|文档|文稿"), setOf("doc", "docx", "txt", "md", "rtf", "odt")),
        FileType("表格", Regex("表格|excel|Excel|EXCEL"), setOf("xls", "xlsx", "csv")),
        FileType("幻灯片", Regex("ppt|PPT|幻灯片|演示文稿"), setOf("ppt", "pptx")),
        FileType("压缩包", Regex("压缩包|压缩文件"), setOf("zip", "rar", "7z", "tar", "gz")),
        FileType("安装包", Regex("apk|APK|安装包"), setOf("apk"))
    )

    private fun parseFiles(t: String): Action? {
        if (!Regex("找|搜|查找|搜索|查查|翻出").containsMatchIn(t)) return null
        var type: FileType? = null
        for (ft in fileTypes) {
            if (ft.words.containsMatchIn(t)) {
                type = ft
                break
            }
        }
        val generic = Regex("文件|资料|文稿").containsMatchIn(t)
        val personal = Regex("我的|手机|本地|下载|相册|最近|最新|刚才|刚刚|存的|保存的|里的").containsMatchIn(t)
        val strong = type != null && type.name in setOf("PDF", "文档", "表格", "幻灯片", "压缩包", "安装包")
        // “搜索猫的图片”这类更像是上网搜图，没有明确指向手机里的文件就不抢着处理
        if (type == null && !generic) return null
        if (!generic && !personal && !strong) return null

        var s = t
        if (type != null) s = s.replace(type.words, " ")
        s = s.replace(
            Regex("能不能|可不可以|可以|帮我|给我|请你|请|麻烦|你|找一下|找找|找到|查找|搜索|查查|翻出|找|搜|查|一下|手机里面|手机里|手机上|手机|里面|里的|有没有|有|我的|我|最近的|最近|最新的|最新|那个|那份|那张|那些|这个|文件|资料|文稿|个|份|张|些|的|吗|吧|呢|啊|呀"),
            " "
        )
        val kws = s.split(Regex("[\\s，。,.！!？?、和与]+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (kws.isEmpty() && type == null) {
            return Note("用户想找文件，但没说文件名或类型，请追问要找什么。")
        }
        return FindFiles(kws, type?.exts, type?.name ?: "文件")
    }

    // ---- AI 记忆：记住 / 查看 / 忘掉

    private val reRemember = Regex("^.{0,6}?(?:记住|记一下|记下来|记下|记着|你要记得|你要记住|请记得|帮我记|帮我记住)(?:一下|住)?[，,：:\\s]*(.+)$")
    private val reMemList = Regex("你(?:都|现在)?记(?:得|住了?|下了?)(?:些)?(?:什么|哪些|了什么|了哪些)|我的记忆|记忆列表|看看记忆|查看记忆|有哪些记忆|记了什么|记忆有哪些")
    private val reMemClear = Regex("清空(?:所有|全部)?记忆|(?:忘记|忘掉|忘了)(?:所有|全部|一切)(?:的)?(?:事|东西|记忆)?|全部忘掉|把记忆(?:全部)?清空|删除(?:所有|全部)记忆")
    private val reMemNum1 = Regex("(?:删除|删掉|忘记|忘掉|去掉)第($NUM)条(?:记忆)?")
    private val reMemNum2 = Regex("(?:删除|删掉|忘记|忘掉|去掉)记忆(?:第)?($NUM)(?:条)?$")
    private val reForgetKw = Regex("^.{0,6}?(?:忘记|忘掉|忘了|删除记忆|删掉记忆|别记|不要记|不用记)(?:关于)?(.{1,20})$")

    private fun parseMemory(ctx: Context, t: String): Action? {
        // “提醒我记住带钥匙”这类是提醒，不是让她记事
        if (Regex("提醒|叫我|喊我|闹钟|倒计时").containsMatchIn(t)) return null
        // 问“你是我的谁/我们什么关系”：有关系类记忆就必须按记忆回答，不能按好感度等级乱说
        if (Regex("你是我的谁|你是我什么人|我们是什么关系|我们什么关系|咱们什么关系|你我什么关系|我们的关系|你和我是什么关系|你是谁的").containsMatchIn(t)) {
            val rel = if (workMode) emptyList() else AiMemory.relationMemories(ctx)
            if (rel.isNotEmpty()) {
                return Note("用户在问你们之间是什么关系。用户设定的记忆里写着：" + rel.joinToString("；") + "。请严格按这个设定来回答，不要用好感度等级的说法，也不要否认。")
            }
        }
        if (reMemClear.containsMatchIn(t)) {
            val all = AiMemory.load(ctx, scope)
            if (all.isEmpty()) return Note("用户想清空记忆，但其实现在还没有任何记忆。请如实告诉用户。")
            return Forget(all.map { it.id }, all.map { it.text }, true)
        }
        if (reMemList.containsMatchIn(t)) return ListMemory()

        val numM = reMemNum1.find(t) ?: reMemNum2.find(t)
        if (numM != null) {
            val n = cnNum(numM.groupValues[1])
            val all = AiMemory.load(ctx, scope)
            if (n == null || n < 1 || n > all.size) {
                return Note("用户想删除第" + numM.groupValues[1] + "条记忆，但现在只有 " + all.size + " 条记忆，没有这一条。请如实告诉用户。")
            }
            val target = all[n - 1]
            return Forget(listOf(target.id), listOf(target.text), false)
        }

        reRemember.find(t)?.let { m ->
            var c = m.groupValues[1].trim()
            c = c.replace(Regex("(哦|啊|呀|哈|吧|呢|啦)$"), "").trim()
            c = c.trim('。', '.', '！', '!', '，', ',', ' ')
            // 只取要记的那件事，后面夹带的闲聊不记（闲聊部分你照常回应就好）
            val fact = AiMemory.splitFact(c)
            if (fact.length < 2) return Note("用户想让你记住点什么，但没说清楚内容。请追问要记什么。")
            return Remember(fact)
        }

        reForgetKw.find(t)?.let { m ->
            var kw = m.groupValues[1].trim()
            kw = kw.replace(Regex("(了|吧|吗|呀|啊|呢)$"), "").replace(Regex("^(我的|关于|那条|这条)"), "")
                .replace(Regex("(这条|那条)?(的)?记忆$"), "").trim()
            if (kw.length < 2) return null
            val hit = AiMemory.load(ctx, scope).filter { it.text.contains(kw, true) }
            // 只有确实有对应记忆才当成“删除记忆”，避免把“我忘记带钥匙了”之类的闲聊当指令
            if (hit.isNotEmpty()) return Forget(hit.map { it.id }, hit.map { it.text }, false)
        }
        return null
    }

    // ---- 音乐应用：打开并播放

    private class MusicApp(val aliases: List<String>, val label: String, val pkg: String)

    // 顺序也是没指定应用时的优先顺序；“酷狗概念版”必须排在“酷狗”前面
    private val musicApps = listOf(
        MusicApp(listOf("酷狗概念版", "酷狗概念"), "酷狗概念版", "com.kugou.android.lite"),
        MusicApp(listOf("网易云音乐", "网易云", "云音乐"), "网易云音乐", "com.netease.cloudmusic"),
        MusicApp(listOf("qq音乐", "q音"), "QQ音乐", "com.tencent.qqmusic"),
        MusicApp(listOf("酷我音乐", "酷我"), "酷我音乐", "cn.kuwo.player"),
        MusicApp(listOf("酷狗音乐", "酷狗"), "酷狗音乐", "com.kugou.android")
    )
    private val musicDefaultOrder = listOf("com.netease.cloudmusic", "com.tencent.qqmusic", "com.kugou.android", "cn.kuwo.player", "com.kugou.android.lite")

    private fun parseMusic(ctx: Context, t: String): Action? {
        val verb = Regex("播放|放一首|放首|放个|放点|来一首|来首|听一下|听听|听|放歌|放").find(t) ?: return null
        val low = t.lowercase()
        val named = musicApps.firstOrNull { m -> m.aliases.any { low.contains(it) } }
        if (named == null && !Regex("音乐|歌|曲").containsMatchIn(t)) return null

        var q = t.substring(verb.range.last + 1)
        for (m in musicApps) for (a in m.aliases) q = q.replace(a, "", ignoreCase = true)
        q = q.replace(Regex("^(?:一下|一首|首|个|点|些|的|吧|啊|呀|呢|给我|帮我|请|里|上|中|用|在)+"), "")
        q = q.replace(Regex("(?:音乐|歌曲|歌|曲子|的|吧|啊|呀|呢|哦|谢谢|一下|[。.！!？?，,\\s])+$"), "").trim()

        if (named != null) return PlayMusic(named.label, named.pkg, q)
        // 没指定应用：用手机上装了的第一个
        val pm = ctx.packageManager
        for (pkg in musicDefaultOrder) {
            val app = musicApps.first { it.pkg == pkg }
            try {
                if (pm.getLaunchIntentForPackage(pkg) != null) return PlayMusic(app.label, pkg, q)
            } catch (e: Exception) {
            }
        }
        return Note("用户想听歌，但没找到手机上的音乐应用（网易云音乐、QQ音乐、酷狗、酷我、酷狗概念版）。请如实告诉用户，并让用户说明想用哪个应用。")
    }

    // ---- 浏览器搜索 / 打开网址

    private fun enc(s: String): String = java.net.URLEncoder.encode(s, "UTF-8")

    private fun parseBrowse(t: String): Action? {
        // 直接说网址
        val urlM = Regex("(https?://[^\\s，。]+|(?:[a-zA-Z0-9-]+\\.)+(?:com|cn|org|net|io|cc|edu|gov|top|xyz)(?:/[^\\s，。]*)?)").find(t)
        if (urlM != null && Regex("打开|访问|进入|浏览|去").containsMatchIn(t)) {
            var u = urlM.value
            if (!u.startsWith("http")) u = "https://$u"
            return Browse(u, "网页 " + urlM.value)
        }
        if (Regex("^(?:请|帮我|麻烦|你)*打开(?:一下)?浏览器$").containsMatchIn(t)) {
            return Browse("https://www.baidu.com", "浏览器")
        }
        val engine = Regex("百度|必应|[Bb]ing|谷歌|[Gg]oogle").find(t)?.value ?: ""
        val browserWord = Regex("浏览器|上网").containsMatchIn(t)
        if (engine.isEmpty() && !browserWord) return null
        val trig = Regex("搜索一下|搜一下|查一下|找一下|百度一下|必应一下|谷歌一下|搜索|搜|查询|查|找|一下").find(t) ?: return null
        var q = t.substring(trig.range.last + 1)
        q = q.replace(Regex("^[：:，,\\s]+"), "").replace(Regex("[。.！!？?\\s]+$"), "")
        q = q.replace(Regex("(吧|吗|呢|啊|呀)$"), "").trim()
        if (q.isEmpty()) return null
        val low = engine.lowercase()
        return when {
            low == "必应" || low == "bing" -> Browse("https://cn.bing.com/search?q=" + enc(q), "必应搜索「" + q + "」")
            low == "谷歌" || low == "google" -> Browse("https://www.google.com/search?q=" + enc(q), "谷歌搜索「" + q + "」")
            else -> Browse("https://www.baidu.com/s?wd=" + enc(q), "百度搜索「" + q + "」")
        }
    }

    // ---- 发短信 / 发微信、QQ / 打电话（都只打开编辑界面，最后一下由用户自己点）

    private val reSms1 = Regex("^.{0,6}?(?:给|跟|向)(.{1,12}?)发(?:一条|个|条)?(短信|信息|消息)[，,：:\\s]*(?:说|内容是|内容为|写)?(.*)$")
    private val reSms2 = Regex("^.{0,6}?发(?:一条|个|条)?(短信|信息)给(.{1,12}?)[，,：:\\s]*(?:说|内容是|内容为|写)?(.*)$")
    private val reIm1 = Regex("^.{0,6}?给(.{1,12}?)发(微信|QQ|qq)(?:消息)?[，,：:\\s]*(?:说|内容是|内容为)?(.*)$")
    private val reIm2 = Regex("^.{0,6}?发(?:个|条|一条)?(微信|QQ|qq)(?:消息)?[，,：:\\s]*(?:说|内容是|内容为)?(.*)$")
    private val reIm3 = Regex("^.{0,6}?(?:用|通过)(微信|QQ|qq)(?:给(.{1,12}?))?发(?:送)?(?:一条|个|条)?(?:消息)?[，,：:\\s]*(?:说|内容是|内容为)?(.*)$")
    private val reIm4 = Regex("^.{0,6}?把(.+?)(?:发|分享|转发)(?:到|给|至)(微信|QQ|qq)$")
    private val reDial1 = Regex("^.{0,6}?(?:打(?:个)?电话给|拨打|拨号给|呼叫)(.{1,12})$")
    private val reDial2 = Regex("^.{0,6}?给(.{1,12}?)打(?:个)?电话$")
    private val rePhone = Regex("^\\+?[0-9][0-9 \\-]{2,18}$")

    private fun trimBody(s: String): String =
        s.trim().trim('“', '”', '"', '「', '」', '，', '。', ',', ' ').trim()

    private fun cleanName(s: String): String =
        s.trim().replace(Regex("(的|吧|吗|呀|啊|呢)$"), "").trim()

    private fun number(s: String): String? =
        if (rePhone.matches(s.trim())) s.replace(Regex("[ \\-]"), "") else null

    private fun imApp(w: String): Pair<String, String> =
        if (w.equals("QQ", true)) Pair("QQ", "com.tencent.mobileqq") else Pair("微信", "com.tencent.mm")

    private fun parseComm(t: String): Action? {
        reSms1.find(t)?.let { m ->
            val who = cleanName(m.groupValues[1])
            val kind = m.groupValues[2]
            val body = trimBody(m.groupValues[3])
            if (kind == "消息") {
                return Note("用户想给「" + who + "」发消息，但没说用短信、微信还是 QQ。请追问用哪个，并告诉用户你只能帮忙打开编辑界面，最后要用户自己点发送。")
            }
            if (body.isEmpty()) return Note("用户想给「" + who + "」发短信，但没说内容。请追问要发什么内容。")
            return Sms(who, number(who), body)
        }
        reSms2.find(t)?.let { m ->
            val who = cleanName(m.groupValues[2])
            val body = trimBody(m.groupValues[3])
            if (body.isEmpty()) return Note("用户想给「" + who + "」发短信，但没说内容。请追问要发什么内容。")
            return Sms(who, number(who), body)
        }
        reIm1.find(t)?.let { m ->
            val app = imApp(m.groupValues[2])
            val body = trimBody(m.groupValues[3])
            if (body.isEmpty()) return Note("用户想发" + app.first + "消息，但没说内容。请追问要发什么内容。")
            return ShareIm(app.first, app.second, body, cleanName(m.groupValues[1]))
        }
        reIm3.find(t)?.let { m ->
            val app = imApp(m.groupValues[1])
            val body = trimBody(m.groupValues[3])
            if (body.isEmpty()) return Note("用户想发" + app.first + "消息，但没说内容。请追问要发什么内容。")
            return ShareIm(app.first, app.second, body, cleanName(m.groupValues[2]))
        }
        reIm2.find(t)?.let { m ->
            val app = imApp(m.groupValues[1])
            val body = trimBody(m.groupValues[2])
            if (body.isEmpty()) return Note("用户想发" + app.first + "消息，但没说内容。请追问要发什么内容。")
            return ShareIm(app.first, app.second, body, "")
        }
        reIm4.find(t)?.let { m ->
            val app = imApp(m.groupValues[2])
            val body = trimBody(m.groupValues[1])
            if (body.isNotEmpty()) return ShareIm(app.first, app.second, body, "")
        }
        val d = reDial1.find(t)?.groupValues?.get(1) ?: reDial2.find(t)?.groupValues?.get(1)
        if (d != null) {
            val who = cleanName(d)
            if (who.isNotEmpty()) return Dial(who, number(who))
        }
        return null
    }

    // ---- 打开应用

    /** 常用应用：应用列表读不到时的备用打开方式（包名 + 链接协议，协议不需要读取应用列表） */
    private class KnownApp(val aliases: List<String>, val label: String, val pkg: String, val scheme: String)

    private val knownApps = listOf(
        KnownApp(listOf("微信", "wechat"), "微信", "com.tencent.mm", "weixin://"),
        KnownApp(listOf("qq", "腾讯qq"), "QQ", "com.tencent.mobileqq", "mqq://"),
        KnownApp(listOf("支付宝"), "支付宝", "com.eg.android.AlipayGphone", "alipays://platformapi/startapp"),
        KnownApp(listOf("抖音"), "抖音", "com.ss.android.ugc.aweme", "snssdk1128://"),
        KnownApp(listOf("淘宝"), "淘宝", "com.taobao.taobao", "taobao://"),
        KnownApp(listOf("微博"), "微博", "com.sina.weibo", "sinaweibo://"),
        KnownApp(listOf("哔哩哔哩", "b站"), "哔哩哔哩", "tv.danmaku.bili", "bilibili://"),
        KnownApp(listOf("小红书"), "小红书", "com.xingin.xhs", "xhsdiscover://")
    )

    private fun parseOpenApp(ctx: Context, t: String): Action? {
        val m = Regex("^.{0,8}?(?:打开|启动|运行|开启|进入|点开|开一下|开下)\\s*(?:一下|下)?(.{1,14})$").find(t) ?: return null
        var name = m.groupValues[1].trim()
        name = name.replace(Regex("[。.！!？?，,~\\s]+$"), "")
        name = name.replace(Regex("(好吗|可以吗|谢谢|吗|吧|呀|啊|呢|哦|嘛|了)+$"), "")
        name = name.replace(Regex("(这个|那个|应用|软件|程序|app|APP|App)$"), "").trim()
        name = name.replace(Regex("^(我的|那个|这个)"), "").trim()
        if (name.isEmpty() || name.length > 8) return null

        findApp(ctx, name)?.let { return OpenApp(it.first, it.second) }
        val low = name.lowercase()
        for (k in knownApps) {
            if (k.aliases.any { low.contains(it) }) return OpenApp(k.label, k.pkg, k.scheme)
        }
        return Note(
            "用户想打开「" + name + "」，但没能在手机里找到这个应用（可能没安装，也可能系统限制了读取应用列表）。" +
                "请如实说没有打开，绝对不要说已经打开了。"
        )
    }

    private fun findApp(ctx: Context, name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try {
            pm.queryIntentActivities(i, 0)
        } catch (e: Exception) {
            return null
        }
        var contains: Pair<String, String>? = null
        var reverse: Pair<String, String>? = null
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName) continue
            val label = ri.loadLabel(pm).toString()
            if (label.equals(name, true)) return Pair(label, pkg)
            if (contains == null && label.contains(name, true)) contains = Pair(label, pkg)
            // 名字里带了多余的字：取最长的那个应用名
            if (label.length >= 2 && name.contains(label, true) && (reverse == null || label.length > reverse.first.length)) {
                reverse = Pair(label, pkg)
            }
        }
        return contains ?: reverse
    }

    // ------------------------------------------------------------------ 执行
    // 返回值是「真实结果」，会交给模型转述，所以措辞必须和实际情况一致。

    fun execute(ctx: Context, a: Action): String = when (a) {
        is Alarm -> setAlarm(ctx, a)
        is Timer -> setTimer(ctx, a)
        is Torch -> torch(ctx, a.on)
        is OpenApp -> openApp(ctx, a)
        is Browse -> browse(ctx, a)
        is Sms -> sendSms(ctx, a)
        is Dial -> dial(ctx, a)
        is ShareIm -> shareIm(ctx, a)
        is PlayMusic -> playMusic(ctx, a)
        is Remember -> remember(ctx, a)
        is Forget -> forget(ctx, a)
        else -> ""
    }

    private fun setAlarm(ctx: Context, a: Alarm): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, a.minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (a.label.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
        val what = a.dayText + " " + two(a.hour) + ":" + two(a.minute) + " 的闹钟"
        return try {
            ctx.startActivity(i)
            "已经把「" + what + "」的设置请求交给了系统时钟应用（我没法确认它一定成功，请用户到时钟应用里看一眼）。"
        } catch (e: Exception) {
            "没能设置闹钟：手机上没有找到能处理闹钟请求的时钟应用。"
        }
    }

    private fun setTimer(ctx: Context, a: Timer): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (a.label.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
        return try {
            ctx.startActivity(i)
            "已经把「" + durText(a.seconds) + "的倒计时」的设置请求交给了系统时钟应用（我没法确认它一定成功，请用户到时钟应用里看一眼）。"
        } catch (e: Exception) {
            "没能设置倒计时：手机上没有找到能处理倒计时请求的时钟应用。"
        }
    }

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(cid)
                val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val back = ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (flash && back) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                "手机没有可用的闪光灯，没能操作手电筒。"
            } else {
                cm.setTorchMode(id, on)
                if (on) "已经打开了手电筒。" else "已经关掉了手电筒。"
            }
        } catch (e: Exception) {
            "操作手电筒失败了：" + (e.message ?: "未知原因")
        }
    }

    private fun browse(ctx: Context, a: Browse): String {
        return try {
            val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(a.url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "已经请手机用浏览器打开了「" + a.desc + "」（页面内容我看不到，也没法替用户总结）。"
        } catch (e: Exception) {
            "没能打开浏览器：手机上没有找到能打开网页的应用。"
        }
    }

    private fun sendSms(ctx: Context, a: Sms): String {
        val num = a.number ?: return "没能写短信：没有收件人的号码。"
        return try {
            val i = Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:" + android.net.Uri.encode(num)))
            i.putExtra("sms_body", a.body)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "已经打开了短信编辑界面，收件人是「" + a.name + "」，内容已经填好。但短信还没有发出，需要用户自己点发送。"
        } catch (e: Exception) {
            "没能打开短信应用：手机上没有找到能写短信的应用。"
        }
    }

    private fun dial(ctx: Context, a: Dial): String {
        val num = a.number ?: return "没能拨号：没有对方的号码。"
        return try {
            val i = Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + android.net.Uri.encode(num)))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "已经打开了拨号界面并填好「" + a.name + "」的号码。电话还没有拨出，需要用户自己按拨号键。"
        } catch (e: Exception) {
            "没能打开拨号界面：手机上没有找到拨号应用。"
        }
    }

    private fun shareIm(ctx: Context, a: ShareIm): String {
        return try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, a.body)
            i.setPackage(a.pkg)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "已经把内容交给「" + a.app + "」，需要用户自己在里面选择联系人" +
                (if (a.to.isNotEmpty()) "（用户想发给「" + a.to + "」，但我没法替用户选人）" else "") +
                "并点发送。消息还没有发出。"
        } catch (e: Exception) {
            "没能打开「" + a.app + "」：可能没有安装，或者它不支持接收分享的文字。"
        }
    }

    private fun sendMediaPlay(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            val t = android.os.SystemClock.uptimeMillis()
            am.dispatchMediaKeyEvent(android.view.KeyEvent(t, t, android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PLAY, 0))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(t, t, android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PLAY, 0))
        } catch (e: Exception) {
        }
    }

    private fun playMusic(ctx: Context, a: PlayMusic): String {
        val launch = try {
            ctx.packageManager.getLaunchIntentForPackage(a.pkg)
        } catch (e: Exception) {
            null
        }
        if (launch == null) {
            return "没能打开「" + a.label + "」：手机上可能没有安装，或者系统不允许本应用启动它。请如实告诉用户没有打开成功。"
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        if (a.query.isNotEmpty()) {
            // 先试系统标准的“按关键词播放”请求，支持的应用会直接放；不支持就退回打开应用+复制歌名
            try {
                val i = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                i.setPackage(a.pkg)
                i.putExtra(android.app.SearchManager.QUERY, a.query)
                i.putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return "已经向「" + a.label + "」发出了播放「" + a.query + "」的请求。我没法确认它是否真的开始播放、放的是不是这一首，请用户听一下；不对的话需要用户自己在应用里搜索。"
            } catch (e: Exception) {
            }
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("song", a.query))
                ctx.startActivity(launch)
                return "已经打开了「" + a.label + "」，并把「" + a.query + "」复制到了剪贴板。这个应用不支持直接按歌名播放，需要用户自己粘贴搜索再点播放。"
            } catch (e: Exception) {
                return "没能打开「" + a.label + "」：" + (e.message ?: "未知原因")
            }
        }

        return try {
            ctx.startActivity(launch)
            // 应用起来之后发一个“播放”按键，通常会接着上次的列表继续放
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ sendMediaPlay(ctx) }, 2500L)
            "已经打开了「" + a.label + "」，并会过几秒向它发出播放指令（一般是接着上次的播放列表放）。我没法确认它是否真的开始播放，请用户听一下。"
        } catch (e: Exception) {
            "没能打开「" + a.label + "」：" + (e.message ?: "未知原因")
        }
    }

    private fun remember(ctx: Context, a: Remember): String {
        val shown = AiMemory.fixPronouns(a.text, scope)
        return when (AiMemory.add(ctx, a.text, scope)) {
            1 -> "已经把「" + shown + "」记进了记忆（现在一共 " + AiMemory.load(ctx, scope).size + " 条）。如果用户这句话里除了让你记住，还说了别的话，请顺着那句话自然地回应，别只回答“记住了”。"
            0 -> "这件事「" + shown + "」之前已经记过了，不用重复记。"
            -1 -> "记忆已经满了（最多 " + AiMemory.MAX + " 条），没能记下，请告诉用户先删掉一些。"
            else -> "要记的内容太短了，没能记下。"
        }
    }

    private fun forget(ctx: Context, a: Forget): String {
        val n = if (a.clearAll) AiMemory.clear(ctx, scope) else AiMemory.remove(ctx, a.ids.toSet(), scope)
        return if (a.clearAll) "已经清空了全部记忆（共 " + n + " 条），现在什么都不记得了。"
        else "已经忘掉了 " + n + " 条记忆：" + a.texts.joinToString("；")
    }

    private fun openApp(ctx: Context, a: OpenApp): String {
        if (a.pkg.isNotEmpty()) {
            try {
                val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(i)
                    return "已经帮用户打开了「" + a.label + "」。"
                }
            } catch (e: Exception) {
            }
        }
        if (a.scheme.isNotEmpty()) {
            try {
                val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(a.scheme))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return "已经向手机发出了打开「" + a.label + "」的请求。"
            } catch (e: Exception) {
            }
        }
        return "没能打开「" + a.label + "」：手机上可能没有安装，或者系统不允许本应用启动它。请如实告诉用户没有打开成功。"
    }
}

/** 按文件名找文件（需要「所有文件访问」权限，只在用户让她找文件时才会遍历文件名） */
object FileFinder {

    fun hasAccess(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    /** 在手机存储里按文件名找，最新修改的排前面；最多扫 10 秒 */
    fun search(keywords: List<String>, exts: Set<String>?, limit: Int): List<File> {
        val root = Environment.getExternalStorageDirectory()
        val kw = keywords.map { it.lowercase() }
        val out = ArrayList<File>()
        val stack = ArrayList<File>()
        stack.add(root)
        val deadline = System.currentTimeMillis() + 10000L
        var scanned = 0
        while (stack.isNotEmpty() && System.currentTimeMillis() < deadline && scanned < 300000 && out.size < 500) {
            val d = stack.removeAt(stack.size - 1)
            val files = d.listFiles() ?: continue
            for (f in files) {
                scanned++
                val n = f.name
                if (n.startsWith(".")) continue
                if (f.isDirectory) {
                    if (!(d == root && n == "Android")) stack.add(f)
                    continue
                }
                val lower = n.lowercase()
                if (exts != null && lower.substringAfterLast('.', "") !in exts) continue
                if (kw.all { lower.contains(it) }) out.add(f)
            }
        }
        return out.sortedByDescending { it.lastModified() }.take(limit)
    }
}

/** 按名字在通讯录里找号码（需要读取联系人权限，只在用户让她发短信/打电话时才会查） */
object ContactFinder {

    class Hit(val name: String, val number: String)

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun find(ctx: Context, name: String): List<Hit> {
        val out = ArrayList<Hit>()
        val seen = HashSet<String>()
        val c = ctx.contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        c?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: ""
                val num = (it.getString(1) ?: "").replace(Regex("[ \\-]"), "")
                if (num.isEmpty() || !seen.add(num)) continue
                out.add(Hit(n, num))
            }
        }
        // 名字完全一致的排前面
        return out.sortedBy { if (it.name == name) 0 else 1 }.take(5)
    }
}

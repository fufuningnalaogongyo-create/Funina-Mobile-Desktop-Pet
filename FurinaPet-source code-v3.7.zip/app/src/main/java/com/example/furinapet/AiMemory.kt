package com.example.furinapet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * AI 记忆：用户让她「记住」的事。存在本机 ai/memory.json，最多 100 条。
 * 聊天时会把这些记忆放进她的提示词里；也会随「导出配置文件」一起备份。
 */
object AiMemory {

    class Item(val id: Long, val text: String, val ts: Long)

    const val MAX = 100
    const val MAX_LEN = 100

    /** 记忆分区：普通聊天 / 工作模式，各存各的 */
    const val CHAT = "chat"
    const val WORK = "work"

    private fun file(ctx: Context, scope: String = CHAT): File =
        File(LocalAi.dir(ctx), if (scope == WORK) "work_memory.json" else "memory.json")

    /** 表示“关系/身份”的词：记忆里出现这些，就说明用户给你们设定了关系 */
    val relRe = Regex("老婆|妻子|老公|丈夫|恋人|爱人|伴侣|情侣|对象|男朋友|女朋友|夫妻|主人|哥哥|姐姐|弟弟|妹妹|爸爸|妈妈|女儿|儿子|师父|徒弟|搭档|闺蜜|兄弟|姐妹")

    fun relationMemories(ctx: Context): List<String> = load(ctx, CHAT).map { it.text }.filter { relRe.containsMatchIn(it) }

    /**
     * 把用户的口吻改成第三人称：用户说“记住你是我老婆”，存成“芙宁娜是用户的老婆”。
     * 否则模型读到“你是我老婆”时分不清“你”和“我”分别是谁。重复处理也是安全的。
     */
    fun fixPronouns(raw: String, scope: String = CHAT): String {
        var s = raw.trim()
        if (scope == WORK) {
            if (!Regex("[你我]").containsMatchIn(s)) return s
            return s.replace("你们", "助手").replace("我们", "用户和助手").replace("你的", "助手的")
                .replace("我的", "用户的").replace("你", "助手").replace("我", "用户")
        }
        // “她是我老婆”：这里的“她”指正在聊天的芙宁娜
        if (s.startsWith("她") && relRe.containsMatchIn(s)) s = "芙宁娜" + s.substring(1)
        if (!Regex("[你我]").containsMatchIn(s)) return s
        s = s.replace("你们", "芙宁娜").replace("我们", "用户和芙宁娜")
        s = s.replace("你的", "芙宁娜的").replace("我的", "用户的")
        s = s.replace("你", "芙宁娜").replace("我", "用户")
        s = Regex("用户(?=老婆|老公|妻子|丈夫|女朋友|男朋友|恋人|爱人|对象|主人|朋友|哥哥|姐姐|弟弟|妹妹|爸爸|妈妈|家人|女儿|儿子)").replace(s, "用户的")
        return s
    }

    /**
     * 只取“要记住的那件事”，后面夹带的闲聊不要。
     * 例如“你是我老婆，今天天气真好” → “你是我老婆”；“我对芒果过敏，不能吃” → 整句保留（后半句是在补充）。
     */
    fun splitFact(raw: String): String {
        // 先找“你是我老婆 / 我是你老公 / 她是我老婆”这种关系设定：只取这一句，后面（哪怕没标点）夹带的闲聊不要
        val rel = relRe.pattern
        val relCore = Regex("[你她][^，。！？,.!?\\s]{0,8}?(?:是|当|做|成为|当作)我(?:的)?(?:$rel)|我[^，。！？,.!?\\s]{0,8}?(?:是|当|做|成为)[你她](?:的)?(?:$rel)")
        relCore.find(raw)?.let { return it.value.trim() }
        val first = raw.trim().split(Regex("[。！？!?\\n]"))[0].trim()
        val clauses = first.split(Regex("[，,；;]"))
        var out = clauses[0].trim()
        val cont = Regex("^(所以|因为|也就是|就是说|就是|比如|不能|不要|别|不|要|得|只|必须|同时|并且|而且|还要)")
        for (i in 1 until clauses.size) {
            val c = clauses[i].trim()
            if (c.isEmpty()) continue
            if (cont.containsMatchIn(c) && out.length + c.length <= 40) out += "，$c" else break
        }
        return out
    }

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[\\s，。,.！!？?、；;：:“”\"'「」]+"), "")

    fun parse(json: String): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("t", "").trim()
                if (t.isEmpty()) continue
                out.add(Item(o.optLong("i", i.toLong() + 1L), t.take(MAX_LEN), o.optLong("s", 0L)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun toJson(list: List<Item>): String {
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("i", m.id)
            o.put("t", m.text)
            o.put("s", m.ts)
            arr.put(o)
        }
        return arr.toString()
    }

    @Synchronized
    fun load(ctx: Context, scope: String = CHAT): MutableList<Item> {
        val txt = SafeFile.read(file(ctx, scope)) ?: return ArrayList()
        val list = parse(txt)
        // 老记忆里可能还是“你是我老婆”这种第一/第二人称，顺手改成第三人称并存回去
        var changed = false
        val fixed = ArrayList<Item>()
        for (m in list) {
            val t = fixPronouns(m.text, scope).take(MAX_LEN)
            if (t != m.text) changed = true
            fixed.add(Item(m.id, t, m.ts))
        }
        if (changed) save(ctx, fixed, scope)
        return fixed
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Item>, scope: String = CHAT) {
        try {
            SafeFile.write(file(ctx, scope), toJson(list))
        } catch (e: Exception) {
        }
    }

    private fun nextId(list: List<Item>): Long {
        var m = System.currentTimeMillis()
        for (x in list) if (x.id >= m) m = x.id + 1L
        return m
    }

    /** 返回 1=已记住，0=已经记过了，-1=记忆已满，-2=内容为空 */
    @Synchronized
    fun add(ctx: Context, raw: String, scope: String = CHAT): Int {
        val text = fixPronouns(raw, scope).take(MAX_LEN)
        if (text.length < 2) return -2
        val list = load(ctx, scope)
        val n = norm(text)
        if (list.any { norm(it.text) == n }) return 0
        if (list.size >= MAX) return -1
        list.add(Item(nextId(list), text, System.currentTimeMillis()))
        save(ctx, list, scope)
        return 1
    }

    /** 修改一条记忆：1=已修改，0=和别的记忆重复，-2=内容太短，-3=找不到 */
    @Synchronized
    fun update(ctx: Context, id: Long, raw: String, scope: String = CHAT): Int {
        val text = fixPronouns(raw, scope).take(MAX_LEN)
        if (text.length < 2) return -2
        val list = load(ctx, scope)
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return -3
        val n = norm(text)
        for (i in list.indices) {
            if (i != idx && norm(list[i].text) == n) return 0
        }
        list[idx] = Item(id, text, System.currentTimeMillis())
        save(ctx, list, scope)
        return 1
    }

    /** 删除指定 id 的记忆，返回删掉了几条 */
    @Synchronized
    fun remove(ctx: Context, ids: Set<Long>, scope: String = CHAT): Int {
        val list = load(ctx, scope)
        val before = list.size
        list.removeAll { it.id in ids }
        if (list.size != before) save(ctx, list, scope)
        return before - list.size
    }

    @Synchronized
    fun clear(ctx: Context, scope: String = CHAT): Int {
        val n = load(ctx, scope).size
        SafeFile.delete(file(ctx, scope))
        return n
    }

    /** 导入备份时合并：本机已有的不会被删，重复的跳过。返回新增了几条 */
    @Synchronized
    fun mergeFrom(ctx: Context, incoming: List<Item>, scope: String = CHAT): Int {
        val list = load(ctx, scope)
        val seen = HashSet<String>()
        for (x in list) seen.add(norm(x.text))
        var added = 0
        for (m in incoming.sortedBy { it.ts }) {
            if (list.size >= MAX) break
            if (!seen.add(norm(m.text))) continue
            list.add(Item(nextId(list), fixPronouns(m.text, scope), m.ts))
            added++
        }
        if (added > 0) save(ctx, list, scope)
        return added
    }

    /** 放进提示词的记忆（最新的优先，限制总长度，免得小模型被撑爆） */
    fun forPrompt(ctx: Context, scope: String = CHAT): List<String> {
        val items = load(ctx, scope).sortedByDescending { it.ts }
        val out = ArrayList<String>()
        var total = 0
        for (m in items) {
            if (out.size >= 30 || total + m.text.length > 900) break
            out.add(m.text)
            total += m.text.length
        }
        return out
    }
}

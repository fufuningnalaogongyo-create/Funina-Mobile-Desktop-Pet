package com.example.furinapet

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

class GameActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var game = "catch"
    private var lastScore = 0
    private var leveled = false

    // 猜拳状态
    private var win = 0
    private var draw = 0
    private var lose = 0
    private var streak = 0
    private lateinit var herSay: TextView
    private lateinit var versus: TextView
    private lateinit var scoreText: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // 关闭时的页面动画
    override fun finish() {
        super.finish()
        Ui.closeTransition(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        PetService.instance?.setPetVisible(false)
        game = intent.getStringExtra("game") ?: "catch"
        if (game == "rps") buildRps() else buildCatch()
    }

    override fun onDestroy() {
        PetService.instance?.onGameEnd(game, lastScore, leveled)
        super.onDestroy()
    }

    private fun loadSprite(): Bitmap? {
        val o = BitmapFactory.Options()
        o.inSampleSize = 2
        val f = PetService.customImageFile(this)
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.absolutePath, o)
            if (b != null) return b
        }
        return try {
            assets.open("furina.png").use { BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ 接甜点

    private fun buildCatch() {
        val v = CatchView(this, loadSprite(), prefs.getInt(Prefs.BEST_CATCH, 0), object : CatchView.Listener {
            override fun onGameOver(score: Int, newBest: Boolean): Int {
                lastScore = score
                if (newBest) prefs.edit().putInt(Prefs.BEST_CATCH, score).apply()
                val gain = minOf(score / 4, 8)
                if (gain > 0) {
                    val before = Bond.aff(prefs)
                    if (Bond.playAff(prefs, gain)) leveled = true
                    return Bond.aff(prefs) - before
                }
                return 0
            }

            override fun onExit() {
                finish()
            }
        })
        setContentView(v)
    }

    // ------------------------------------------------------------ 猜拳

    private val hands = arrayOf("✊", "✌️", "✋")
    private val handNames = arrayOf("石头", "剪刀", "布")

    private fun buildRps() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(20), dp(40), dp(20), dp(30))
        box.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0B1230.toInt(), 0xFF24449A.toInt())
        )

        val title = TextView(this)
        title.text = "审判猜拳"
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        title.setTextColor(0xFFE5C26B.toInt())
        title.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        box.addView(title)

        herSay = TextView(this)
        herSay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        herSay.setTextColor(0xFFEAF1FF.toInt())
        herSay.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(0xFF121D4A.toInt())
        bg.cornerRadius = dp(18).toFloat()
        bg.setStroke(dp(1), 0x66E5C26B)
        herSay.background = bg
        herSay.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lpS = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpS.topMargin = dp(24)
        box.addView(herSay, lpS)

        versus = TextView(this)
        versus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
        versus.gravity = Gravity.CENTER
        versus.setTextColor(0xFFFFFFFF.toInt())
        versus.text = "❓  VS  ❓"
        val lpV = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpV.topMargin = dp(30)
        box.addView(versus, lpV)

        scoreText = TextView(this)
        scoreText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        scoreText.setTextColor(0xFF9FB0DC.toInt())
        scoreText.gravity = Gravity.CENTER
        scoreText.setPadding(0, dp(14), 0, 0)
        box.addView(scoreText)
        updateScore()

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until 3) {
            val b = Button(this)
            b.text = hands[i] + "\n" + handNames[i]
            b.transformationMethod = null
            b.stateListAnimator = null
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            b.setTextColor(0xFF0B1230.toInt())
            val g = GradientDrawable()
            g.setColor(0xFFE5C26B.toInt())
            g.cornerRadius = dp(20).toFloat()
            b.background = g
            val idx = i
            b.setOnClickListener { playRound(idx) }
            val lp = LinearLayout.LayoutParams(0, dp(96), 1f)
            lp.leftMargin = dp(5)
            lp.rightMargin = dp(5)
            row.addView(b, lp)
        }
        val lpR = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpR.topMargin = dp(36)
        box.addView(row, lpR)

        val back = Button(this)
        back.text = "返回"
        back.transformationMethod = null
        back.stateListAnimator = null
        back.setTextColor(0xFFE5C26B.toInt())
        val bg2 = GradientDrawable()
        bg2.setColor(0)
        bg2.cornerRadius = dp(22).toFloat()
        bg2.setStroke(dp(1), 0x99E5C26B.toInt())
        back.background = bg2
        back.setOnClickListener { finish() }
        val lpB = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lpB.topMargin = dp(30)
        box.addView(back, lpB)

        setContentView(box)
        val s = Lines.pick(prefs, "rps_start", Prefs.name(prefs)) ?: "来一局吧！"
        herSay.text = s
        PetService.instance?.voiceSay("rps_start", s)
    }

    private fun updateScore() {
        scoreText.text = "胜 " + win + "  ·  平 " + draw + "  ·  负 " + lose + "      连胜 " + streak
    }

    private fun playRound(p: Int) {
        val c = Random.nextInt(3)
        versus.text = hands[p] + "  VS  " + hands[c]
        val diff = (p - c + 3) % 3
        val key: String
        if (diff == 0) {
            draw++
            key = "rps_draw"
        } else if (diff == 2) {
            win++
            streak++
            key = "rps_win"
        } else {
            lose++
            streak = 0
            key = "rps_lose"
        }
        updateScore()
        val s = Lines.pick(prefs, key, Prefs.name(prefs)) ?: ""
        herSay.text = s
        PetService.instance?.voiceSay(key, s)
        if (Bond.playAff(prefs, 1)) leveled = true
    }
}

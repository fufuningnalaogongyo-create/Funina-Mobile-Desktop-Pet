package com.example.furinapet

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.io.File
import java.util.Locale
import kotlin.random.Random

/**
 * 语音：优先播放用户为该场景导入的音频，没有就用系统自带的中文语音朗读。
 * 系统朗读不是任何角色的原声，只是手机的通用中文语音。
 */
class VoicePlayer(private val ctx: Context, private val prefs: SharedPreferences) :
    TextToSpeech.OnInitListener {

    companion object {
        fun dir(ctx: Context, key: String): File = File(ctx.filesDir, "voice/" + key)

        fun files(ctx: Context, key: String): List<File> {
            val fs = dir(ctx, key).listFiles() ?: return emptyList()
            return fs.filter { it.isFile }.sortedBy { it.name }
        }

        fun count(ctx: Context, key: String): Int = files(ctx, key).size

        fun clear(ctx: Context, key: String) {
            for (f in files(ctx, key)) f.delete()
        }

        fun importFile(ctx: Context, key: String, uri: Uri): Boolean {
            try {
                val d = dir(ctx, key)
                d.mkdirs()
                if (count(ctx, key) >= 10) return false
                val out = File(d, System.nanoTime().toString() + ".snd")
                val input = ctx.contentResolver.openInputStream(uri) ?: return false
                input.use { src ->
                    out.outputStream().use { dst -> src.copyTo(dst) }
                }
                if (out.length() > 6L * 1024L * 1024L) {
                    out.delete()
                    return false
                }
                return true
            } catch (e: Exception) {
                return false
            }
        }
    }

    private var tts: TextToSpeech? = null
    private var ready = false
    private var player: MediaPlayer? = null

    init {
        try {
            tts = TextToSpeech(ctx, this)
        } catch (e: Exception) {
            tts = null
        }
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            val r = t.setLanguage(Locale.SIMPLIFIED_CHINESE)
            ready = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED)
        }
    }

    private fun volume(): Float = prefs.getInt(Prefs.VOICE_VOL, 100) / 100f

    fun speak(key: String, text: String) {
        if (!prefs.getBoolean(Prefs.VOICE_ON, false)) return
        val mode = prefs.getInt(Prefs.VOICE_MODE, 0) // 0 自定义优先+朗读, 1 只播自定义, 2 只朗读
        stop()
        if (mode != 2 && key.isNotEmpty()) {
            if (playCustom(key)) return
        }
        if (mode == 1) return
        speakTts(text)
    }

    private fun playCustom(key: String): Boolean {
        val fs = files(ctx, key)
        if (fs.isEmpty()) return false
        val f = fs[Random.nextInt(fs.size)]
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            val v = volume()
            mp.setVolume(v, v)
            mp.setOnCompletionListener { m ->
                try {
                    m.release()
                } catch (e: Exception) {
                }
                if (player === m) player = null
            }
            mp.start()
            player = mp
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun clean(s: String): String {
        var t = s.replace(Regex("[（(][^）)]*[）)]"), "")
        t = t.replace(Regex("[♪♥~～「」『』]"), "")
        t = t.replace(Regex("[\\x{1F000}-\\x{1FFFF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}]"), "")
        return t.trim()
    }

    private fun speakTts(text: String) {
        val t = tts ?: return
        if (!ready) return
        val c = clean(text)
        if (c.isEmpty()) return
        t.setSpeechRate(prefs.getInt(Prefs.VOICE_RATE, 100) / 100f)
        t.setPitch(prefs.getInt(Prefs.VOICE_PITCH, 110) / 100f)
        val params = Bundle()
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume())
        t.speak(c, TextToSpeech.QUEUE_FLUSH, params, "furina_line")
    }

    /** 播放语音包里的一段音频（不受「语音开关」限制，音量沿用语音音量） */
    fun playFile(f: File): Boolean {
        stop()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            val v = volume()
            mp.setVolume(v, v)
            mp.setOnCompletionListener { m ->
                try {
                    m.release()
                } catch (e: Exception) {
                }
                if (player === m) player = null
            }
            mp.start()
            player = mp
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
        val p = player
        player = null
        if (p != null) {
            try {
                p.stop()
            } catch (e: Exception) {
            }
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
    }
}

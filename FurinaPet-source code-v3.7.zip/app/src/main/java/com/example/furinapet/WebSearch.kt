package com.example.furinapet

import android.content.SharedPreferences
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset
import java.util.Locale

/**
 * 可选的联网搜索（默认关闭，需要网络）。
 *
 * 流程：整理关键词 → 多个搜索引擎取结果并合并去重 → 按和问题的相关度排序 →
 * （聊天用 searchDeep）再把排名靠前的几个网页真的打开，挑出和问题最相关的几段正文，
 * 这样模型拿到的是网页里的内容，而不只是搜索结果页上被截断的一两句摘要。
 */
object WebSearch {

    class Hit(val title: String, val text: String, val url: String = "") {
        /** 从网页里挑出来的相关正文（没抓到就是空，只用 text 里的搜索摘要） */
        @Volatile
        var body: String = ""

        @Volatile
        var score: Int = 0

        fun best(): String = if (body.isNotEmpty()) body else text
    }

    private const val UA = "FurinaPet/3.1 (Android desktop pet)"
    private const val MAX_BYTES = 600 * 1024
    private const val PAGE_MAX_BYTES = 700 * 1024

    // ------------------------------------------------------------------ 关键词整理

    /** 句首的客套话 / 指令词（“请问”“帮我”“麻烦你”……） */
    private val leadFiller = Regex(
        "^(?:请问一下|请问|请你|请|麻烦你|麻烦|劳驾|帮我|帮忙|帮个忙|给我|替我|你能不能|你可以|你能|能不能|可不可以|可以|能否|" +
            "能告诉我|能帮我|能给我|我想知道|我想要|我想问一下|我想问|我想|我要|我需要|告诉我|跟我说说|跟我讲讲|说说|讲讲|讲一讲|讲一下|介绍一下|介绍下|" +
            "那你|那请|那么|那就|然后|对了|嗯|哦|啊|呃|喂|诶|哎|就是|你知道|你了解|你听说过|你知不知道)+[，,、\\s]*"
    )

    /** “搜索一下”“查查”这类动作词 */
    private val cmdVerb = Regex(
        "^(?:联网)?(?:搜索一下|搜索下|搜索|搜一下|搜一搜|搜搜|搜|查一下|查一查|查查|查询一下|查询|查找|查|找一下|找一找|找找|找|看一下|看看|了解一下|了解下|了解)[，,:：、\\s]*"
    )

    /** 句尾的语气词 / 问法 */
    private val tailFiller = Regex(
        "(?:是什么意思|是什么|是谁|是啥|吗|呢|吧|啊|呀|哦|嘛|么|哈|啦|呗|告诉我|给我|一下|看看)+[?？!！。.…~～，,\\s]*$"
    )

    private val stopTerms = setOf(
        "怎么", "什么", "如何", "一下", "可以", "有没", "没有", "这个", "那个", "我们", "你们", "他们",
        "的话", "为什", "什么样", "应该", "是不", "不是", "还是", "或者", "以及", "然后", "因为", "所以"
    )

    /** 去掉“搜索一下……是什么”之类的口头语，留下关键词 */
    fun cleanQuery(msg: String): String {
        var q = msg.trim()
        var prev: String
        var n = 0
        do {
            prev = q
            q = leadFiller.replace(q, "")
            q = cmdVerb.replace(q, "")
            n++
        } while (q != prev && n < 5)
        q = q.replace("关于", " ").replace("有关", " ")
        q = Regex("的?相关(?:信息|资料|内容|消息)").replace(q, " ")
        q = tailFiller.replace(q, "")
        q = q.replace(Regex("[，,。！!？?；;、]+"), " ")
        q = q.replace(Regex("\\s+"), " ").trim()
        if (q.isEmpty()) q = msg.trim()
        return if (q.length > 50) q.substring(0, 50) else q
    }

    /**
     * 用户这句话生成最终的搜索词。追问（“它的配队呢”“那个怎么打”）本身关键词太少，
     * 就把上一个问题的关键词带上，不然搜出来全是无关的东西。
     * @param prevUser 之前用户说过的话（旧的在前）
     */
    fun buildQuery(msg: String, prevUser: List<String> = emptyList()): String {
        val q = cleanQuery(msg)
        val pron = Regex("^(?:它们|他们|她们|它|他|她|其|该|此|这个|那个|这款|那款)")
        val followUp = q.length <= 3 || (q.length <= 14 && pron.containsMatchIn(q))
        if (!followUp || prevUser.isEmpty()) return q
        val prev = cleanQuery(prevUser.last())
        if (prev.isEmpty() || prev == q) return q
        val core = pron.replace(q, "").trimStart('的', ' ').trim()
        val merged = (prev.take(24) + " " + core).trim()
        return if (merged.length > 50) merged.substring(0, 50) else merged
    }

    /** 搜不到时的“精简版”关键词：只留前面最关键的部分 */
    private fun shorter(q: String): String {
        val parts = q.split(' ').filter { it.isNotEmpty() }
        val s = if (parts.size >= 3) parts.take(2).joinToString(" ") else if (q.length > 10) q.substring(0, 10) else q
        return s
    }

    /** 问题里的关键词（英文数字词 + 中文双字词），用来给搜索结果和网页段落打相关度分 */
    fun queryTerms(q: String): Set<String> {
        val out = LinkedHashSet<String>()
        val lower = q.lowercase(Locale.ROOT)
        for (m in Regex("[a-z0-9][a-z0-9.+#-]*").findAll(lower)) {
            if (m.value.length >= 2) out.add(m.value)
        }
        // 先在“的、了、在、是、怎、么……”这些虚词处断开，免得出现“丹的”“的圣”这种跨词的无意义组合
        val cjkOnly = lower.replace(Regex("[的了在是和与及或吗呢吧啊呀怎么什能就都也还把被给让对从向到为个这那你我他她它有告诉]"), " ")
        for (m in Regex("[\\u4e00-\\u9fff]+").findAll(cjkOnly)) {
            val r = m.value
            if (r.length in 2..4) out.add(r)
            for (i in 0 until r.length - 1) {
                val bi = r.substring(i, i + 2)
                if (bi !in stopTerms) out.add(bi)
            }
        }
        return out
    }

    private fun relevance(text: String, terms: Set<String>): Int {
        if (terms.isEmpty() || text.isEmpty()) return 0
        val t = text.lowercase(Locale.ROOT)
        var n = 0
        for (w in terms) if (t.contains(w)) n++
        return n
    }

    /** 最近一次成功用到的来源，用来在界面上提示 */
    @Volatile
    var lastSource = ""
        private set

    class Engine(val id: String, val label: String)

    val engines = listOf(
        Engine("auto", "自动（推荐）"),
        Engine("bing", "必应（国内版）"),
        Engine("baidu", "百度"),
        Engine("so360", "360 搜索"),
        Engine("sogou", "搜狗"),
        Engine("bocha", "博查搜索 API（需要 Key，最稳定）"),
        Engine("searx", "自定义 SearXNG"),
        Engine("wiki", "中文维基百科（国内可能打不开）")
    )

    fun engineLabel(id: String): String = engines.firstOrNull { it.id == id }?.label ?: engines[0].label

    // ------------------------------------------------------------------ 搜索（只要搜索结果）

    private fun runEngine(e: String, key: String, custom: String, q: String): List<Hit> = when (e) {
        "bocha" -> {
            if (key.isEmpty()) throw IOException("还没有填 API Key")
            bocha(key, q)
        }
        "searx" -> {
            if (custom.isEmpty()) throw IOException("还没有填自定义接口地址")
            searx(custom, q)
        }
        "bing" -> bing(q)
        "baidu" -> baidu(q)
        "so360" -> so360(q)
        "sogou" -> sogou(q)
        else -> wikipedia(q)
    }

    /**
     * 按设置里选的搜索引擎搜索。选“自动”时：有博查 Key 先用博查；否则依次试 必应 → 百度 → 360 → 搜狗，
     * 把前几个引擎的结果合并、去重、按相关度排序（单个引擎结果太少或解析不到时，别的引擎来补）；
     * 都没有才退到维基。全部失败会抛异常（带上每个来源的失败原因）；搜到 0 条返回空列表。
     * 这个函数只返回搜索结果里的标题 / 摘要 / 网址；要网页正文用 searchDeep。
     */
    fun search(p: SharedPreferences, query: String): List<Hit> {
        val id = p.getString(Prefs.AI_ENGINE, "auto") ?: "auto"
        val key = (p.getString(Prefs.AI_BOCHA_KEY, "") ?: "").trim()
        val custom = (p.getString(Prefs.AI_SEARX_URL, "") ?: "").trim()
        val auto = id == "auto"
        val order = ArrayList<String>()
        if (auto) {
            if (key.isNotEmpty()) order.add("bocha")
            if (custom.isNotEmpty()) order.add("searx")
            order.addAll(listOf("bing", "baidu", "so360", "sogou", "wiki"))
        } else {
            order.add(id)
        }
        val terms = queryTerms(query)
        val t0 = System.currentTimeMillis()
        val merged = ArrayList<Hit>()
        val used = ArrayList<String>()
        val errors = ArrayList<String>()
        var anyOk = false
        for (e in order) {
            if (auto && e == "wiki" && merged.isNotEmpty()) continue
            if (auto && merged.isNotEmpty() && System.currentTimeMillis() - t0 > 22000L) break
            val label = engineLabel(e).substringBefore("（")
            try {
                var r = runEngine(e, key, custom, query)
                if (r.isEmpty()) {
                    // 整句搜不到：换成精简的关键词再试一次
                    val alt = shorter(query)
                    if (alt != query && alt.length >= 2) r = runEngine(e, key, custom, alt)
                }
                anyOk = true
                if (r.isEmpty()) {
                    errors.add(label + "：没有解析到结果")
                    continue
                }
                addDedup(merged, r)
                used.add(label)
                if (!auto) break
                if (e == "bocha") break
                if (goodCount(merged, terms) >= 6 || used.size >= 3) break
            } catch (ex: Exception) {
                errors.add(label + "：" + describe(ex))
            }
        }
        if (merged.isEmpty()) {
            if (!anyOk) throw IOException(errors.joinToString("；"))
            lastSource = ""
            return emptyList()
        }
        lastSource = used.joinToString("＋")
        return rank(merged, terms).take(8)
    }

    private fun goodCount(hits: List<Hit>, terms: Set<String>): Int {
        if (terms.isEmpty()) return hits.size
        var n = 0
        for (h in hits) if (relevance(h.title + " " + h.text, terms) > 0) n++
        return n
    }

    private fun urlKey(h: Hit): String {
        if (h.url.isBlank()) return "t:" + h.title.take(24)
        return try {
            val u = URL(h.url)
            (u.host + u.path).lowercase(Locale.ROOT).trimEnd('/')
        } catch (e: Exception) {
            h.url
        }
    }

    private fun addDedup(into: MutableList<Hit>, more: List<Hit>) {
        val seen = HashSet<String>()
        for (h in into) seen.add(urlKey(h))
        for (h in more) if (seen.add(urlKey(h))) into.add(h)
    }

    /** 靠谱的资料站（百科、游戏攻略站、官方文档）加一点分 */
    private val goodHosts = listOf(
        "baike.baidu.com", "wikipedia.org", "biligame.com", "gamersky.com", "ali213.net", "3dmgame.com",
        "nga.cn", "miyoushe.com", "mihoyo.com", "github.com", "gov.cn", "zhihu.com", "jingyan.baidu.com"
    )

    private val lowValueHosts = listOf(
        "douyin.com", "wenku.baidu.com", "docin.com", "doc88.com", "kuaishou.com", "youku.com", "iqiyi.com",
        "xiaohongshu.com", "weibo.com", "weibo.cn", "toutiao.com", "baijiahao.baidu.com", "mbd.baidu.com"
    )

    private fun hostOf(url: String): String = try {
        URL(url).host.lowercase(Locale.ROOT)
    } catch (e: Exception) {
        ""
    }

    private fun rank(hits: List<Hit>, terms: Set<String>): List<Hit> {
        for (h in hits) {
            var s = relevance(h.title, terms) * 3 + relevance(h.text, terms) * 2
            val host = hostOf(h.url)
            if (host.isNotEmpty() && goodHosts.any { host.endsWith(it) }) s += 2
            // 视频页 / 文库 / 短视频这类，打开也读不到正文，当参考来源也没用，往后排
            if (host.isNotEmpty() && lowValueHosts.any { host.endsWith(it) }) s -= 4
            h.score = s
        }
        val sorted = hits.sortedByDescending { it.score }
        // 和问题完全无关的结果去掉（至少留 3 条，免得全删光）
        if (terms.size >= 2) {
            val keep = sorted.filter { it.score > 0 }
            if (keep.size >= 3) return keep
        }
        return sorted
    }

    private fun describe(e: Exception): String = when (e) {
        is java.net.UnknownHostException -> "连不上服务器（没网或被屏蔽）"
        is java.net.SocketTimeoutException -> "连接超时"
        is javax.net.ssl.SSLException -> "安全连接失败"
        else -> e.message ?: e.javaClass.simpleName
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun http(url: String, ua: String = UA, accept: String = "application/json"): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", accept)
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.5")
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val out = ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192)
                while (true) {
                    val r = ins.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    if (out.size() > MAX_BYTES) break
                }
            }
            return String(out.toByteArray(), Charsets.UTF_8)
        } finally {
            c.disconnect()
        }
    }

    private fun short(s: String, n: Int): String {
        val t = s.replace(Regex("\\s+"), " ").trim()
        return if (t.length > n) t.substring(0, n) + "…" else t
    }

    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** 必应用 Edge 的身份访问：和电脑上用 Edge 搜到的页面一致，结果最完整 */
    private const val EDGE_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"

    private fun decodeEntities(h: String): String {
        var t = h.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&ensp;", " ").replace("&emsp;", " ")
            .replace("&amp;", "&")
        t = Regex("&#(\\d+);").replace(t) { m ->
            val n = m.groupValues[1].toIntOrNull()
            if (n != null && n in 32..0xFFFF) n.toChar().toString() else ""
        }
        return t
    }

    private fun stripHtml(h: String): String {
        val t = decodeEntities(h.replace(Regex("<[^>]*>"), ""))
        return t.replace(Regex("\\s+"), " ").trim()
    }

    /** 必应的结果链接有时是跳转链接（/ck/a?...&u=a1<base64>），还原成真实网址；还原不了就只在是普通 http 链接时才用 */
    private fun realUrl(raw: String): String {
        val href = raw.replace("&amp;", "&").trim()
        if (href.contains("/ck/a?")) {
            val u = Regex("[?&]u=a1([A-Za-z0-9_\\-]+)").find(href)?.groupValues?.get(1)
            if (u != null) {
                try {
                    val b = android.util.Base64.decode(u, android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP)
                    val r = String(b, Charsets.UTF_8)
                    if (r.startsWith("http")) return r
                } catch (e: Exception) {
                }
            }
            return ""
        }
        return if (href.startsWith("http")) href else ""
    }

    // ------------------------------------------------------------------ 必应

    /** 结果块的起点。注意 class 里常常不止 b_algo 一个（比如 "b_algo b_vtl"），不能只匹配 class="b_algo" */
    private val bingBlock = Regex("<li[^>]*class=\"[^\"]*\\bb_algo\\b[^\"]*\"[^>]*>", RegexOption.IGNORE_CASE)

    private fun bingParse(html: String): List<Hit> {
        val out = ArrayList<Hit>()
        val parts = bingBlock.split(html)
        val opt = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        val reTitle = Regex("<h2[^>]*>.*?<a[^>]*?href=\"([^\"]*)\"[^>]*>(.*?)</a>", opt)
        val reAnyA = Regex("<a[^>]*?href=\"(https?://[^\"]*)\"[^>]*>(.*?)</a>", opt)
        val snipRes = listOf(
            Regex("<p[^>]*class=\"[^\"]*b_lineclamp[^\"]*\"[^>]*>(.*?)</p>", opt),
            Regex("<div[^>]*class=\"[^\"]*b_caption[^\"]*\"[^>]*>.*?<p[^>]*>(.*?)</p>", opt),
            Regex("<div[^>]*class=\"[^\"]*b_(?:snippet|lineclamp)[^\"]*\"[^>]*>(.*?)</div>", opt),
            Regex("<p[^>]*>(.*?)</p>", opt)
        )
        for (i in 1 until parts.size) {
            if (out.size >= 8) break
            val b = parts[i].take(6000)
            val tm = reTitle.find(b) ?: reAnyA.find(b) ?: continue
            val title = stripHtml(tm.groupValues[2])
            if (title.length < 2) continue
            val url = realUrl(tm.groupValues[1])
            var snip = ""
            for (re in snipRes) {
                val m = re.find(b) ?: continue
                val t = stripHtml(m.groupValues[1])
                if (t.length >= 8) {
                    snip = t
                    break
                }
            }
            if (snip.isEmpty()) snip = stripHtml(b.substring(tm.range.last + 1)).take(240)
            out.add(Hit(short(title, 60), short(snip.ifEmpty { title }, 260), url))
        }
        return out
    }

    private fun looksBlocked(html: String): Boolean {
        if (html.length > 60000) return false
        return Regex("验证码|安全验证|人机验证|captcha|访问过于频繁|unusual traffic", RegexOption.IGNORE_CASE).containsMatchIn(html)
    }

    /** 抓必应网页版搜索结果（没有官方免费接口）。国内版结果少 / 解析不到时，再试国际版 */
    private fun bing(query: String): List<Hit> {
        var best: List<Hit> = emptyList()
        var err: Exception? = null
        for (host in listOf("https://cn.bing.com", "https://www.bing.com")) {
            try {
                val html = http(
                    host + "/search?q=" + enc(query) + "&setlang=zh-Hans&mkt=zh-CN&count=10",
                    EDGE_UA, "text/html,application/xhtml+xml"
                )
                val r = bingParse(html)
                if (r.size >= 3) return r
                if (r.size > best.size) best = r
                if (r.isEmpty() && looksBlocked(html)) err = IOException("必应要求验证（被识别为机器人）")
            } catch (e: Exception) {
                err = e
            }
        }
        val e = err
        if (best.isEmpty() && e != null) throw e
        return best
    }

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    private fun decodeAmp(s: String): String = s.replace("&amp;", "&").trim()

    /**
     * 通用的搜索结果网页解析：按 blockStart 把页面切成一条条结果，取每条里第一个链接的文字当标题，
     * 真实网址优先用 realUrl（页面里藏的原始地址），否则用普通 http 链接；摘要优先用 snippetRe，不行就取标题后面的文字。
     */
    private fun genericHits(html: String, blockStart: Regex, realUrl: Regex?, snippetRe: Regex?, skipHost: String): List<Hit> {
        val out = ArrayList<Hit>()
        val parts = blockStart.split(html)
        val opt = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        val reA = Regex("<a[^>]*?href=\"([^\"]*)\"[^>]*>(.*?)</a>", opt)
        for (i in 1 until parts.size) {
            if (out.size >= 6) break
            val b = parts[i].take(4000)
            val a = reA.find(b) ?: continue
            val title = stripHtml(a.groupValues[2])
            if (title.length < 2) continue
            var url = realUrl?.find(b)?.groupValues?.get(1)?.let { decodeAmp(it) } ?: ""
            if (!url.startsWith("http")) {
                url = ""
                val h = decodeAmp(a.groupValues[1])
                if (h.startsWith("http") && !h.contains(skipHost)) url = h
            }
            val rest = b.substring(a.range.last + 1)
            var snip = snippetRe?.find(rest)?.groupValues?.get(1)?.let { stripHtml(it) } ?: ""
            if (snip.length < 8) snip = stripHtml(rest).take(240)
            if (snip.length < 8) continue
            out.add(Hit(short(title, 60), short(snip, 260), url))
        }
        return out
    }

    /** 百度网页版（抓取，可能遇到“安全验证”） */
    private fun baidu(query: String): List<Hit> {
        val html = http("https://www.baidu.com/s?rn=10&wd=" + enc(query), DESKTOP_UA, "text/html,application/xhtml+xml")
        if (html.contains("wappass.baidu.com") || html.contains("百度安全验证")) {
            throw IOException("百度要求安全验证（被识别为机器人），请换别的引擎")
        }
        // 每条自然结果的容器上有 mu="真实网址"，以它为切分点，真实网址就在每一块的开头
        var r = genericHits(html, Regex("<div[^>]*?\\bmu=\""), Regex("^(https?://[^\"]+)\""), null, "baidu.com")
        if (r.isEmpty()) r = genericHits(html, Regex("<h3[^>]*>", RegexOption.IGNORE_CASE), null, null, "baidu.com")
        return r
    }

    /** 360 搜索网页版（抓取） */
    private fun so360(query: String): List<Hit> {
        val html = http("https://www.so.com/s?q=" + enc(query), DESKTOP_UA, "text/html,application/xhtml+xml")
        var r = genericHits(
            html, Regex("<li[^>]*class=\"res-list[^\"]*\"[^>]*>", RegexOption.IGNORE_CASE),
            Regex("data-mdurl=\"([^\"]+)\""), Regex("<p[^>]*class=\"res-desc[^\"]*\"[^>]*>(.*?)</p>", setOf(RegexOption.DOT_MATCHES_ALL)), "so.com"
        )
        if (r.isEmpty()) r = genericHits(html, Regex("<h3[^>]*class=\"res-title[^\"]*\"[^>]*>", RegexOption.IGNORE_CASE), Regex("data-mdurl=\"([^\"]+)\""), null, "so.com")
        return r
    }

    /** 搜狗网页版（抓取；结果链接是跳转链接，所以拿不到真实网址，只有标题和摘要） */
    private fun sogou(query: String): List<Hit> {
        val html = http("https://www.sogou.com/web?query=" + enc(query), DESKTOP_UA, "text/html,application/xhtml+xml")
        if (html.contains("antispider") || html.contains("用户您好，我们的系统检测到您的网络环境")) {
            throw IOException("搜狗要求验证（被识别为机器人），请换别的引擎")
        }
        var r = genericHits(html, Regex("<div[^>]*class=\"(?:vrwrap|rb)[^\"]*\"[^>]*>", RegexOption.IGNORE_CASE), null, null, "sogou.com")
        if (r.isEmpty()) r = genericHits(html, Regex("<h3[^>]*>", RegexOption.IGNORE_CASE), null, null, "sogou.com")
        return r
    }

    /** 博查搜索 API（国内的 AI 搜索接口，需要自己在开放平台申请 Key；比抓网页稳定） */
    private fun bocha(key: String, query: String): List<Hit> {
        val body = JSONObject()
            .put("query", query)
            .put("freshness", "noLimit")
            .put("summary", true)
            .put("count", 8)
            .toString()
        val resp = JSONObject(postJson("https://api.bochaai.com/v1/web-search", key, body))
        val code = resp.optInt("code", 200)
        if (code != 200) throw IOException(resp.optString("msg", "博查返回错误 $code"))
        val arr = resp.optJSONObject("data")?.optJSONObject("webPages")?.optJSONArray("value") ?: return emptyList()
        val out = ArrayList<Hit>()
        var i = 0
        while (i < arr.length() && out.size < 8) {
            val o = arr.optJSONObject(i)
            i++
            if (o == null) continue
            val text = o.optString("summary", "").ifBlank { o.optString("snippet", "") }
            if (text.isBlank()) continue
            out.add(Hit(short(o.optString("name", ""), 60), short(text, 400), o.optString("url", "")))
        }
        return out
    }

    private fun postJson(url: String, bearer: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Authorization", "Bearer $bearer")
            c.setRequestProperty("Accept", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            if (code !in 200..299) {
                throw IOException("HTTP $code" + (if (text.isNotEmpty()) "：" + text.take(120) else ""))
            }
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun wikipedia(query: String): List<Hit> {
        val u = "https://zh.wikipedia.org/w/api.php?action=query&format=json&utf8=1" +
            "&generator=search&gsrlimit=4&prop=extracts&exintro=1&explaintext=1&exsentences=4&exlimit=max" +
            "&gsrsearch=" + enc(query)
        val pages = JSONObject(http(u)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val rows = ArrayList<Triple<Int, String, String>>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val o = pages.optJSONObject(keys.next()) ?: continue
            val extract = o.optString("extract", "")
            if (extract.isBlank()) continue
            rows.add(Triple(o.optInt("index", 99), o.optString("title", ""), extract))
        }
        rows.sortBy { it.first }
        val out = ArrayList<Hit>()
        for (r in rows) {
            out.add(Hit(r.second, short(r.third, 320), "https://zh.wikipedia.org/wiki/" + enc(r.second.replace(' ', '_')).replace("+", "%20")))
        }
        return out
    }

    private fun searx(base: String, query: String): List<Hit> {
        val b = base.trim().trimEnd('/')
        if (!b.startsWith("https://")) throw IOException("搜索接口需要 https 地址")
        val u = b + "/search?format=json&language=zh-CN&q=" + enc(query)
        val arr = JSONObject(http(u)).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Hit>()
        var i = 0
        while (i < arr.length() && out.size < 8) {
            val o = arr.optJSONObject(i)
            i++
            if (o == null) continue
            val content = o.optString("content", "")
            if (content.isBlank()) continue
            out.add(Hit(short(o.optString("title", ""), 60), short(content, 260), o.optString("url", "")))
        }
        return out
    }

    // ------------------------------------------------------------------ 打开网页取正文

    /** 搜索 + 把排名靠前的几个网页打开，取出和问题最相关的正文。聊天 / 工作模式回答问题用这个 */
    fun searchDeep(p: SharedPreferences, query: String): List<Hit> {
        val hits = search(p, query)
        if (hits.isEmpty()) return hits
        try {
            enrich(hits, query)
        } catch (e: Throwable) {
            // 取正文失败不影响用搜索摘要回答
        }
        return hits.take(6)
    }

    /** 这些站点打开也拿不到有用的正文（要登录 / 要 JS / 视频页 / 文档下载），跳过 */
    private val skipFetchHosts = listOf(
        "bilibili.com", "douyin.com", "xiaohongshu.com", "weibo.com", "weibo.cn", "zhihu.com", "tieba.baidu.com",
        "wenku.baidu.com", "docin.com", "doc88.com", "baijiahao.baidu.com", "mbd.baidu.com", "youku.com", "iqiyi.com",
        "kuaishou.com", "pan.baidu.com", "map.baidu.com", "bing.com", "sogou.com", "so.com", "toutiao.com"
    )

    private fun fetchable(url: String): Boolean {
        if (!url.startsWith("http")) return false
        val host = hostOf(url)
        if (host.isEmpty()) return false
        if (skipFetchHosts.any { host == it || host.endsWith(".$it") }) return false
        val path = url.substringBefore('?').lowercase(Locale.ROOT)
        return !Regex("\\.(pdf|docx?|xlsx?|pptx?|zip|rar|7z|apk|exe|mp4|mp3|jpg|jpeg|png|gif)$").containsMatchIn(path)
    }

    private fun enrich(hits: List<Hit>, query: String, maxPages: Int = 3, budgetMs: Long = 8000L) {
        val terms = queryTerms(query)
        val cand = hits.take(6).filter { fetchable(it.url) }.take(maxPages)
        if (cand.isEmpty()) return
        val threads = ArrayList<Thread>()
        for (h in cand) {
            val t = Thread {
                try {
                    val d = pageDigest(h.url, terms, 560)
                    if (d.length >= 40) h.body = d
                } catch (e: Throwable) {
                }
            }
            t.isDaemon = true
            t.start()
            threads.add(t)
        }
        val deadline = System.currentTimeMillis() + budgetMs
        for (t in threads) {
            val left = deadline - System.currentTimeMillis()
            if (left > 0L) {
                try {
                    t.join(left)
                } catch (e: InterruptedException) {
                }
            }
        }
    }

    private fun readAll(c: HttpURLConnection): ByteArray {
        val out = ByteArrayOutputStream()
        c.inputStream.use { ins ->
            val buf = ByteArray(16384)
            while (true) {
                val r = ins.read(buf)
                if (r < 0) break
                out.write(buf, 0, r)
                if (out.size() > PAGE_MAX_BYTES) break
            }
        }
        return out.toByteArray()
    }

    /** 按响应头 / 网页里声明的编码解码（国内老站很多是 GBK） */
    private fun decodePage(bytes: ByteArray, contentType: String?): String {
        var cs: String? = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(contentType ?: "")?.groupValues?.get(1)
        if (cs == null) {
            val head = String(bytes, 0, minOf(bytes.size, 4096), Charsets.ISO_8859_1)
            cs = Regex("<meta[^>]+charset=[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1)
        }
        val charset = try {
            Charset.forName(cs ?: "UTF-8")
        } catch (e: Exception) {
            Charsets.UTF_8
        }
        return String(bytes, charset)
    }

    private fun fetchPage(url: String): String {
        var u = url
        var hops = 0
        while (true) {
            val c = URL(u).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 5000
                c.readTimeout = 6000
                c.instanceFollowRedirects = false // 自己处理跳转，这样 http ↔ https 的跳转也能跟上
                c.setRequestProperty("User-Agent", EDGE_UA)
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml")
                c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.5")
                val code = c.responseCode
                if (code in 300..399 && hops < 4) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("跳转没有目标地址")
                    u = URL(URL(u), loc).toString()
                    hops++
                    continue
                }
                if (code !in 200..299) throw IOException("HTTP $code")
                val ct = c.contentType ?: ""
                val low = ct.lowercase(Locale.ROOT)
                if (low.isNotEmpty() && !low.contains("html") && !low.contains("text/plain") && !low.contains("xml")) {
                    throw IOException("不是网页")
                }
                return decodePage(readAll(c), ct)
            } finally {
                c.disconnect()
            }
        }
    }

    private val dropBlocks = Regex(
        "<(script|style|noscript|svg|iframe|form|nav|footer|aside|header|button|select|template|head)\\b[^>]*>.*?</\\1\\s*>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
    )
    private val htmlComments = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
    private val blockTags = Regex(
        "</?(?:p|div|li|ul|ol|h[1-6]|tr|td|th|br|section|article|table|blockquote|dd|dt|main|figure|figcaption|pre)\\b[^>]*>",
        RegexOption.IGNORE_CASE
    )
    private val boilerplate = Regex(
        "版权所有|copyright|ICP备|公网安备|登录|注册|免责声明|隐私政策|关于我们|联系我们|广告|点击查看|下载APP|扫码|分享到|上一篇|下一篇|" +
            "相关推荐|热门推荐|责任编辑|Cookie|客服|举报|评论|回复|收藏|点赞|转发|关注我们|友情链接|网站地图|返回顶部",
        RegexOption.IGNORE_CASE
    )

    private fun cjkCount(s: String): Int {
        var n = 0
        for (ch in s) if (ch in '一'..'鿿') n++
        return n
    }

    /** 把网页变成“一行一段”的正文行，去掉脚本、导航、页脚、广告、代码之类 */
    private fun extractLines(html: String): List<String> {
        var h = htmlComments.replace(html, " ")
        h = dropBlocks.replace(h, " ")
        h = blockTags.replace(h, "\n")
        h = h.replace(Regex("<[^>]*>"), "")
        h = decodeEntities(h)
        val out = ArrayList<String>()
        val seen = HashSet<String>()
        for (raw in h.split('\n')) {
            val l = raw.replace(Regex("\\s+"), " ").trim()
            if (l.length < 14) continue
            val cjk = cjkCount(l)
            if (cjk < 8 && l.length < 40) continue
            if (l.count { it == '{' || it == '}' || it == ';' } > 3 || l.contains("function(") || l.contains("var ")) continue
            if (boilerplate.containsMatchIn(l) && l.length < 60) continue
            if (seen.add(l)) out.add(l)
        }
        return out
    }

    /** 从网页里挑出和问题最相关的几段（按原来的顺序拼起来），总长度不超过 budget */
    private fun pageDigest(url: String, terms: Set<String>, budget: Int): String {
        val html = fetchPage(url)
        if (looksBlocked(html)) return ""
        val lines = extractLines(html)
        if (lines.isEmpty()) return ""
        val need = if (terms.size >= 6) 2 else 1
        val scored = ArrayList<Pair<Int, Int>>() // 行号, 分数
        if (terms.isNotEmpty()) {
            for (i in lines.indices) {
                val s = relevance(lines[i], terms)
                if (s >= need) scored.add(Pair(i, s))
            }
        }
        val chosen = ArrayList<Int>()
        var used = 0
        if (scored.isNotEmpty()) {
            val top = scored.sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenBy { it.first })
            for (p in top) {
                val seg = short(lines[p.first], 240)
                if (used + seg.length > budget) {
                    if (chosen.isEmpty()) {
                        chosen.add(p.first)
                    }
                    break
                }
                chosen.add(p.first)
                used += seg.length
                if (chosen.size >= 6) break
            }
        } else {
            // 没有哪一段明显相关：取文章开头几段当概述
            for (i in lines.indices) {
                val seg = short(lines[i], 200)
                if (lines[i].length < 30) continue
                if (used + seg.length > budget / 2) break
                chosen.add(i)
                used += seg.length
            }
        }
        chosen.sort()
        val sb = StringBuilder()
        for (i in chosen) {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(short(lines[i], 240))
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ 给模型看的资料

    /**
     * 把搜索结果整理成给模型的资料：编号 + 标题 + 来源 + 正文（有网页正文用正文，否则用搜索摘要），
     * 总长度限制在 budget 字以内，免得把模型的上下文塞满。
     */
    fun renderForPrompt(hits: List<Hit>, withUrl: Boolean, budget: Int = 2600): String {
        val sb = StringBuilder()
        var i = 1
        for (h in hits) {
            val host = hostOf(h.url)
            val head = StringBuilder()
            head.append(i).append(". ").append(h.title)
            if (withUrl && h.url.isNotEmpty()) head.append("（网址：").append(h.url).append("）")
            else if (host.isNotEmpty()) head.append("（来自 ").append(host).append("）")
            head.append("：")
            val remain = budget - sb.length - head.length - 1
            if (remain < 60) break
            val cap = if (h.body.isNotEmpty()) 640 else 220
            sb.append(head).append(short(h.best(), minOf(remain, cap))).append("\n")
            i++
        }
        return sb.toString()
    }
}

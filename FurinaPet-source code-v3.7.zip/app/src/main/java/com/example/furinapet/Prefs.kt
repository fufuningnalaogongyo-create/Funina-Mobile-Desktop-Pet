package com.example.furinapet

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "pet"

    fun get(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // 键名
    const val NAME = "userName"
    const val SIZE = "sizeDp"
    const val ALPHA = "alphaPct"
    const val AUTO_DOCK = "autoDock"
    const val HIDE_PCT = "hidePct"
    const val TILT = "tiltDeg"
    const val WANDER = "wander"
    const val WANDER_SEC = "wanderSec"
    const val CHAT = "chatEnabled"
    const val CHAT_SEC = "chatSec"
    const val BUBBLE_SEC = "bubbleSec"
    const val BUBBLE_TEXT = "bubbleTextSp"
    const val BUBBLE_THEME = "bubbleTheme"
    const val HAPTIC = "haptic"
    const val GREET_ON_START = "greetStart"
    const val HOURLY = "hourly"
    const val WATER_ON = "waterOn"
    const val WATER_MIN = "waterMin"
    const val REST_ON = "restOn"
    const val REST_MIN = "restMin"
    const val REMINDERS = "reminders"
    const val QUIET_ON = "quietOn"
    const val QUIET_FROM = "quietFrom"
    const val QUIET_TO = "quietTo"
    const val BATTERY_TALK = "batteryTalk"
    const val BOOT_START = "bootStart"
    const val IMG_VERSION = "imgVersion"
    const val POS_Y = "posY"
    const val POS_X = "posX"
    const val DOCK_SIDE = "dockSide" // -1 未贴边, 0 左, 1 右
    const val RUNNING = "running"
    const val AFF = "bondAff"
    const val FULL = "bondFull"
    const val FULL_TS = "bondFullTs"
    const val DAY = "bondDay"
    const val TAP_DAY = "bondTapDay"
    const val TAP_TODAY = "bondTapToday"
    const val HUNGRY_TALK = "hungryTalk"
    const val VPACK_ON = "vpackOn"
    const val VPACK_MIX = "vpackMix"
    const val VOICE_ON = "voiceOn"
    const val VOICE_MODE = "voiceMode"
    const val VOICE_VOL = "voiceVol"
    const val VOICE_RATE = "voiceRate"
    const val VOICE_PITCH = "voicePitch"
    const val FOCUS_MIN = "focusMin"
    const val FORTUNE_DAY = "bondFortuneDay"
    const val FORTUNE_IDX = "bondFortuneIdx"
    const val PLAY_DAY = "bondPlayDay"
    const val PLAY_TODAY = "bondPlayToday"
    const val BEST_CATCH = "bondBestCatch"
    const val AI_SEARCH = "aiSearch"
    const val AI_SEARX_URL = "aiSearxUrl"
    const val AI_ENGINE = "aiEngine"
    const val AI_TTS = "aiTts"
    const val TTS_RATE = "aiTtsRate"
    const val TTS_PITCH = "aiTtsPitch"
    const val AI_BOCHA_KEY = "aiBochaKey"
    const val AI_GPU = "aiGpu"
    const val AI_ROMANCE = "aiRomance"
    const val AI_WORK_SEARCH = "aiWorkSearch"
    const val UI_BG_BLUR = "uiBgBlur"
    const val UI_BG_DIM = "uiBgDim"
    const val UI_BG_VER = "uiBgVer"
    const val AI_ACTIONS = "aiActions"
    const val AI_MODEL_URL = "aiModelUrl"
    const val AI_MODEL_ACTIVE = "aiModelActive"
    const val AI_DEEP = "aiDeepThink"
    const val AI_HUMAN = "aiHuman"
    const val CHAT_DAY = "bondChatDay"
    const val CHAT_TODAY = "bondChatToday"

    fun name(p: SharedPreferences): String {
        val n = p.getString(NAME, "") ?: ""
        return if (n.isBlank()) "旅行者" else n.trim()
    }
}

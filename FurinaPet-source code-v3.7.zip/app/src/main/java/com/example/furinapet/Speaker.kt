package com.example.furinapet

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * 聊天自动朗读：用手机自带的语音引擎（TextToSpeech）读出她的回复。
 * 括号里的动作/心理描写、表情符号、Markdown 符号不会读。
 * 注意：这是系统自带的音色，不是声音克隆。
 */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var pending: String? = null
    private var appCtx: Context? = null

    private val bracketRe = Regex("[（(【\\[][^）)】\\]]*[）)】\\]]")
    private val noiseRe = Regex("[*_#`~>|]|[\\p{So}\\p{Cs}]")

    /** 把要读的文字整理干净 */
    fun clean(raw: String): String {
        var s = bracketRe.replace(raw, " ")
        s = noiseRe.replace(s, " ")
        s = s.replace(Regex("[ \\t]{2,}"), " ").trim()
        return s
    }

    private fun applyParams() {
        val c = appCtx ?: return
        val p = Prefs.get(c)
        tts?.setSpeechRate(p.getInt(Prefs.TTS_RATE, 100).coerceIn(30, 250) / 100f)
        tts?.setPitch(p.getInt(Prefs.TTS_PITCH, 100).coerceIn(30, 250) / 100f)
    }

    private fun say(text: String) {
        applyParams()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "furina_chat")
    }

    fun speak(ctx: Context, raw: String) {
        val text = clean(raw)
        if (text.isEmpty() || failed) return
        appCtx = ctx.applicationContext
        if (tts == null) {
            pending = text
            tts = TextToSpeech(appCtx) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale.SIMPLIFIED_CHINESE)
                    ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    if (!ready) failed = true
                    val t = pending
                    pending = null
                    if (ready && t != null) say(t)
                } else {
                    failed = true
                }
            }
            return
        }
        if (ready) say(text) else pending = text
    }

    /** 这次朗读是否失败了（没有可用的语音引擎或中文语音） */
    fun unavailable(): Boolean = failed

    fun stop() {
        pending = null
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
    }

    fun shutdown() {
        try {
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ready = false
    }
}

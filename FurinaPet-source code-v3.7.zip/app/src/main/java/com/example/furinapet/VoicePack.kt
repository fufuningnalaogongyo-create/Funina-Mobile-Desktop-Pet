package com.example.furinapet

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream
import kotlin.random.Random

/**
 * 语音包模块：每条语音 = 一个音频文件 + 一句文字 + 一个所属场景。
 * 内容完全由用户在本机导入，应用本身不自带任何第三方录音。
 */
object VoicePack {

    class Entry(val id: String, var cat: String, var text: String)

    const val NONE = "none"
    private const val MAX_ENTRIES = 300
    private const val MAX_BYTES = 6L * 1024L * 1024L
    private var counter = 0L

    /** 当前启用方案的文件夹 */
    fun dir(ctx: Context): File = dirOf(ctx, activeId(ctx))

    fun audioFile(ctx: Context, e: Entry): File = File(dir(ctx), e.id + ".snd")

    fun catLabel(key: String): String {
        if (key == NONE) return "未归类（不使用）"
        val c = Lines.byKey(key)
        return if (c != null) c.label else key
    }

    fun load(ctx: Context): MutableList<Entry> {
        ensureDefault(ctx)
        return readIndex(dirOf(ctx, activeId(ctx)))
    }

    private fun readIndex(d: File): MutableList<Entry> {
        val out = ArrayList<Entry>()
        try {
            val f = File(d, "index.json")
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.getString("id"), o.optString("cat", NONE), o.optString("text", "")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun writeIndex(d: File, list: List<Entry>) {
        try {
            val arr = JSONArray()
            for (e in list) {
                val o = JSONObject()
                o.put("id", e.id)
                o.put("cat", e.cat)
                o.put("text", e.text)
                arr.put(o)
            }
            d.mkdirs()
            File(d, "index.json").writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    fun save(ctx: Context, list: List<Entry>) {
        writeIndex(dir(ctx), list)
    }

    // ------------------------------------------------------------------ 方案
    // 方案 = 一套独立的语音包。「默认语音包」是内置的那 22 条；另有若干「自定义方案」，各自独立导入、互不影响。
    // 同一时间只启用一个方案，桌宠触发场景时只从当前方案里挑语音。

    class Scheme(val id: String, var name: String)

    const val DEFAULT_ID = "default"
    const val DEFAULT_NAME = "默认语音包（内置）"
    const val MAX_CUSTOM = 10
    const val K_ACTIVE = "vpackScheme"
    const val K_LIST = "vpackSchemes"
    const val K_SEQ = "vpackSchemeSeq"

    fun dirOf(ctx: Context, id: String): File = File(ctx.filesDir, "vpack_" + id)

    private fun saveCustom(p: SharedPreferences, list: List<Scheme>) {
        val arr = JSONArray()
        for (sc in list) {
            val o = JSONObject()
            o.put("id", sc.id)
            o.put("name", sc.name)
            arr.put(o)
        }
        p.edit().putString(K_LIST, arr.toString()).apply()
    }

    /** 旧版（只有单一语音包）留下的 vpack 文件夹，迁进「自定义方案1」，里面的内置默认条目去掉，避免重复 */
    private fun migrateLegacy(ctx: Context, target: Scheme) {
        try {
            val legacy = File(ctx.filesDir, "vpack")
            if (!legacy.exists()) return
            val t = dirOf(ctx, target.id)
            if (t.exists() || !legacy.renameTo(t)) return
            val keep = ArrayList<Entry>()
            for (e in readIndex(t)) {
                if (e.id.startsWith("default_")) File(t, e.id + ".snd").delete() else keep.add(e)
            }
            writeIndex(t, keep)
        } catch (e: Exception) {
        }
    }

    @Synchronized
    private fun customSchemes(ctx: Context): MutableList<Scheme> {
        val p = Prefs.get(ctx)
        val out = ArrayList<Scheme>()
        val raw = p.getString(K_LIST, null)
        if (raw == null) {
            // 第一次：预先建好「自定义方案1」「自定义方案2」
            val a = Scheme("c1", "自定义方案1")
            val b = Scheme("c2", "自定义方案2")
            out.add(a)
            out.add(b)
            p.edit().putInt(K_SEQ, 2).apply()
            saveCustom(p, out)
            migrateLegacy(ctx, a)
            return out
        }
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Scheme(o.getString("id"), o.optString("name", "自定义方案")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    /** 全部方案：第一个是默认语音包，后面是自定义方案 */
    fun schemes(ctx: Context): List<Scheme> {
        val out = ArrayList<Scheme>()
        out.add(Scheme(DEFAULT_ID, DEFAULT_NAME))
        out.addAll(customSchemes(ctx))
        return out
    }

    fun activeId(ctx: Context): String {
        val id = Prefs.get(ctx).getString(K_ACTIVE, DEFAULT_ID) ?: DEFAULT_ID
        if (id == DEFAULT_ID) return id
        for (sc in customSchemes(ctx)) {
            if (sc.id == id) return id
        }
        return DEFAULT_ID
    }

    fun nameOf(ctx: Context, id: String): String {
        for (sc in schemes(ctx)) {
            if (sc.id == id) return sc.name
        }
        return DEFAULT_NAME
    }

    fun setActive(ctx: Context, id: String) {
        Prefs.get(ctx).edit().putString(K_ACTIVE, id).apply()
    }

    fun schemeCount(ctx: Context, id: String): Int {
        if (id == DEFAULT_ID) ensureDefault(ctx)
        return readIndex(dirOf(ctx, id)).size
    }

    /** 新建一个自定义方案；已达上限返回 null */
    @Synchronized
    fun addScheme(ctx: Context): Scheme? {
        val p = Prefs.get(ctx)
        val list = customSchemes(ctx)
        if (list.size >= MAX_CUSTOM) return null
        var n = 1
        while (list.any { it.name == "自定义方案" + n }) n++
        val seq = p.getInt(K_SEQ, list.size) + 1
        p.edit().putInt(K_SEQ, seq).apply()
        val sc = Scheme("c" + seq, "自定义方案" + n)
        list.add(sc)
        saveCustom(p, list)
        return sc
    }

    @Synchronized
    fun renameScheme(ctx: Context, id: String, name: String): Boolean {
        val n = name.trim()
        if (id == DEFAULT_ID || n.isEmpty()) return false
        val list = customSchemes(ctx)
        for (sc in list) {
            if (sc.id == id) {
                sc.name = if (n.length > 20) n.substring(0, 20) else n
                saveCustom(Prefs.get(ctx), list)
                return true
            }
        }
        return false
    }

    /** 删除一个自定义方案（连同里面的语音）；默认语音包不能删除 */
    @Synchronized
    fun deleteScheme(ctx: Context, id: String): Boolean {
        if (id == DEFAULT_ID) return false
        val p = Prefs.get(ctx)
        val list = customSchemes(ctx)
        val hit = list.firstOrNull { it.id == id } ?: return false
        dirOf(ctx, id).deleteRecursively()
        list.remove(hit)
        saveCustom(p, list)
        if (p.getString(K_ACTIVE, DEFAULT_ID) == id) setActive(ctx, DEFAULT_ID)
        return true
    }

    // ------------------------------------------------------------------ 内置默认语音包

    const val DEFAULT_FLAG = "vpackDefaultV2"
    private const val DEFAULT_ASSETS = "vpack_default"

    /** 首次运行时装入内置默认语音包（只装一次；之后想找回用 restoreDefault） */
    @Synchronized
    private fun ensureDefault(ctx: Context) {
        val p = Prefs.get(ctx)
        if (p.getBoolean(DEFAULT_FLAG, false)) return
        if (installDefault(ctx, false) >= 0) p.edit().putBoolean(DEFAULT_FLAG, true).apply()
    }

    /** 恢复默认语音包：清掉「默认语音包」当前内容，重新装入最初内置的语音、场景和文字。返回条数，失败返回 -1。自定义方案不受影响。 */
    @Synchronized
    fun restoreDefault(ctx: Context): Int {
        val n = installDefault(ctx, true)
        if (n >= 0) Prefs.get(ctx).edit().putBoolean(DEFAULT_FLAG, true).apply()
        return n
    }

    private fun installDefault(ctx: Context, wipe: Boolean): Int {
        try {
            val json = ctx.assets.open(DEFAULT_ASSETS + "/manifest.json").use { String(it.readBytes(), Charsets.UTF_8) }
            val arr = JSONArray(json)
            val d = dirOf(ctx, DEFAULT_ID)
            if (wipe) d.deleteRecursively()
            d.mkdirs()
            val list = readIndex(d)
            var ok = true
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val file = o.getString("file")
                val id = "default_" + file.substringBeforeLast('.')
                if (list.any { it.id == id }) continue
                try {
                    ctx.assets.open(DEFAULT_ASSETS + "/" + file).use { input ->
                        File(d, id + ".snd").outputStream().use { out -> input.copyTo(out) }
                    }
                    list.add(Entry(id, o.optString("cat", "idle"), o.optString("text", "")))
                } catch (e: Exception) {
                    File(d, id + ".snd").delete()
                    ok = false
                }
            }
            writeIndex(d, list)
            return if (ok) list.size else -1
        } catch (e: Exception) {
            return -1
        }
    }

    fun remove(ctx: Context, list: MutableList<Entry>, e: Entry) {
        audioFile(ctx, e).delete()
        list.remove(e)
        save(ctx, list)
    }

    fun clearAll(ctx: Context) {
        val fs = dir(ctx).listFiles()
        if (fs != null) {
            for (f in fs) f.delete()
        }
    }

    /** 删除所有「未归类」的语音，返回删除数量 */
    fun removeUncategorized(ctx: Context, list: MutableList<Entry>): Int {
        val del = ArrayList<Entry>()
        for (e in list) {
            if (e.cat == NONE) del.add(e)
        }
        for (e in del) {
            audioFile(ctx, e).delete()
            list.remove(e)
        }
        save(ctx, list)
        return del.size
    }

    private fun isAudioName(n: String): Boolean {
        val l = n.lowercase()
        return l.endsWith(".mp3") || l.endsWith(".wav") || l.endsWith(".ogg") ||
            l.endsWith(".m4a") || l.endsWith(".aac") || l.endsWith(".flac") || l.endsWith(".opus")
    }

    private fun hasCjk(s: String): Boolean {
        for (ch in s) {
            if (ch.code in 0x4E00..0x9FFF) return true
        }
        return false
    }

    /** 根据文件名里的关键词猜测场景；有中文名但猜不到的放「日常闲聊」，没有中文名的放「未归类」 */
    private fun guess(raw: String): Pair<String, String> {
        // 去掉「01_」这类序号前缀
        val stem = raw.replace(Regex("^\\s*\\d+[_\\-.\\s]+"), "").trim()
        var cat = NONE
        if (stem.contains("早上好") || stem.contains("早安")) cat = "greet_morning"
        else if (stem.contains("中午好")) cat = "greet_noon"
        else if (stem.contains("下午好")) cat = "greet_afternoon"
        else if (stem.contains("晚上好")) cat = "greet_evening"
        else if (stem.contains("晚安") || stem.contains("明天见") || stem.contains("困了")) cat = "greet_night"
        else if (stem.contains("闲聊") || stem.contains("无聊")) cat = "idle"
        else if (stem.contains("蛋糕") || stem.contains("饿")) cat = "hungry"
        val usable = hasCjk(stem) && !stem.startsWith("语音片段")
        // 文件名有中文但没匹配到关键词的，一律放进「日常闲聊」
        if (usable && cat == NONE) cat = "idle"
        val text = if (usable) punctuate(stem) else ""
        return Pair(cat, text)
    }

    /** 简易补标点：开头语气词后加逗号、常见连接词前加逗号、句末按语气词补 。！？ 。仅规则判断，建议再自己润色。 */
    fun punctuate(src: String): String {
        var s = src.trim()
        if (s.isEmpty()) return s
        s = s.replace(Regex("^(哼|嗯|哎呀|唉|哇|喂|啊|哦|咦)(?=[^，。！？、\\s])"), "\$1，")
        s = s.replace(
            Regex("(?<=[^，。！？、\\s])(还说|还好|那是|谁让|说明|如果|因为|所以|但是|不过|可是|等等)"),
            "，\$1"
        )
        val last = s[s.length - 1]
        if ("。！？!?…~～".indexOf(last) >= 0) return s
        val q = arrayOf("吗", "哪里", "什么", "怎么", "多少", "谁", "呢")
        val ex = arrayOf("啦", "呀", "哦", "啊", "嘛", "哇", "喔", "咯")
        for (w in q) {
            if (s.endsWith(w)) return s + "？"
        }
        for (w in ex) {
            if (s.endsWith(w)) return s + "！"
        }
        return s + "。"
    }

    /** 给所有语音的文字补标点，返回有改动的条数 */
    fun punctuateAll(ctx: Context, list: List<Entry>): Int {
        var n = 0
        for (e in list) {
            val t = punctuate(e.text)
            if (t != e.text) {
                e.text = t
                n++
            }
        }
        save(ctx, list)
        return n
    }

    /** 把语音包里「已归类且有文字」的句子同步进对应场景的普通台词（已存在的不重复），返回新增条数 */
    fun syncToLines(ctx: Context, list: List<Entry>): Int {
        val p = Prefs.get(ctx)
        var added = 0
        for (e in list) {
            if (e.cat == NONE || e.text.isBlank()) continue
            val raw = Lines.getRaw(p, e.cat)
            val existing = raw.split("\n").map { it.trim() }
            val t = e.text.trim()
            if (existing.contains(t)) continue
            val merged = if (raw.isBlank()) t else raw.trimEnd() + "\n" + t
            p.edit().putString("lines_" + e.cat, merged).apply()
            added++
        }
        return added
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        var n = ""
        try {
            val c = ctx.contentResolver.query(uri, null, null, null, null)
            if (c != null) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) {
                    n = c.getString(i) ?: ""
                }
                c.close()
            }
        } catch (e: Exception) {
        }
        return n
    }

    private fun stemOf(name: String): String {
        val base = name.substringAfterLast('/').substringAfterLast('\\')
        return if (base.contains('.')) base.substringBeforeLast('.') else base
    }

    private fun copyIn(ctx: Context, input: InputStream, stem: String, list: MutableList<Entry>): Boolean {
        counter++
        val id = System.currentTimeMillis().toString() + "_" + counter
        val d = dir(ctx)
        d.mkdirs()
        val out = File(d, id + ".snd")
        var total = 0L
        var ok = true
        out.outputStream().use { o ->
            val buf = ByteArray(16384)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_BYTES) {
                    ok = false
                    break
                }
                o.write(buf, 0, n)
            }
        }
        if (!ok || total == 0L) {
            out.delete()
            return false
        }
        val g = guess(stem)
        list.add(Entry(id, g.first, g.second))
        return true
    }

    fun importUris(ctx: Context, uris: List<Uri>): Int {
        val list = load(ctx)
        var n = 0
        for (u in uris) {
            if (list.size >= MAX_ENTRIES) break
            try {
                val input = ctx.contentResolver.openInputStream(u)
                if (input != null) {
                    input.use {
                        if (copyIn(ctx, it, stemOf(displayName(ctx, u)), list)) n++
                    }
                }
            } catch (e: Exception) {
            }
        }
        save(ctx, list)
        return n
    }

    fun importZip(ctx: Context, uri: Uri): Int {
        val list = load(ctx)
        var n = 0
        try {
            val raw = ctx.contentResolver.openInputStream(uri)
            if (raw != null) {
                val zis = ZipInputStream(raw)
                zis.use {
                    var e = it.nextEntry
                    while (e != null) {
                        if (list.size >= MAX_ENTRIES) break
                        if (!e.isDirectory && isAudioName(e.name)) {
                            if (copyIn(ctx, it, stemOf(e.name), list)) n++
                        }
                        it.closeEntry()
                        e = it.nextEntry
                    }
                }
            }
        } catch (e: Exception) {
        }
        save(ctx, list)
        return n
    }

    /** 为某个场景挑一条语音；返回 null 表示这次用普通台词 */
    fun pick(ctx: Context, p: SharedPreferences, key: String): Entry? {
        if (!p.getBoolean(Prefs.VPACK_ON, true)) return null
        val pool = ArrayList<Entry>()
        for (e in load(ctx)) {
            if (e.cat == key && audioFile(ctx, e).exists()) pool.add(e)
        }
        if (pool.isEmpty()) return null
        val mix = p.getBoolean(Prefs.VPACK_MIX, true)
        if (mix && Random.nextFloat() >= 0.5f) return null
        return pool[Random.nextInt(pool.size)]
    }
}

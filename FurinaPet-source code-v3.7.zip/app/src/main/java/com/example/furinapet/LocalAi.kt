package com.example.furinapet

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 本地大模型（LiteRT-LM，完全在手机上运行，不需要网络）。
 * 模型文件（.litertlm）由用户自己导入，应用不自带。
 */
object LocalAi {

    class Turn(val fromUser: Boolean, val text: String)

    private val lock = Any()

    @Volatile
    private var engine: Engine? = null

    /** 引擎当前加载的是哪个模型文件；切换模型后据此判断要不要重新加载 */
    @Volatile
    private var loadedPath = ""

    @Volatile
    var usingGpu = false
        private set

    private var busy = 0
    private var releasePending = false

    fun dir(ctx: Context): File = File(ctx.filesDir, "ai")
    /** 当前正在使用的那个模型的文件（可以同时装多个，见 Models） */
    fun modelFile(ctx: Context): File = Models.file(ctx, Models.active(ctx))
    fun hasModel(ctx: Context): Boolean {
        val f = modelFile(ctx)
        return f.isFile && f.length() > 0L
    }

    fun isLoaded(): Boolean = engine != null

    // ------------------------------------------------------------------ 模型文件

    private fun queryName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (e: Exception) {
        }
        return ""
    }

    private fun querySize(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (e: Exception) {
        }
        return -1L
    }

    /** 把用户选的模型文件复制进应用私有目录（引擎只能读真实路径）。耗时长，请在后台线程调用。 */
    fun importModel(ctx: Context, uri: Uri, onProgress: (Long, Long) -> Unit) {
        val name = queryName(ctx, uri).lowercase()
        if (name.endsWith(".task") || name.endsWith(".bin") || name.endsWith(".gguf") || name.endsWith(".safetensors")) {
            throw IllegalStateException("这不是 .litertlm 格式的模型（.task / .bin / .gguf 本应用不支持）")
        }
        val total = querySize(ctx, uri)
        val d = dir(ctx)
        d.mkdirs()
        if (total > 0L && d.usableSpace < total + 256L * 1024L * 1024L) {
            throw IllegalStateException("手机存储空间不足，需要至少 " + (total / 1048576L + 256L) + " MB 可用空间")
        }
        val custom = Models.byId(Models.CUSTOM)
        val tmp = Models.partFile(ctx, custom)
        tmp.delete()
        try {
            val input = ctx.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("无法读取所选文件")
            var done = 0L
            var last = 0L
            input.use { src ->
                tmp.outputStream().use { dst ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val r = src.read(buf)
                        if (r < 0) break
                        dst.write(buf, 0, r)
                        done += r
                        val now = System.currentTimeMillis()
                        if (now - last > 500L) {
                            last = now
                            onProgress(done, total)
                        }
                    }
                }
            }
            if (done < 1024L * 1024L) throw IllegalStateException("文件太小，不像是模型文件")
            release()
            val dst = Models.file(ctx, custom)
            dst.delete()
            if (!tmp.renameTo(dst)) {
                tmp.copyTo(dst, true)
                tmp.delete()
            }
            Models.setActive(ctx, Models.CUSTOM)
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
    }

    /** 删除当前正在用的模型（想删指定的模型用 Models.delete） */
    fun deleteModel(ctx: Context) {
        Models.delete(ctx, Models.active(ctx))
    }

    /** 去掉推理模型（DeepSeek-R1 这类）输出的 <think>…</think> 思考过程，只留最后的回答 */
    fun stripThink(raw: String, expectThink: Boolean, finished: Boolean): String {
        var t = raw
        t = Regex("<think>.*?</think>", RegexOption.DOT_MATCHES_ALL).replace(t, "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open)
        val close = t.lastIndexOf("</think>")
        if (close >= 0) {
            t = t.substring(close + "</think>".length)
        } else if (expectThink) {
            // 深度思考时，模板常把开头的 <think> 放进提示词里，输出里只有结尾的 </think>：
            // 没见到 </think> 说明还在思考（或者想到被截断也没给出答案），都不能把思考过程当回答显示
            return ""
        }
        return t.trimStart()
    }

    /**
     * 快速模式下给小模型的回复限长：超过 max 字就在最近的句末截断（括号没配对的半截动作也去掉），
     * 返回的长度比原文短就说明被截了。
     */
    fun clipReply(s: String, max: Int): String {
        if (s.length <= max) return s
        val head = s.substring(0, minOf(s.length, max + 20))
        val end = head.lastIndexOfAny(charArrayOf('。', '！', '？', '!', '?'))
        var t = if (end >= 10) head.substring(0, end + 1) else s.substring(0, max)
        val open = t.lastIndexOf('（')
        if (open >= 0 && t.indexOf('）', open) < 0) t = t.substring(0, open).trimEnd()
        return t.ifEmpty { s.substring(0, max) }
    }

    /**
     * 小模型容易“复读”：同一段话一遍遍重复。找到第一处 16 个字以上的重复，从重复开始的地方截断。
     * 没有重复就原样返回。
     */
    fun cutLoop(s: String): String {
        val w = 16
        if (s.length < w * 2) return s
        var i = 0
        while (i + w * 2 <= s.length) {
            val j = s.indexOf(s.substring(i, i + w), i + w)
            if (j > 0) return s.substring(0, j).trimEnd()
            i++
        }
        return s
    }

    // ------------------------------------------------------------------ 引擎

    private fun create(path: String, backend: Backend): Engine {
        val e = Engine(EngineConfig(modelPath = path, backend = backend))
        try {
            e.initialize()
        } catch (t: Throwable) {
            try {
                e.close()
            } catch (x: Throwable) {
            }
            throw t
        }
        return e
    }

    /** 加载模型（可能要几十秒），必须在后台线程调用 */
    fun ensureEngine(ctx: Context): Engine {
        if (!hasModel(ctx)) throw IllegalStateException("还没有导入模型")
        val path = modelFile(ctx).absolutePath
        engine?.let { if (loadedPath == path) return it }
        synchronized(lock) {
            engine?.let { if (loadedPath == path) return it }
            if (engine != null) {
                // 换了模型：旧的先卸载（正在回答时不能换）
                if (busy > 0) throw IllegalStateException("她正在回答，等回答完再切换模型")
                try {
                    engine?.close()
                } catch (t: Throwable) {
                }
                engine = null
            }
            var e: Engine? = null
            usingGpu = false
            if (Prefs.get(ctx).getBoolean(Prefs.AI_GPU, false)) {
                try {
                    e = create(path, Backend.GPU())
                    usingGpu = true
                } catch (t: Throwable) {
                    e = null
                }
            }
            val result = e ?: create(path, Backend.CPU())
            engine = result
            loadedPath = path
            return result
        }
    }

    /** 释放模型占用的内存；有回答正在生成时会等它结束再释放。可能阻塞，请在后台线程调用 */
    fun release() {
        synchronized(lock) {
            if (busy > 0) {
                releasePending = true
                return
            }
            val e = engine
            engine = null
            loadedPath = ""
            if (e != null) {
                try {
                    e.close()
                } catch (t: Throwable) {
                }
            }
        }
    }

    private fun finishBusy() {
        var doRelease = false
        synchronized(lock) {
            busy--
            if (busy <= 0 && releasePending) {
                releasePending = false
                doRelease = true
            }
        }
        if (doRelease) release()
    }

    // ------------------------------------------------------------------ 生成

    /**
     * 每一轮都用最新的系统提示词新建一个对话，把最近几轮历史带进去，
     * 这样好感度、饱食度变了，回答风格马上跟着变。必须在后台线程调用。
     * onPartial 收到的是目前为止的完整文本；onFinish 的参数为 null 表示成功。
     */
    fun generate(
        ctx: Context,
        system: String,
        history: List<Turn>,
        user: String,
        onPartial: (String) -> Unit,
        onFinish: (Throwable?) -> Unit,
        temperature: Double = 0.75
    ) {
        val eng = try {
            ensureEngine(ctx)
        } catch (t: Throwable) {
            onFinish(t)
            return
        }

        // 历史必须 用户/模型 交替，并且以用户开头、以模型结尾
        // 存档里可能有没回复的用户消息、被中断的半截回复：整理成严格交替的上下文
        val src = history.takeLast(16)
        val cleaned = ArrayList<Turn>()
        for (i in src.indices) {
            val t = src[i]
            val nextSame = i + 1 < src.size && src[i + 1].fromUser == t.fromUser
            if (nextSame) continue
            val txt = t.text.removeSuffix(ChatStore.INTERRUPTED).substringBefore("\n\n参考来源：").substringBefore("\n\n（未联网核实").trim()
            cleaned.add(Turn(t.fromUser, if (t.fromUser) txt else Persona.cleanReply(txt)))
        }
        var h: List<Turn> = cleaned.dropWhile { !it.fromUser }
        while (h.isNotEmpty() && h.last().fromUser) h = h.dropLast(1)
        val thinker = Models.active(ctx).id == Models.DEEPSEEK
        // 1.5B 的小模型上下文一长就容易乱，少带几轮历史
        h = h.takeLast(if (thinker) 6 else 12).dropWhile { !it.fromUser }
        val initial = ArrayList<Message>()
        for (t in h) initial.add(if (t.fromUser) Message.user(t.text) else Message.model(t.text))

        // DeepSeek 是推理模型：开了“深度思考”才让它先想后答（要放宽输出预算，很慢）；
        // 关闭时严格限制长度、降低随机性、并明确要求直接回答，尽量快
        val deep = thinker && Prefs.get(ctx).getBoolean(Prefs.AI_DEEP, false)
        val maxTokens = if (deep) 1536 else if (thinker) 320 else 256
        val temp = if (deep) 0.6 else if (thinker) 0.5 else temperature
        val sys = if (thinker && !deep) {
            system + "\n\n【重要】直接给出最终回答，不要输出思考过程，不要写 <think> 标签，不要重复同一句话，不要自言自语，只回答用户问的问题。" +
                "\n用户刚刚说：「" + user.take(120) + "」。你的回复必须直接回应这句话的内容，不要岔开。"
        } else system
        val fast = thinker && !deep
        val sampler = SamplerConfig(topK = 40, topP = 0.9, temperature = temp)
        synchronized(lock) { busy++ }

        val conv: Conversation = try {
            eng.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(sys),
                    initialMessages = initial,
                    samplerConfig = sampler,
                    thinkingConfig = ThinkingConfig(enableThinking = deep),
                    maxOutputToken = maxTokens
                )
            )
        } catch (t: Throwable) {
            try {
                eng.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(sys),
                        initialMessages = initial,
                        samplerConfig = sampler
                    )
                )
            } catch (t2: Throwable) {
                finishBusy()
                onFinish(t2)
                return
            }
        }

        val sb = StringBuilder()
        var finished = false
        val finish = fun(err: Throwable?) {
            synchronized(sb) {
                if (finished) return
                finished = true
            }
            // 在回调线程里直接 close 可能卡住，换个线程收尾
            Thread {
                try {
                    conv.close()
                } catch (t: Throwable) {
                }
                finishBusy()
                onFinish(err)
            }.start()
        }

        try {
            conv.sendMessageAsync(user, object : MessageCallback {
                override fun onMessage(message: Message) {
                    val s: String
                    synchronized(sb) {
                        if (finished) return
                        sb.append(message.toString())
                        s = sb.toString()
                    }
                    val shown = stripThink(s, deep, false)
                    var cut = cutLoop(shown)
                    // 快速模式：回复限长，超了就在句末截断并立刻停止生成（省时间）
                    if (fast) cut = clipReply(cut, 160)
                    onPartial(cut)
                    if (cut.length < shown.length) {
                        // 开始复读了：到此为止，不让它继续刷屏
                        finish(null)
                    }
                }

                override fun onDone() {
                    val s = synchronized(sb) { sb.toString() }
                    var out = cutLoop(stripThink(s, deep, true))
                    if (fast) out = clipReply(out, 160)
                    onPartial(out)
                    finish(null)
                }

                override fun onError(throwable: Throwable) {
                    finish(throwable)
                }
            })
        } catch (t: Throwable) {
            finish(t)
        }
    }
}

/** 原子写文件：写到一半被系统杀掉也不会把原文件弄坏（android.util.AtomicFile 会自动留备份并恢复） */
object SafeFile {
    fun write(f: File, text: String) {
        f.parentFile?.mkdirs()
        val af = android.util.AtomicFile(f)
        val out = af.startWrite()
        try {
            out.write(text.toByteArray(Charsets.UTF_8))
            af.finishWrite(out)
        } catch (e: Exception) {
            af.failWrite(out)
            throw e
        }
    }

    fun read(f: File): String? {
        return try {
            android.util.AtomicFile(f).openRead().use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) {
            null
        }
    }

    fun delete(f: File) {
        android.util.AtomicFile(f).delete()
    }
}

/** 聊天记录：只存在本机，最多保留最近 80 条。每次都用原子写，被后台清理时不会丢 */
object ChatStore {
    private const val MAX = 80

    /** 回复生成到一半被中断时，存下来的半截回复会带上这个结尾 */
    const val INTERRUPTED = "……（回复被中断了）"

    private fun file(ctx: Context, scope: String): File =
        File(LocalAi.dir(ctx), if (scope == AiMemory.WORK) "work_chat.json" else "chat.json")

    fun load(ctx: Context, scope: String = AiMemory.CHAT): MutableList<LocalAi.Turn> {
        val out = ArrayList<LocalAi.Turn>()
        val txt = SafeFile.read(file(ctx, scope)) ?: return out
        try {
            val arr = JSONArray(txt)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(LocalAi.Turn(o.optString("r") == "u", o.optString("t", "")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<LocalAi.Turn>, scope: String = AiMemory.CHAT) {
        try {
            val arr = JSONArray()
            for (t in list.takeLast(MAX)) {
                val o = JSONObject()
                o.put("r", if (t.fromUser) "u" else "m")
                o.put("t", t.text)
                arr.put(o)
            }
            SafeFile.write(file(ctx, scope), arr.toString())
        } catch (e: Exception) {
        }
    }

    fun clear(ctx: Context, scope: String = AiMemory.CHAT) {
        SafeFile.delete(file(ctx, scope))
    }
}

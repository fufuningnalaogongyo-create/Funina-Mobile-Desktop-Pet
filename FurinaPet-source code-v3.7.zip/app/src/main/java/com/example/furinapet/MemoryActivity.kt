package com.example.furinapet

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** AI 记忆管理：查看、搜索、添加、修改、删除、清空她记住的事 */
class MemoryActivity : Activity() {

    private lateinit var pageHost: PageHost
    private lateinit var listBox: LinearLayout
    private lateinit var countText: TextView
    private lateinit var addInput: EditText
    private lateinit var searchInput: EditText
    private var keyword = ""
    private var scope = AiMemory.CHAT

    private val cGold = 0xFFE5C26B.toInt()
    private val cText = 0xFFEAF1FF.toInt()
    private val cSub = 0xFF9FB0DC.toInt()
    private val cNavy = 0xFF0B1230.toInt()
    private val cDanger = 0xFFFF8A80.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        Ui.noteTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun finish() {
        super.finish()
        Ui.closeTransition(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scope = intent.getStringExtra("scope") ?: AiMemory.CHAT
        buildUi()
        render()
    }

    override fun onResume() {
        super.onResume()
        pageHost.resumeVideo()
    }

    override fun onPause() {
        pageHost.pauseVideo()
        super.onPause()
    }

    override fun onDestroy() {
        pageHost.release()
        super.onDestroy()
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun styleInput(et: EditText, hint: String) {
        et.hint = hint
        et.setTextColor(cText)
        et.setHintTextColor(0xFF6E7DAA.toInt())
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        et.background = Ui.glass(this, 14, 0xB0)
        et.setPadding(dp(14), dp(10), dp(14), dp(10))
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.maxLines = 2
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(12))

        // 顶栏
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val back = label("‹ 返回", 15f, cSub)
        back.setPadding(dp(4), dp(6), dp(12), dp(6))
        back.setOnClickListener { finish() }
        Ui.press(back)
        top.addView(back)
        val title = label(if (scope == AiMemory.WORK) "工作记忆" else "AI 记忆", 20f, cGold, true)
        title.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        title.gravity = Gravity.CENTER
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clear = label("清空", 14f, cDanger)
        clear.setPadding(dp(12), dp(6), dp(4), dp(6))
        clear.setOnClickListener { confirmClear() }
        Ui.press(clear)
        top.addView(clear)
        root.addView(top)

        countText = label("", 12f, cSub)
        countText.setPadding(0, dp(8), 0, dp(2))
        root.addView(countText)
        val tip = label(
            "这是她记住的、关于你的事，聊天时会自然地用上。记忆里的「用户」是你，「芙宁娜」是她。" +
                "也可以在聊天里直接说“记住……”“忘掉……”“你记得什么”。",
            12f, cSub
        )
        tip.setLineSpacing(0f, 1.15f)
        root.addView(tip)

        // 添加
        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        addRow.gravity = Gravity.CENTER_VERTICAL
        addInput = EditText(this)
        styleInput(addInput, "添加一条记忆，例如：我对芒果过敏")
        addRow.addView(addInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val addBtn = Button(this)
        addBtn.text = "添加"
        addBtn.transformationMethod = null
        addBtn.stateListAnimator = null
        addBtn.typeface = Typeface.DEFAULT_BOLD
        addBtn.setTextColor(cNavy)
        addBtn.background = Ui.goldFill(this, 18)
        addBtn.setOnClickListener { addMemory() }
        Ui.press(addBtn)
        val lpAdd = LinearLayout.LayoutParams(dp(68), dp(42))
        lpAdd.leftMargin = dp(8)
        addRow.addView(addBtn, lpAdd)
        val lpAddRow = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpAddRow.topMargin = dp(12)
        root.addView(addRow, lpAddRow)

        // 搜索
        searchInput = EditText(this)
        styleInput(searchInput, "搜索记忆")
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                keyword = s?.toString()?.trim() ?: ""
                render()
            }
        })
        val lpSearch = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpSearch.topMargin = dp(8)
        root.addView(searchInput, lpSearch)

        // 列表
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        listBox.setPadding(0, 0, 0, dp(8))
        scroll.addView(listBox, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val lpScroll = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        lpScroll.topMargin = dp(6)
        root.addView(scroll, lpScroll)

        pageHost = PageHost(this)
        pageHost.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(pageHost)
    }

    private fun render() {
        listBox.removeAllViews()
        val all = AiMemory.load(this, scope)
        countText.text = "共 " + all.size + " 条（上限 " + AiMemory.MAX + " 条）"
        if (all.isEmpty()) {
            val t = label("还没有记忆。在上面输入内容点「添加」，或者在聊天里对她说“记住……”。", 13f, cSub)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(40), dp(8), dp(8))
            listBox.addView(t)
            return
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        var shown = 0
        for (i in all.indices) {
            val m = all[i]
            if (keyword.isNotEmpty() && !m.text.contains(keyword, true)) continue
            shown++

            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.background = Ui.glass(this, 14, 0xC0)
            card.setPadding(dp(14), dp(12), dp(14), dp(10))

            val body = label(m.text, 15f, cText)
            body.setLineSpacing(0f, 1.12f)
            card.addView(body)

            val meta = LinearLayout(this)
            meta.orientation = LinearLayout.HORIZONTAL
            meta.gravity = Gravity.CENTER_VERTICAL
            val time = if (m.ts > 0L) fmt.format(Date(m.ts)) else ""
            val info = label("第 " + (i + 1) + " 条" + (if (time.isNotEmpty()) " · $time" else ""), 11f, cSub)
            meta.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val edit = label("编辑", 13f, cGold, true)
            edit.setPadding(dp(12), dp(6), dp(12), dp(6))
            edit.setOnClickListener { editMemory(m) }
            Ui.press(edit)
            meta.addView(edit)
            val del = label("删除", 13f, cDanger, true)
            del.setPadding(dp(12), dp(6), dp(4), dp(6))
            del.setOnClickListener { confirmDelete(m) }
            Ui.press(del)
            meta.addView(del)
            val lpMeta = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpMeta.topMargin = dp(4)
            card.addView(meta, lpMeta)

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            listBox.addView(card, lp)
        }
        if (shown == 0) {
            val t = label("没有找到包含「" + keyword + "」的记忆。", 13f, cSub)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(8), dp(30), dp(8), dp(8))
            listBox.addView(t)
        }
    }

    private fun addMemory() {
        val r = AiMemory.add(this, addInput.text.toString(), scope)
        val msg = when (r) {
            1 -> "已记住"
            0 -> "已经记过这条了"
            -1 -> "记忆已满（最多 " + AiMemory.MAX + " 条），请先删掉一些"
            else -> "内容太短了"
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        if (r == 1) {
            addInput.setText("")
            render()
        }
    }

    private fun editMemory(m: AiMemory.Item) {
        val et = EditText(this)
        et.setText(m.text)
        et.setSelection(et.text.length)
        et.setTextColor(cText)
        et.setPadding(dp(20), dp(12), dp(20), dp(12))
        GlassDialog(this)
            .setTitle("修改这条记忆")
            .setView(et)
            .setPositiveButton("保存") { _, _ ->
                val r = AiMemory.update(this, m.id, et.text.toString(), scope)
                val msg = when (r) {
                    1 -> "已修改"
                    0 -> "和另一条记忆重复了"
                    -2 -> "内容太短了"
                    else -> "这条记忆已经不存在了"
                }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmDelete(m: AiMemory.Item) {
        GlassDialog(this)
            .setTitle("删除这条记忆？")
            .setMessage(m.text)
            .setPositiveButton("删除") { _, _ ->
                AiMemory.remove(this, setOf(m.id), scope)
                render()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmClear() {
        val n = AiMemory.load(this, scope).size
        if (n == 0) {
            Toast.makeText(this, "现在没有记忆", Toast.LENGTH_SHORT).show()
            return
        }
        GlassDialog(this)
            .setTitle("清空全部记忆")
            .setMessage("会删除她记住的全部 $n 条内容，无法恢复。")
            .setPositiveButton("清空") { _, _ ->
                AiMemory.clear(this, scope)
                render()
            }
            .setNegativeButton("取消", null)
            .show()
    }
}

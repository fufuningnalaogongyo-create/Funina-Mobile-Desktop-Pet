package com.example.furinapet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.get(context).getBoolean(Prefs.BOOT_START, false)) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            PetService.start(context)
        } catch (e: Exception) {
        }
    }
}

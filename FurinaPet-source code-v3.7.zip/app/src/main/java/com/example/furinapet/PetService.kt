package com.example.furinapet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.Calendar
import kotlin.math.abs
import kotlin.random.Random

class PetService : Service(), PetView.Listener, SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val ACTION_STOP = "com.example.furinapet.STOP"
        private const val CHANNEL = "pet_channel"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false

        @Volatile
        var instance: PetService? = null

        fun start(c: Context) {
            c.startForegroundService(Intent(c, PetService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, PetService::class.java))
        }

        fun customImageFile(c: Context): File = File(c.filesDir, "custom_pet.png")
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var density = 1f

    private var pet: PetView? = null
    private lateinit var petParams: WindowManager.LayoutParams

    private var bubble: TextView? = null
    private var bubbleW = 0
    private var bubbleH = 0
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var screenW = 1080
    private var screenH = 1920

    private var dockSide = -1
    private var popped = false
    private var dragging = false
    private var originX = 0
    private var originY = 0
    private var moveAnim: ValueAnimator? = null
    private var walking = false

    private val tapTimes = ArrayList<Long>()
    private var pendingLevelUp = false
    private var voice: VoicePlayer? = null
    private var petHidden = false
    private var focusEnd = 0L

    private var panel: View? = null
    private var panelCard: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var backdropAnim: android.animation.ValueAnimator? = null
    private var panelPos = 0
    private var pLv: TextView? = null
    private var pAffText: TextView? = null
    private var pAffBar: BarView? = null
    private var pFullText: TextView? = null
    private var pFullBar: BarView? = null
    private var lastWater = 0L
    private var lastRest = 0L

    // ------------------------------------------------------------------ 生命周期

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        density = resources.displayMetrics.density
        prefs = Prefs.get(this)
        Bond.ensureInit(prefs)
        instance = this
        voice = VoicePlayer(this, prefs)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        readScreen()
        createPet()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_BATTERY_LOW)
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(batteryReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(batteryReceiver, f)
        }

        prefs.registerOnSharedPreferenceChangeListener(this)

        lastWater = SystemClock.elapsedRealtime()
        lastRest = lastWater
        if (Bond.daily(prefs)) pendingLevelUp = true
        scheduleIdle()
        scheduleWander()
        val now = System.currentTimeMillis()
        handler.postDelayed(minuteRunnable, 60000L - now % 60000L + 200L)

        if (prefs.getBoolean(Prefs.GREET_ON_START, true)) {
            handler.postDelayed({
                if (dockSide >= 0) popOut(false)
                pet?.jump(12f)
                pet?.burst(10)
                val ms = say(greetKey(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)))
                if (dockSide >= 0) scheduleRedock(ms + 1200L)
            }, 900L)
        }
        if (pendingLevelUp) {
            handler.postDelayed({ announceLevelUp() }, 6000L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && ACTION_STOP == intent.action) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        instance = null
        handler.removeCallbacksAndMessages(null)
        voice?.shutdown()
        voice = null
        moveAnim?.cancel()
        removeBubbleNow()
        hidePanelNow()
        try {
            pet?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        pet = null
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
        }
        try {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.postDelayed({
            readScreen()
            val v = pet ?: return@postDelayed
            if (dockSide >= 0 && !popped) {
                petParams.x = dockX(dockSide, v)
            } else {
                petParams.x = petParams.x.coerceIn(minX(v), maxX(v))
            }
            petParams.y = petParams.y.coerceIn(0, maxOf(0, screenH - v.windowH))
            updatePet()
        }, 300L)
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "桌宠常驻通知", NotificationManager.IMPORTANCE_MIN)
        nm.createNotificationChannel(ch)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, PetService::class.java).setAction(ACTION_STOP), flags
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "让她退场", stopPi
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("芙宁娜正在桌面上待命")
            .setContentText("点这里打开设置")
            .setContentIntent(openPi)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ 屏幕/窗口

    private fun dpi(v: Int): Int = (v * density + 0.5f).toInt()

    private fun readScreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width()
            screenH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels
            screenH = dm.heightPixels
        }
    }

    private fun minX(v: PetView): Int = (-(v.padX + v.drawW * 0.75f)).toInt()
    private fun maxX(v: PetView): Int = (screenW - v.padX - v.drawW * 0.25f).toInt()

    private fun dockX(side: Int, v: PetView): Int {
        val hide = prefs.getInt(Prefs.HIDE_PCT, 50) / 100f
        return if (side == 0) {
            (-(v.padX + v.drawW * hide)).toInt()
        } else {
            (screenW - v.drawW * (1f - hide) - v.padX).toInt()
        }
    }

    private fun fullX(side: Int, v: PetView): Int {
        val m = dpi(6)
        return if (side == 0) (-v.padX + m).toInt() else (screenW - v.drawW - v.padX - m).toInt()
    }

    private fun loadBitmap(): Bitmap? {
        val f = customImageFile(this)
        if (f.exists()) {
            try {
                val b = BitmapFactory.decodeFile(f.absolutePath)
                if (b != null) return b
            } catch (e: Exception) {
            }
        }
        return try {
            assets.open("furina.png").use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }

    private fun createPet() {
        val v = PetView(this)
        v.listener = this
        val b = loadBitmap()
        if (b != null) v.setBitmap(b)
        v.hapticEnabled = prefs.getBoolean(Prefs.HAPTIC, true)
        v.setAlphaPct(prefs.getInt(Prefs.ALPHA, 100))
        v.configure(dpi(prefs.getInt(Prefs.SIZE, 150)))

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        petParams = WindowManager.LayoutParams(v.windowW, v.windowH, type, flags, PixelFormat.TRANSLUCENT)
        petParams.gravity = Gravity.TOP or Gravity.START

        dockSide = prefs.getInt(Prefs.DOCK_SIDE, 1)
        petParams.y = prefs.getInt(Prefs.POS_Y, (screenH * 0.55f).toInt())
        petParams.y = petParams.y.coerceIn(0, maxOf(0, screenH - v.windowH))
        if (dockSide >= 0 && !prefs.getBoolean(Prefs.AUTO_DOCK, true)) dockSide = -1
        if (dockSide >= 0) {
            petParams.x = dockX(dockSide, v)
            v.setDock(dockSide, prefs.getInt(Prefs.TILT, 18).toFloat())
        } else {
            petParams.x = prefs.getInt(Prefs.POS_X, screenW - v.windowW).coerceIn(minX(v), maxX(v))
            v.setDock(-1, 0f)
        }
        pet = v
        wm.addView(v, petParams)
    }

    private fun updatePet() {
        val v = pet ?: return
        try {
            wm.updateViewLayout(v, petParams)
        } catch (e: Exception) {
        }
        updateBubblePos()
    }

    private fun savePos() {
        prefs.edit()
            .putInt(Prefs.POS_X, petParams.x)
            .putInt(Prefs.POS_Y, petParams.y)
            .putInt(Prefs.DOCK_SIDE, dockSide)
            .apply()
    }

    private fun animateTo(
        tx: Int, ty: Int, dur: Long, ip: Interpolator, onEnd: (() -> Unit)? = null
    ) {
        moveAnim?.cancel()
        val sx = petParams.x
        val sy = petParams.y
        val a = ValueAnimator.ofFloat(0f, 1f)
        var cancelled = false
        a.duration = dur
        a.interpolator = ip
        a.addUpdateListener { anim ->
            val f = anim.animatedValue as Float
            petParams.x = (sx + (tx - sx) * f).toInt()
            petParams.y = (sy + (ty - sy) * f).toInt()
            updatePet()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) onEnd?.invoke()
            }
        })
        moveAnim = a
        a.start()
    }

    // ------------------------------------------------------------------ 设置变化

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == null) return
        if (key == Prefs.POS_X || key == Prefs.POS_Y || key == Prefs.DOCK_SIDE) return
        if (key.startsWith("lines_") || key.startsWith("bond")) return
        val v = pet ?: return
        v.hapticEnabled = prefs.getBoolean(Prefs.HAPTIC, true)
        v.setAlphaPct(prefs.getInt(Prefs.ALPHA, 100))
        if (key == Prefs.IMG_VERSION) {
            val b = loadBitmap()
            if (b != null) v.setBitmap(b)
        }
        if (key == Prefs.SIZE || key == Prefs.IMG_VERSION) {
            v.configure(dpi(prefs.getInt(Prefs.SIZE, 150)))
            petParams.width = v.windowW
            petParams.height = v.windowH
        }
        if (!prefs.getBoolean(Prefs.AUTO_DOCK, true) && dockSide >= 0) {
            dockSide = -1
            popped = false
            v.setDock(-1, 0f)
            petParams.x = fullX(if (petParams.x < screenW / 2) 0 else 1, v)
        }
        if (dockSide >= 0 && !popped) {
            v.setDock(dockSide, prefs.getInt(Prefs.TILT, 18).toFloat())
            petParams.x = dockX(dockSide, v)
        }
        petParams.y = petParams.y.coerceIn(0, maxOf(0, screenH - v.windowH))
        updatePet()
        if (key == Prefs.CHAT || key == Prefs.CHAT_SEC) scheduleIdle()
        if (key == Prefs.WANDER || key == Prefs.WANDER_SEC) scheduleWander()
        if (key == Prefs.WATER_ON || key == Prefs.WATER_MIN) lastWater = SystemClock.elapsedRealtime()
        if (key == Prefs.REST_ON || key == Prefs.REST_MIN) lastRest = SystemClock.elapsedRealtime()
    }

    // ------------------------------------------------------------------ 触摸回调

    override fun onTap() {
        val now = SystemClock.uptimeMillis()
        tapTimes.add(now)
        while (tapTimes.isNotEmpty() && now - tapTimes[0] > 4000L) tapTimes.removeAt(0)

        if (dockSide >= 0 && !popped) {
            popOut(true)
            return
        }
        val pv = pet ?: return
        if (tapTimes.size >= 6) {
            tapTimes.clear()
            pv.shake()
            val ms = say("poke")
            if (popped) scheduleRedock(ms + 1200L)
            return
        }
        pv.jump()
        pv.burst(6)
        val lu = Bond.tapAff(prefs)
        val hi = Bond.level(Bond.aff(prefs)) >= 2 && Random.nextFloat() < 0.4f
        val ms = say(if (hi) "tap_hi" else "tap")
        if (hi) pv.burstHearts(4)
        if (lu) {
            handler.postDelayed({ announceLevelUp() }, ms + 400L)
        }
        if (popped) scheduleRedock(ms + 1800L)
    }

    override fun onDoubleTap() {
        if (dockSide >= 0 && !popped) {
            popOut(true)
            return
        }
        pet?.spin()
        pet?.burst(16)
        val ms = say("double")
        if (popped) scheduleRedock(ms + 1200L)
    }

    override fun onLongPress() {
        if (panel != null) {
            hidePanel()
            return
        }
        if (dockSide >= 0 && !popped) {
            popOut(false)
            handler.postDelayed({ showPanel() }, 320L)
        } else {
            showPanel()
        }
    }

    private fun openChat() {
        val i = Intent(this, ChatActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i, Ui.pageOptions(this))
        } catch (e: Exception) {
        }
    }

    private fun openSettings() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i, Ui.pageOptions(this))
        } catch (e: Exception) {
        }
    }

    override fun onDragStart() {
        val v = pet ?: return
        dragging = true
        hidePanelNow()
        moveAnim?.cancel()
        handler.removeCallbacks(redockRunnable)
        walking = false
        v.setWalking(false)
        v.setFacing(1)
        dockSide = -1
        popped = false
        v.setDock(-1, 0f)
        v.setHanging(true)
        originX = petParams.x
        originY = petParams.y
        if (Random.nextFloat() < 0.6f) say("drag")
    }

    override fun onDragMove(dx: Float, dy: Float) {
        val v = pet ?: return
        petParams.x = (originX + dx).toInt().coerceIn(minX(v), maxX(v))
        petParams.y = (originY + dy).toInt().coerceIn(0, maxOf(0, screenH - v.windowH))
        updatePet()
    }

    override fun onDragEnd() {
        val v = pet ?: return
        dragging = false
        v.setHanging(false)
        val left = petParams.x + v.padX
        val right = left + v.drawW
        val th = dpi(40)
        if (prefs.getBoolean(Prefs.AUTO_DOCK, true) && (left < th || screenW - right < th)) {
            val side = if (left + v.drawW / 2f < screenW / 2f) 0 else 1
            dockToSide(side)
        } else {
            v.jump(6f)
            if (Random.nextFloat() < 0.5f) say("drop")
            savePos()
        }
    }

    // ------------------------------------------------------------------ 贴边

    private fun dockToSide(side: Int) {
        val v = pet ?: return
        dockSide = side
        popped = false
        handler.removeCallbacks(redockRunnable)
        v.setDock(side, prefs.getInt(Prefs.TILT, 18).toFloat())
        val ty = petParams.y.coerceIn(0, maxOf(0, screenH - v.windowH))
        animateTo(dockX(side, v), ty, 280L, OvershootInterpolator(1.3f)) { savePos() }
    }

    private val redockRunnable = Runnable {
        if (popped && !dragging && dockSide >= 0) {
            dockToSide(dockSide)
        }
    }

    private fun scheduleRedock(ms: Long) {
        handler.removeCallbacks(redockRunnable)
        if (panel != null) return
        handler.postDelayed(redockRunnable, ms)
    }

    private fun popOut(withLine: Boolean) {
        val v = pet ?: return
        if (dockSide < 0) return
        popped = true
        v.setDock(-1, 0f)
        v.jump(8f)
        v.burst(8)
        animateTo(fullX(dockSide, v), petParams.y, 260L, DecelerateInterpolator())
        var ms = 2500L
        if (withLine) ms = say("peek")
        scheduleRedock(ms + 1200L)
    }

    // ------------------------------------------------------------------ 气泡

    private fun say(key: String, time: String = "", level: String = "", score: String = ""): Long {
        val e = VoicePack.pick(this, prefs, key)
        if (e != null) {
            val t = if (e.text.isBlank()) "♪" else e.text
                .replace("{name}", Prefs.name(prefs))
                .replace("{time}", time)
                .replace("{level}", level)
                .replace("{score}", score)
            val ms = showBubble(t, -1L, key, false)
            if (ms > 0L) voice?.playFile(VoicePack.audioFile(this, e))
            return ms
        }
        val s = Lines.pick(prefs, key, Prefs.name(prefs), time, level, score) ?: return 0L
        return showBubble(s, -1L, key)
    }

    private fun removeBubbleNow() {
        val b = bubble ?: return
        handler.removeCallbacks(hideBubbleRunnable)
        try {
            wm.removeView(b)
        } catch (e: Exception) {
        }
        bubble = null
    }

    private val hideBubbleRunnable = Runnable {
        val b = bubble
        if (b != null) {
            b.animate().alpha(0f).setDuration(220L).withEndAction {
                if (bubble === b) removeBubbleNow()
            }.start()
        }
    }

    private fun showBubble(text: String, forceMs: Long, key: String = "", speak: Boolean = true): Long {
        if (pet == null || petHidden) return 0L
        removeBubbleNow()

        val theme = prefs.getInt(Prefs.BUBBLE_THEME, 0)
        val bg: Int
        val fg: Int
        val stroke: Int
        when (theme) {
            1 -> {
                bg = 0xF5FFFFFF.toInt(); fg = 0xFF4A3A12.toInt(); stroke = 0xFFE0B44C.toInt()
            }
            2 -> {
                bg = 0xEE152248.toInt(); fg = 0xFFEAF1FF.toInt(); stroke = 0xFFFFD66B.toInt()
            }
            else -> {
                bg = 0xF2EAF4FF.toInt(); fg = 0xFF1B2F6B.toInt(); stroke = 0xFF5B8CFF.toInt()
            }
        }
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(fg)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt(Prefs.BUBBLE_TEXT, 14).toFloat())
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dpi(12), dpi(8), dpi(12), dpi(8))
        tv.maxWidth = minOf((screenW * 0.7f).toInt(), dpi(280))
        val d = GradientDrawable()
        d.setColor(bg)
        d.cornerRadius = dpi(16).toFloat()
        d.setStroke(dpi(2), stroke)
        tv.background = d
        tv.alpha = 0f

        tv.measure(
            View.MeasureSpec.makeMeasureSpec(screenW, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        bubbleW = tv.measuredWidth
        bubbleH = tv.measuredHeight

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        bubbleParams = WindowManager.LayoutParams(bubbleW, bubbleH, type, flags, PixelFormat.TRANSLUCENT)
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubble = tv
        computeBubblePos()
        try {
            wm.addView(tv, bubbleParams)
        } catch (e: Exception) {
            bubble = null
            return 0L
        }
        tv.animate().alpha(1f).setDuration(160L).start()
        if (speak) voice?.speak(key, text)

        val ms = if (forceMs > 0) forceMs else
            prefs.getInt(Prefs.BUBBLE_SEC, 5) * 1000L + text.length * 40L
        handler.postDelayed(hideBubbleRunnable, ms)
        return ms
    }

    private fun computeBubblePos() {
        val v = pet ?: return
        val spriteCx = petParams.x + v.padX + v.drawW / 2f
        val m = dpi(6)
        val bx = (spriteCx - bubbleW / 2f).toInt().coerceIn(m, maxOf(m, screenW - bubbleW - m))
        val above = (petParams.y + v.padY - bubbleH - dpi(4)).toInt()
        val below = (petParams.y + v.windowH - v.padY).toInt()
        val wantAbove = panelPos != 1
        var by = if (wantAbove) above else below
        if (wantAbove && by < dpi(24)) by = below
        if (!wantAbove && by + bubbleH > screenH - m) by = above
        if (by + bubbleH > screenH - m) by = screenH - bubbleH - m
        if (by < m) by = m
        bubbleParams.x = bx
        bubbleParams.y = by
    }

    private fun updateBubblePos() {
        val b = bubble ?: return
        computeBubblePos()
        try {
            wm.updateViewLayout(b, bubbleParams)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ 喂食面板

    private fun announceLevelUp() {
        pendingLevelUp = false
        val v = pet ?: return
        v.burstHearts(18)
        v.burst(10)
        v.spin()
        val name = Bond.levelNames[Bond.level(Bond.aff(prefs))]
        val ms = say("levelup", "", name)
        if (popped) scheduleRedock(ms + 1800L)
        updatePanelStats()
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dpi(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dpi(strokeDp), strokeColor)
        return d
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun showPanel() {
        val v = pet ?: return
        hidePanelNow()
        handler.removeCallbacks(redockRunnable)

        val gold = 0xFFE5C26B.toInt()
        val light = 0xFFEAF1FF.toInt()
        val sub = 0xFF9FB0DC.toInt()
        val pw = minOf(screenW - dpi(24), dpi(330))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dpi(14), dpi(12), dpi(14), dpi(12))
        // 毛玻璃：Android 12+ 且系统开启了窗口模糊时，背后的内容会被模糊；否则用更不透明的玻璃保证看得清
        val blurOk = Ui.blurSupported(this)
        root.background = Ui.glass(this, 20, if (blurOk) 0xA0 else 0xEC)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val lv = label("", 15f, gold, true)
        val affText = label("", 12f, light, false)
        row1.addView(lv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row1.addView(affText)
        root.addView(row1)

        val affBar = BarView(this)
        val lpA = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(8))
        lpA.topMargin = dpi(6)
        root.addView(affBar, lpA)

        val fullText = label("", 12f, sub, false)
        val lpF = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpF.topMargin = dpi(10)
        root.addView(fullText, lpF)
        val fullBar = BarView(this)
        val lpFB = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpi(8))
        lpFB.topMargin = dpi(4)
        root.addView(fullBar, lpFB)

        val feedLabel = label("投喂", 12f, sub, false)
        val lpL = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpL.topMargin = dpi(12)
        root.addView(feedLabel, lpL)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val rowFood = LinearLayout(this)
        rowFood.orientation = LinearLayout.HORIZONTAL
        for (f in Bond.foods) {
            val chip = LinearLayout(this)
            chip.orientation = LinearLayout.VERTICAL
            chip.gravity = Gravity.CENTER_HORIZONTAL
            chip.setPadding(dpi(4), dpi(8), dpi(4), dpi(8))
            chip.background = if (f.fav) Ui.ghost(this, 14) else rounded(0x1FFFFFFF, 14, 0x22FFFFFF, 1)
            chip.addView(label(f.emoji, 26f, light, false))
            val nm = label(f.name, 11f, light, false)
            nm.setSingleLine(true)
            chip.addView(nm)
            val tag = if (f.bad) "不爱吃" else "♥+" + f.affection
            chip.addView(label(tag, 10f, if (f.bad) sub else 0xFFFF8FB1.toInt(), false))
            chip.setOnClickListener { feedFromPanel(f) }
            Ui.press(chip)
            val lp = LinearLayout.LayoutParams(dpi(68), LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dpi(8)
            rowFood.addView(chip, lp)
        }
        hs.addView(rowFood)
        val lpH = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpH.topMargin = dpi(6)
        root.addView(hs, lpH)

        val playLabel = label("玩耍", 12f, sub, false)
        val lpPL = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpPL.topMargin = dpi(12)
        root.addView(playLabel, lpPL)

        val playRow = LinearLayout(this)
        playRow.orientation = LinearLayout.HORIZONTAL
        val plays = arrayOf(
            Triple("\uD83C\uDFAE", "接甜点", 0),
            Triple("\u270A", "猜拳", 1),
            Triple("\uD83D\uDD2E", "抽签", 2),
            Triple("\u23F3", "专注", 3)
        )
        for (pl in plays) {
            val chip = LinearLayout(this)
            chip.orientation = LinearLayout.VERTICAL
            chip.gravity = Gravity.CENTER_HORIZONTAL
            chip.setPadding(dpi(2), dpi(8), dpi(2), dpi(8))
            chip.background = rounded(0x1FFFFFFF, 14, 0x22FFFFFF, 1)
            chip.addView(label(pl.first, 22f, light, false))
            chip.addView(label(pl.second, 11f, light, false))
            val kind = pl.third
            chip.setOnClickListener { onPlayChip(kind) }
            Ui.press(chip)
            val lpc = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lpc.leftMargin = dpi(3)
            lpc.rightMargin = dpi(3)
            playRow.addView(chip, lpc)
        }
        val lpPR = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpPR.topMargin = dpi(6)
        root.addView(playRow, lpPR)

        val row3 = LinearLayout(this)
        row3.orientation = LinearLayout.HORIZONTAL
        val b1 = label("设置", 13f, gold, true)
        b1.gravity = Gravity.CENTER
        b1.setPadding(0, dpi(8), 0, dpi(8))
        b1.background = Ui.ghost(this, 18)
        Ui.press(b1)
        b1.setOnClickListener {
            hidePanel()
            openSettings()
        }
        val bc = label("聊天", 13f, gold, true)
        bc.gravity = Gravity.CENTER
        bc.setPadding(0, dpi(8), 0, dpi(8))
        bc.background = Ui.ghost(this, 18)
        Ui.press(bc)
        bc.setOnClickListener {
            hidePanel()
            openChat()
        }
        val b2 = label("收起", 13f, 0xFF0C1740.toInt(), true)
        b2.gravity = Gravity.CENTER
        b2.setPadding(0, dpi(8), 0, dpi(8))
        b2.background = Ui.goldFill(this, 18)
        Ui.press(b2)
        b2.setOnClickListener { hidePanel() }
        val lpb1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lpb1.rightMargin = dpi(4)
        val lpbc = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lpbc.leftMargin = dpi(4)
        lpbc.rightMargin = dpi(4)
        val lpb2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lpb2.leftMargin = dpi(4)
        row3.addView(b1, lpb1)
        row3.addView(bc, lpbc)
        row3.addView(b2, lpb2)
        val lpR3 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpR3.topMargin = dpi(12)
        root.addView(row3, lpR3)

        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
            false
        }

        root.measure(
            View.MeasureSpec.makeMeasureSpec(pw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ph = root.measuredHeight

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        // 二级界面：一个全屏的“罩子”窗口。背后的一级界面（桌宠和其他应用）整体变模糊、变暗，并且点不到；
        // 点空白处就收起面板，和 ColorOS 的二级弹层一样
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_DIM_BEHIND
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.dimAmount = 0f
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (blurOk) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 0
        }
        val m = dpi(6)
        val cx = petParams.x + v.padX + v.drawW / 2f
        val cardX = (cx - pw / 2f).toInt().coerceIn(m, maxOf(m, screenW - pw - m))
        val below = petParams.y + v.windowH / 2 < screenH / 2
        var py = if (below) {
            (petParams.y + v.windowH - v.padY + dpi(4)).toInt()
        } else {
            (petParams.y + v.padY - ph - dpi(4)).toInt()
        }
        if (py + ph > screenH - m) py = screenH - ph - m
        if (py < m) py = m
        val cardY = py
        panelPos = if (below) 2 else 1

        val scrim = android.widget.FrameLayout(this)
        scrim.setOnClickListener { hidePanel() }
        root.setOnClickListener { } // 点到卡片本身不收起
        val lpCard = android.widget.FrameLayout.LayoutParams(pw, ph)
        lpCard.leftMargin = cardX
        lpCard.topMargin = cardY
        scrim.addView(root, lpCard)

        // 从桌宠身上“长”出来：面板在桌宠下面就从上沿展开，在上面就从下沿展开
        root.alpha = 0f
        root.scaleX = 0.7f
        root.scaleY = 0.7f
        root.pivotX = (cx - cardX).coerceIn(0f, pw.toFloat())
        root.pivotY = if (below) 0f else ph.toFloat()
        try {
            wm.addView(scrim, lp)
        } catch (e: Exception) {
            panelPos = 0
            return
        }
        panelLp = lp
        panelCard = root
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(480L).setInterpolator(Ui.SPRING).start()
        panel = scrim
        animateBackdrop(true)
        pLv = lv
        pAffText = affText
        pAffBar = affBar
        pFullText = fullText
        pFullBar = fullBar
        updatePanelStats()
        updateBubblePos()
        handler.postDelayed(hidePanelRunnable, 15000L)
    }
    private val hidePanelRunnable = Runnable { hidePanel() }

    /** 背后的页面：随面板展开慢慢变模糊、变暗；收起时再慢慢恢复 */
    private fun animateBackdrop(open: Boolean) {
        val s = panel ?: return
        val lp = panelLp ?: return
        backdropAnim?.cancel()
        val blur = Ui.blurSupported(this)
        val blurMax = if (blur) dpi(16) else 0
        val dimMax = if (blur) 0.22f else 0.38f
        val va = android.animation.ValueAnimator.ofFloat(if (open) 0f else 1f, if (open) 1f else 0f)
        va.duration = if (open) 420L else 220L
        va.addUpdateListener {
            val p = it.animatedValue as Float
            lp.dimAmount = dimMax * p
            if (blurMax > 0) lp.blurBehindRadius = (blurMax * p).toInt()
            try {
                wm.updateViewLayout(s, lp)
            } catch (e: Exception) {
            }
        }
        backdropAnim = va
        va.start()
    }

    private fun hidePanelNow() {
        handler.removeCallbacks(hidePanelRunnable)
        val p = panel
        backdropAnim?.cancel()
        backdropAnim = null
        panelCard?.animate()?.cancel()
        panelCard = null
        panelLp = null
        if (p != null) {
            try {
                p.animate().cancel()
            } catch (e: Exception) {
            }
            try {
                wm.removeView(p)
            } catch (e: Exception) {
            }
        }
        panel = null
        panelPos = 0
        pLv = null
        pAffText = null
        pAffBar = null
        pFullText = null
        pFullBar = null
    }

    private fun hidePanel() {
        val p = panel
        val card = panelCard
        if (p == null || card == null) {
            hidePanelNow()
            updateBubblePos()
            return
        }
        // 收起：卡片缩回去，背后的模糊同时散开，然后再移除
        handler.removeCallbacks(hidePanelRunnable)
        card.animate().cancel()
        animateBackdrop(false)
        card.animate().alpha(0f).scaleX(0.7f).scaleY(0.7f).setDuration(220L)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .withEndAction {
                if (panel === p) {
                    hidePanelNow()
                    updateBubblePos()
                    if (popped && dockSide >= 0) scheduleRedock(1500L)
                }
            }.start()
    }

    private fun updatePanelStats() {
        if (panel == null) return
        val a = Bond.aff(prefs)
        val l = Bond.level(a)
        pLv?.text = "Lv." + (l + 1) + "  " + Bond.levelNames[l]
        pAffText?.text = if (l >= Bond.maxLevel()) "♥ " + a + " · 满级" else "♥ " + a + " / " + Bond.levelEnd(l)
        pAffBar?.setColors(0xFFFFE9A8.toInt(), 0xFFE5B84F.toInt())
        pAffBar?.progress = Bond.levelProgress(a)
        val f = Bond.fullness(prefs)
        pFullText?.text = "饱食度 " + f.toInt() + "%"
        if (f < 25f) pFullBar?.setColors(0xFFFFB0A0.toInt(), 0xFFFF6B6B.toInt())
        else pFullBar?.setColors(0xFFA8E6FF.toInt(), 0xFF5BB8F5.toInt())
        pFullBar?.progress = f / 100f
    }

    private fun feedFromPanel(f: Bond.Food) {
        handler.removeCallbacks(hidePanelRunnable)
        handler.postDelayed(hidePanelRunnable, 15000L)
        feed(f)
        updatePanelStats()
    }

    private fun feed(f: Bond.Food) {
        val v = pet ?: return
        val r = Bond.feed(prefs, f)
        if (!r.accepted) {
            v.shake()
            say("feed_full")
            return
        }
        v.eat(f.emoji)
        if (f.bad) {
            v.shake()
        } else {
            v.burstHearts(if (f.fav) 10 else 5)
        }
        val key = if (f.bad) "feed_bad" else if (f.fav) "feed_fav" else "feed_ok"
        val ms = say(key)
        if (r.levelUp) {
            handler.postDelayed({ announceLevelUp() }, minOf(ms, 3500L) + 400L)
        }
    }

    // ------------------------------------------------------------------ 玩耍 / 语音 / 游戏

    fun voiceSay(key: String, text: String) {
        voice?.speak(key, text)
    }

    fun setPetVisible(visible: Boolean) {
        petHidden = !visible
        val p = pet ?: return
        p.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        if (visible) {
            petParams.flags = petParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            petParams.flags = petParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            removeBubbleNow()
            hidePanelNow()
            voice?.stop()
        }
        updatePet()
    }

    fun onGameEnd(game: String, score: Int, leveled: Boolean) {
        setPetVisible(true)
        val v = pet ?: return
        var ms = 0L
        if (game == "catch" && score > 0) {
            val key = if (score >= 15) "catch_good" else "catch_bad"
            if (score >= 15) v.burstHearts(10)
            v.jump(10f)
            ms = say(key, "", "", score.toString())
        }
        if (leveled) {
            handler.postDelayed({ announceLevelUp() }, ms + 600L)
        }
        updatePanelStats()
    }

    private fun launchGame(g: String) {
        val i = Intent(this, GameActivity::class.java)
        i.putExtra("game", g)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i, Ui.pageOptions(this))
        } catch (e: Exception) {
        }
    }

    private fun onPlayChip(kind: Int) {
        when (kind) {
            0 -> {
                hidePanel()
                launchGame("catch")
            }
            1 -> {
                hidePanel()
                launchGame("rps")
            }
            2 -> {
                handler.removeCallbacks(hidePanelRunnable)
                handler.postDelayed(hidePanelRunnable, 15000L)
                drawFortune()
            }
            3 -> {
                hidePanel()
                toggleFocus()
            }
        }
    }

    private fun drawFortune() {
        val v = pet ?: return
        var idx = Bond.fortuneToday(prefs)
        var fresh = false
        if (idx < 0 || idx >= Bond.fortunes.size) {
            idx = Bond.rollFortune()
            Bond.saveFortune(prefs, idx)
            fresh = true
        }
        val f = Bond.fortunes[idx]
        val head = if (fresh) "\uD83D\uDD2E 今日签：" else "\uD83D\uDD2E 今天已经抽过啦："
        val text = (head + f.first + "\n" + f.second).replace("{name}", Prefs.name(prefs))
        val ms = showBubble(text, 9000L, "")
        v.burst(8)
        v.jump(8f)
        if (fresh && Bond.addAff(prefs, 2)) {
            handler.postDelayed({ announceLevelUp() }, ms + 400L)
        }
        updatePanelStats()
    }

    private val focusRunnable = Runnable {
        focusEnd = 0L
        val v = pet
        if (v != null) {
            v.spin()
            v.burstHearts(12)
        }
        val lu = Bond.playAff(prefs, 5)
        val ms = say("focus_done")
        if (lu) handler.postDelayed({ announceLevelUp() }, ms + 600L)
    }

    private fun toggleFocus() {
        val now = SystemClock.elapsedRealtime()
        if (focusEnd > now) {
            focusEnd = 0L
            handler.removeCallbacks(focusRunnable)
            say("focus_cancel")
            return
        }
        val min = prefs.getInt(Prefs.FOCUS_MIN, 25)
        focusEnd = now + min * 60000L
        handler.postDelayed(focusRunnable, min * 60000L)
        val ms = say("focus_start")
        if (ms == 0L) showBubble("专注开始，加油！", 4000L, "")
    }

    // ------------------------------------------------------------------ 时间相关

    private fun greetKey(h: Int): String = when {
        h in 5..10 -> "greet_morning"
        h in 11..13 -> "greet_noon"
        h in 14..17 -> "greet_afternoon"
        h in 18..22 -> "greet_evening"
        else -> "greet_night"
    }

    private fun inQuiet(h: Int): Boolean {
        if (!prefs.getBoolean(Prefs.QUIET_ON, false)) return false
        val from = prefs.getInt(Prefs.QUIET_FROM, 23)
        val to = prefs.getInt(Prefs.QUIET_TO, 7)
        if (from == to) return false
        return if (from < to) (h >= from && h < to) else (h >= from || h < to)
    }

    private val idleRunnable = Runnable {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (prefs.getBoolean(Prefs.CHAT, true) && !dragging && bubble == null && !walking && !inQuiet(h) &&
            focusEnd <= SystemClock.elapsedRealtime() && !petHidden) {
            val lv = Bond.level(Bond.aff(prefs))
            val key = when {
                prefs.getBoolean(Prefs.HUNGRY_TALK, true) && Bond.fullness(prefs) < 25f && Random.nextFloat() < 0.6f -> "hungry"
                Random.nextFloat() < 0.25f -> greetKey(h)
                lv >= 2 && Random.nextFloat() < 0.35f -> "idle_hi"
                else -> "idle"
            }
            val ms = say(key)
            if (dockSide < 0) pet?.jump(5f)
            if (popped) scheduleRedock(ms + 1200L)
        }
        scheduleIdle()
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(idleRunnable)
        if (!prefs.getBoolean(Prefs.CHAT, true)) return
        val base = prefs.getInt(Prefs.CHAT_SEC, 90) * 1000L
        val d = (base * (0.6 + Random.nextDouble() * 0.8)).toLong()
        handler.postDelayed(idleRunnable, d)
    }

    private val wanderRunnable = Runnable {
        doWander()
        scheduleWander()
    }

    private fun scheduleWander() {
        handler.removeCallbacks(wanderRunnable)
        if (!prefs.getBoolean(Prefs.WANDER, false)) return
        val base = prefs.getInt(Prefs.WANDER_SEC, 60) * 1000L
        val d = (base * (0.6 + Random.nextDouble() * 0.8)).toLong()
        handler.postDelayed(wanderRunnable, d)
    }

    private fun doWander() {
        val v = pet ?: return
        if (dragging || walking || panel != null) return
        handler.removeCallbacks(redockRunnable)
        val minV = (-v.padX + dpi(6)).toInt()
        val maxV = (screenW - v.drawW - v.padX - dpi(6)).toInt()
        if (maxV <= minV) return
        val tx = minV + Random.nextInt(maxV - minV + 1)
        val ty = (petParams.y + Random.nextInt(-dpi(60), dpi(60) + 1))
            .coerceIn(0, maxOf(0, screenH - v.windowH))
        val dist = abs(tx - petParams.x)
        val dur = (dist / (90f * density) * 1000f).toLong().coerceIn(700L, 7000L)
        dockSide = -1
        popped = false
        walking = true
        v.setDock(-1, 0f)
        v.setFacing(if (tx >= petParams.x) 1 else -1)
        v.setWalking(true)
        animateTo(tx, ty, dur, LinearInterpolator()) {
            walking = false
            v.setWalking(false)
            v.setFacing(1)
            if (prefs.getBoolean(Prefs.AUTO_DOCK, true) && Random.nextFloat() < 0.4f) {
                val side = if (petParams.x + v.padX + v.drawW / 2f < screenW / 2f) 0 else 1
                dockToSide(side)
            } else {
                v.jump(6f)
                savePos()
            }
        }
    }

    private val minuteRunnable = object : Runnable {
        override fun run() {
            onMinute()
            val now = System.currentTimeMillis()
            handler.postDelayed(this, 60000L - now % 60000L + 200L)
        }
    }

    private fun onMinute() {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val quiet = inQuiet(h)
        val nowRt = SystemClock.elapsedRealtime()
        var ms = 0L

        if (!quiet && !dragging) {
            if (prefs.getBoolean(Prefs.HOURLY, false) && m == 0) {
                ms = say("hourly", String.format("%02d:%02d", h, m))
            }
            if (prefs.getBoolean(Prefs.WATER_ON, false) &&
                nowRt - lastWater >= prefs.getInt(Prefs.WATER_MIN, 60) * 60000L
            ) {
                lastWater = nowRt
                ms = say("water")
            }
            if (prefs.getBoolean(Prefs.REST_ON, false) &&
                nowRt - lastRest >= prefs.getInt(Prefs.REST_MIN, 45) * 60000L
            ) {
                lastRest = nowRt
                ms = say("rest")
            }
        }

        val raw = prefs.getString(Prefs.REMINDERS, "") ?: ""
        val re = Regex("^\\s*(\\d{1,2})[:：](\\d{2})\\s*(.*)$")
        for (line in raw.split("\n")) {
            val mt = re.find(line) ?: continue
            val hh = mt.groupValues[1].toIntOrNull() ?: continue
            val mm = mt.groupValues[2].toIntOrNull() ?: continue
            if (hh == h && mm == m) {
                val txt = mt.groupValues[3].trim().ifEmpty { "时间到啦！" }
                val shown = "⏰ " + txt.replace("{name}", Prefs.name(prefs))
                ms = showBubble(shown, 10000L)
                pet?.shake()
                pet?.burst(10)
            }
        }
        if (ms > 0L && popped) scheduleRedock(ms + 1200L)
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!prefs.getBoolean(Prefs.BATTERY_TALK, true) || intent == null) return
            if (dragging) return
            when (intent.action) {
                Intent.ACTION_BATTERY_LOW -> {
                    pet?.shake()
                    say("lowbat")
                }
                Intent.ACTION_POWER_CONNECTED -> {
                    pet?.jump(8f)
                    pet?.burst(8)
                    say("charging")
                }
            }
        }
    }
}

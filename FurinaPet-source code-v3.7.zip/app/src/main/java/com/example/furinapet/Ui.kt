package com.example.furinapet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.KeyEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.media.MediaPlayer
import android.content.DialogInterface
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.view.Window
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max

/** 界面风格：芙宁娜的水蓝 + 金色，磨砂玻璃卡片、半透明模糊弹窗、可自定义背景 */
object Ui {

    const val GOLD = 0xFFE5C26B.toInt()
    const val GOLD_LIGHT = 0xFFF4DE9C.toInt()
    const val GOLD_DEEP = 0xFFD9AE4E.toInt()

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    private fun withAlpha(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun a(color: Int, f: Float): Int = withAlpha(color, (f * 255f).toInt())

    /** 磨砂玻璃：半透明的水蓝渐变 + 顶部一层淡淡的亮面 + 金色细边 */
    fun glass(ctx: Context, radiusDp: Int, alpha: Int = 0xA8): Drawable {
        val r = dp(ctx, radiusDp).toFloat()
        val base = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(withAlpha(0xFF2A4694.toInt(), alpha), withAlpha(0xFF0F1A4D.toInt(), alpha))
        )
        base.cornerRadius = r
        base.setStroke(dp(ctx, 1), 0x66E5C26B)
        val shine = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x24FFFFFF, 0x00FFFFFF, 0x00FFFFFF)
        )
        shine.cornerRadius = r
        return LayerDrawable(arrayOf(base, shine))
    }

    /** 金色实心（主按钮、自己发的气泡） */
    fun goldFill(ctx: Context, radiusDp: Int): Drawable {
        val d = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(GOLD_LIGHT, GOLD_DEEP))
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        return d
    }

    /** 次要按钮：透明底 + 金色描边 */
    fun ghost(ctx: Context, radiusDp: Int): Drawable {
        val d = GradientDrawable()
        d.setColor(0x14FFFFFF)
        d.cornerRadius = dp(ctx, radiusDp).toFloat()
        d.setStroke(dp(ctx, 1), 0x99E5C26B.toInt())
        return d
    }

    // ------------------------------------------------------------------ 动效（弹簧）

    val SPRING: Interpolator = SpringInterpolator()

    @Volatile
    private var touchX = -1f

    @Volatile
    private var touchY = -1f

    @Volatile
    private var touchT = 0L

    @Volatile
    private var originX = -1f

    @Volatile
    private var originY = -1f

    @Volatile
    private var originT = 0L

    private var originRef: java.lang.ref.WeakReference<View>? = null

    /** 记下手指按下的位置（弹窗里的按钮也会记） */
    fun noteTouch(e: MotionEvent) {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            touchX = e.rawX
            touchY = e.rawY
            touchT = SystemClock.uptimeMillis()
        }
    }

    /** 记下被点的按钮：新窗口会从这个按钮“长”出来 */
    fun noteOrigin(v: View) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        originX = loc[0] + v.width / 2f
        originY = loc[1] + v.height / 2f
        originT = SystemClock.uptimeMillis()
        originRef = java.lang.ref.WeakReference(v)
    }

    /** 最近 2 秒内的起点：优先用被点的按钮中心，其次用手指位置；都没有就返回 null */
    private fun recentOrigin(): FloatArray? {
        val now = SystemClock.uptimeMillis()
        if (originX >= 0f && now - originT < 2000L && originT >= touchT) return floatArrayOf(originX, originY)
        if (touchX >= 0f && now - touchT < 2000L) return floatArrayOf(touchX, touchY)
        return null
    }

    /** 弹窗进入：从被点的按钮位置“长”出来（先小后大，带一点回弹），同时背后的页面后退 */
    fun springIn(v: View) {
        v.post {
            val w = v.width.toFloat()
            val h = v.height.toFloat()
            if (w <= 0f || h <= 0f) {
                v.alpha = 1f
                return@post
            }
            var px = w / 2f
            var py = h / 2f
            val o = recentOrigin()
            if (o != null) {
                val loc = IntArray(2)
                v.getLocationOnScreen(loc)
                px = (o[0] - loc[0]).coerceIn(0f, w)
                py = (o[1] - loc[1]).coerceIn(0f, h)
            }
            v.pivotX = px
            v.pivotY = py
            v.tag = floatArrayOf(px, py) // 关闭时缩回同一个点
            v.scaleX = 0.55f
            v.scaleY = 0.55f
            v.alpha = 0f
            val anim = ValueAnimator.ofFloat(0f, 1f)
            anim.duration = 480L
            anim.interpolator = SPRING
            anim.addUpdateListener {
                val p = it.animatedValue as Float
                val sc = 0.55f + 0.45f * p
                v.scaleX = sc
                v.scaleY = sc
                v.alpha = (p * 3f).coerceIn(0f, 1f)
            }
            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    v.scaleX = 1f
                    v.scaleY = 1f
                    v.alpha = 1f
                }
            })
            anim.start()
        }
        // 保险：万一动画没跑起来，也不能让窗口一直透明
        v.postDelayed({ if (v.alpha < 1f) v.alpha = 1f }, 1000L)
    }

    /** 弹窗关闭：缩回它长出来的那个按钮，同时淡出 */
    fun springOut(v: View?, onEnd: () -> Unit) {
        if (v == null) {
            onEnd()
            return
        }
        var done = false
        val finish = {
            if (!done) {
                done = true
                onEnd()
            }
        }
        val pv = v.tag as? FloatArray
        if (pv != null) {
            v.pivotX = pv[0]
            v.pivotY = pv[1]
        }
        v.animate().cancel()
        v.animate().scaleX(0.55f).scaleY(0.55f).alpha(0f).setDuration(240L)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction { finish() }.start()
        v.postDelayed({ finish() }, 700L) // 保险
    }

    /** 按下去轻轻缩小，松手弹回来；同时记下这个按钮，新窗口从它这里长出来 */
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    noteOrigin(view)
                    view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(110L)
                        .setInterpolator(DecelerateInterpolator()).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(420L).setInterpolator(SPRING).start()
            }
            false
        }
    }

    /** 打开新页面的动画：从被点的按钮放大出来；没有按钮可依附时用弹性放大 */
    fun pageOptions(ctx: Context): Bundle? {
        try {
            val v = originRef?.get()
            if (ctx is Activity && v != null && v.isAttachedToWindow && v.width > 0 &&
                SystemClock.uptimeMillis() - originT < 2000L
            ) {
                return ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()
            }
        } catch (e: Throwable) {
        }
        return try {
            ActivityOptions.makeCustomAnimation(ctx, R.anim.page_enter, R.anim.page_behind).toBundle()
        } catch (e: Throwable) {
            null
        }
    }

    /** 关闭页面的动画（缩小淡出，下面的页面回到原位） */
    @Suppress("DEPRECATION")
    fun closeTransition(act: Activity) {
        try {
            act.overridePendingTransition(R.anim.page_back_enter, R.anim.page_leave)
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------------ 模糊支持

    fun blurSupported(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        return try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.isCrossWindowBlurEnabled
        } catch (e: Throwable) {
            false
        }
    }

    /** 弹窗：半透明磨砂 + 背后内容模糊（Android 12+ 且系统允许时），不支持时退回更不透明的玻璃，保证看得清 */
    fun frostWindow(w: Window?) {
        if (w == null) return
        val ctx = w.context
        val blur = blurSupported(ctx)
        w.setBackgroundDrawable(glass(ctx, 22, if (blur) 0x92 else 0xEA))
        w.setDimAmount(if (blur) 0.22f else 0.4f)
        if (blur) {
            try {
                // 整个后面的一级界面都模糊（并且因为是弹窗，点不到它）；模糊度随弹出动画慢慢加深
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val a = w.attributes
                val maxBehind = dp(ctx, 16)
                val va = ValueAnimator.ofFloat(0f, 1f)
                va.duration = 420L
                va.interpolator = DecelerateInterpolator()
                va.addUpdateListener {
                    try {
                        val p = it.animatedValue as Float
                        a.blurBehindRadius = (maxBehind * p).toInt()
                        w.attributes = a
                        w.setBackgroundBlurRadius((70f * p).toInt())
                    } catch (e: Throwable) {
                    }
                }
                va.start()
            } catch (e: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ 页面背景

    private const val BG_FILE = "ui_bg.jpg"

    fun bgFile(ctx: Context): File = File(ctx.filesDir, BG_FILE)
    fun hasBackground(ctx: Context): Boolean = bgFile(ctx).isFile

    private const val VIDEO_FILE = "ui_bg_video.mp4"
    private const val MAX_VIDEO = 80L * 1024L * 1024L

    fun videoFile(ctx: Context): File = File(ctx.filesDir, VIDEO_FILE)
    fun hasVideo(ctx: Context): Boolean = videoFile(ctx).isFile

    /** 保存用户选的背景视频（静音循环播放用）。最大 80MB。 */
    fun saveBackgroundVideo(ctx: Context, uri: Uri) {
        val tmp = File(ctx.filesDir, "ui_bg_video.tmp")
        tmp.delete()
        try {
            val ins = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法读取这个视频")
            var total = 0L
            ins.use { src ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val r = src.read(buf)
                        if (r < 0) break
                        total += r
                        if (total > MAX_VIDEO) throw IllegalStateException("视频太大了（超过 80MB），请选短一点或压缩过的视频")
                        out.write(buf, 0, r)
                    }
                }
            }
            if (total < 1024L) throw IllegalStateException("视频文件太小，可能不是有效的视频")
            val dst = videoFile(ctx)
            dst.delete()
            if (!tmp.renameTo(dst)) {
                tmp.copyTo(dst, true)
                tmp.delete()
            }
            bgFile(ctx).delete()
            cacheBmp = null
            Prefs.get(ctx).edit().putLong(Prefs.UI_BG_VER, System.currentTimeMillis()).apply()
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
    }

    /** 默认背景：深水蓝渐变 + 左上角一团柔光 */
    fun defaultBackground(ctx: Context): Drawable {
        val base = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0A1332.toInt(), 0xFF13265E.toInt(), 0xFF0B1946.toInt())
        )
        val glow = GradientDrawable()
        glow.gradientType = GradientDrawable.RADIAL_GRADIENT
        glow.gradientRadius = dp(ctx, 460).toFloat()
        glow.setGradientCenter(0.15f, 0.02f)
        glow.colors = intArrayOf(0x405A8CF0, 0x00000000)
        return LayerDrawable(arrayOf(base, glow))
    }

    private var cacheKey = ""
    private var cacheBmp: Bitmap? = null

    fun pageBackground(ctx: Context): Drawable {
        if (!hasBackground(ctx)) return defaultBackground(ctx)
        val p = Prefs.get(ctx)
        val blur = p.getInt(Prefs.UI_BG_BLUR, 40)
        val dim = p.getInt(Prefs.UI_BG_DIM, 35)
        val key = p.getLong(Prefs.UI_BG_VER, 0L).toString() + "|" + blur
        var bmp = cacheBmp
        if (bmp == null || cacheKey != key) {
            val src = try {
                BitmapFactory.decodeFile(bgFile(ctx).absolutePath)
            } catch (e: Throwable) {
                null
            } ?: return defaultBackground(ctx)
            bmp = soften(src, blur)
            cacheBmp = bmp
            cacheKey = key
        }
        return CoverDrawable(bmp!!, (dim * 255 / 100).coerceIn(0, 255))
    }

    /** 先缩小再放大就是模糊：level 越大缩得越小 */
    private fun soften(src: Bitmap, level: Int): Bitmap {
        if (level <= 0) return src
        val factor = 1f + level / 5f
        val tw = max(8, (src.width / factor).toInt())
        val th = max(8, (src.height / factor).toInt())
        var cur = src
        while (cur.width / 2 > tw && cur.height / 2 > th) {
            cur = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
        }
        return Bitmap.createScaledBitmap(cur, tw, th, true)
    }

    /** 保存用户选的背景图（缩到长边 1600 以内，并处理照片方向） */
    fun saveBackground(ctx: Context, uri: Uri) {
        val cr = ctx.contentResolver
        val opts = BitmapFactory.Options()
        opts.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (opts.outWidth <= 0 || opts.outHeight <= 0) throw IllegalStateException("无法读取这张图片")
        var sample = 1
        while (max(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalStateException("无法读取这张图片")

        var deg = 0
        try {
            cr.openInputStream(uri)?.use { ins ->
                val o = ExifInterface(ins).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                deg = when (o) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            }
        } catch (e: Exception) {
        }
        if (deg != 0) {
            val m = Matrix()
            m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        val tmp = File(ctx.filesDir, "ui_bg.tmp")
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        val dst = bgFile(ctx)
        dst.delete()
        if (!tmp.renameTo(dst)) {
            tmp.copyTo(dst, true)
            tmp.delete()
        }
        videoFile(ctx).delete()
        cacheBmp = null
        Prefs.get(ctx).edit().putLong(Prefs.UI_BG_VER, System.currentTimeMillis()).apply()
    }

    /** 一键恢复默认背景（图片和视频都清掉） */
    fun resetBackground(ctx: Context) {
        bgFile(ctx).delete()
        videoFile(ctx).delete()
        cacheBmp = null
        Prefs.get(ctx).edit().putLong(Prefs.UI_BG_VER, System.currentTimeMillis()).apply()
    }
}

/** 居中裁剪铺满 + 一层压暗，保证上面的文字看得清 */
class CoverDrawable(private val bmp: Bitmap, private val dimAlpha: Int) : Drawable() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val scrim = Paint()
    private val dst = RectF()

    init {
        scrim.color = Color.argb(dimAlpha, 6, 14, 40)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val s = max(b.width() / bw, b.height() / bh)
        val dw = bw * s
        val dh = bh * s
        val l = b.left + (b.width() - dw) / 2f
        val t = b.top + (b.height() - dh) / 2f
        dst.set(l, t, l + dw, t + dh)
        canvas.save()
        canvas.clipRect(b)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
        canvas.drawRect(b, scrim)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/**
 * 统一风格的弹窗（二级界面）：从被点的按钮“长”出来，关闭时再缩回那个按钮；
 * 背后的一级界面整体模糊（Android 12+），并且点不到。
 */
class GlassDialog(private val host: Context) {
    private val b = AlertDialog.Builder(host, R.style.FurinaDialog)
    private var posL: DialogInterface.OnClickListener? = null
    private var negL: DialogInterface.OnClickListener? = null
    private var neuL: DialogInterface.OnClickListener? = null
    private var itemsL: DialogInterface.OnClickListener? = null
    private var cancelable = true
    private var outsideHandler: ((MotionEvent) -> Boolean)? = null

    fun setTitle(t: CharSequence?): GlassDialog {
        b.setTitle(t)
        return this
    }

    fun setMessage(m: CharSequence?): GlassDialog {
        b.setMessage(m)
        return this
    }

    fun setView(v: View?): GlassDialog {
        b.setView(v)
        return this
    }

    fun setCancelable(c: Boolean): GlassDialog {
        cancelable = c
        b.setCancelable(c)
        return this
    }

    fun setPositiveButton(t: CharSequence?, l: DialogInterface.OnClickListener?): GlassDialog {
        posL = l
        b.setPositiveButton(t, l)
        return this
    }

    fun setNegativeButton(t: CharSequence?, l: DialogInterface.OnClickListener?): GlassDialog {
        negL = l
        b.setNegativeButton(t, l)
        return this
    }

    fun setNeutralButton(t: CharSequence?, l: DialogInterface.OnClickListener?): GlassDialog {
        neuL = l
        b.setNeutralButton(t, l)
        return this
    }

    fun setItems(items: Array<out CharSequence>, l: DialogInterface.OnClickListener?): GlassDialog {
        itemsL = l
        b.setItems(items, l)
        return this
    }

    fun setMultiChoiceItems(
        items: Array<out CharSequence>,
        checked: BooleanArray?,
        l: DialogInterface.OnMultiChoiceClickListener?
    ): GlassDialog {
        b.setMultiChoiceItems(items, checked, l)
        return this
    }

    /** 只带样式和弹出动画（进度框这类自己管关闭的弹窗用这个） */
    fun create(): AlertDialog {
        val d = b.create()
        try {
            d.window?.decorView?.alpha = 0f // 先藏起来，等弹出动画开始再显示，避免闪一下
        } catch (e: Throwable) {
        }
        d.setOnShowListener {
            Ui.frostWindow(d.window)
            try {
                // 弹窗里的按钮被点时也记下位置，从弹窗再弹出的窗口也从那个按钮长出来
                val win = d.window
                if (win != null) win.callback = TouchRelay(win.callback) { e -> outsideHandler?.invoke(e) ?: false }
            } catch (e: Throwable) {
            }
            val dv = d.window?.decorView
            if (dv != null) Ui.springIn(dv)
        }
        return d
    }

    /** 显示，并让关闭（按钮、列表项、返回键、点外面）都播放“缩回按钮”的动画 */
    fun show(): AlertDialog {
        val d = create()
        d.show()
        hookClose(d)
        return d
    }

    private fun hookClose(d: AlertDialog) {
        var closing = false
        fun closeWith(after: () -> Unit) {
            if (closing) return
            closing = true
            Ui.springOut(d.window?.decorView) {
                try {
                    d.window?.setWindowAnimations(0) // 已经自己演完了，不再播系统的退出动画
                } catch (e: Throwable) {
                }
                after()
            }
        }

        val pairs = listOf(
            Pair(DialogInterface.BUTTON_POSITIVE, posL),
            Pair(DialogInterface.BUTTON_NEGATIVE, negL),
            Pair(DialogInterface.BUTTON_NEUTRAL, neuL)
        )
        for (pr in pairs) {
            val btn = d.getButton(pr.first) ?: continue
            val l = pr.second
            btn.setOnClickListener {
                closeWith {
                    l?.onClick(d, pr.first)
                    d.dismiss()
                }
            }
        }
        val il = itemsL
        if (il != null) {
            d.listView?.setOnItemClickListener { _, _, pos, _ ->
                closeWith {
                    il.onClick(d, pos)
                    d.dismiss()
                }
            }
        }
        if (cancelable) {
            d.setOnKeyListener { _, keyCode, e ->
                if (keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) {
                    closeWith { d.cancel() }
                    true
                } else {
                    false
                }
            }
            outsideHandler = { e ->
                val dv = d.window?.decorView
                var outside = e.action == MotionEvent.ACTION_OUTSIDE
                if (!outside && e.action == MotionEvent.ACTION_DOWN && dv != null) {
                    val slop = android.view.ViewConfiguration.get(host).scaledWindowTouchSlop
                    val x = e.x.toInt()
                    val y = e.y.toInt()
                    outside = x < -slop || y < -slop || x > dv.width + slop || y > dv.height + slop
                }
                if (outside) closeWith { d.cancel() }
                outside
            }
        }
    }
}

/** 把触摸事件先交给 Ui 记位置（以及处理点弹窗外面），再交还给原来的窗口回调 */
class TouchRelay(
    private val base: android.view.Window.Callback,
    private val onOutside: (MotionEvent) -> Boolean
) : android.view.Window.Callback by base {
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        Ui.noteTouch(event)
        if (onOutside(event)) return true
        return base.dispatchTouchEvent(event)
    }
}

/** 弹簧插值：先冲过头一点再回弹到位（ColorOS 那种流体弹性的手感） */
class SpringInterpolator(private val damping: Float = 0.62f, private val freq: Float = 1.6f) : Interpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        if (t <= 0f) return 0f
        val w = (2.0 * PI * freq).toFloat()
        val decay = exp((-damping * 10f * t).toDouble()).toFloat()
        return 1f - decay * cos((w * t).toDouble()).toFloat()
    }
}

/** 页面底层：默认渐变 / 自定义图片 / 循环播放的视频；上面再盖一层压暗，保证文字看得清 */
class PageHost(private val ctx: Context) : FrameLayout(ctx) {
    private var video: VideoBg? = null
    private var shownVer = -1L
    private val dim = View(ctx)

    init {
        addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        refresh()
    }

    /** 换了背景（图片/视频/恢复默认）之后调用 */
    fun refresh() {
        val p = Prefs.get(ctx)
        if (Ui.hasVideo(ctx)) {
            background = Ui.defaultBackground(ctx)
            val ver = p.getLong(Prefs.UI_BG_VER, 0L)
            if (video == null || shownVer != ver) {
                removeVideo()
                val v = VideoBg(ctx, Ui.videoFile(ctx).absolutePath)
                addView(v, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                video = v
                shownVer = ver
            }
            val d = p.getInt(Prefs.UI_BG_DIM, 35)
            dim.setBackgroundColor(Color.argb((d * 255 / 100).coerceIn(0, 255), 6, 12, 40))
        } else {
            removeVideo()
            background = Ui.pageBackground(ctx)
            dim.setBackgroundColor(0)
        }
    }

    private fun removeVideo() {
        val v = video
        if (v != null) {
            v.release()
            removeView(v)
        }
        video = null
        shownVer = -1L
    }

    fun pauseVideo() {
        video?.pause()
    }

    fun resumeVideo() {
        video?.resume()
    }

    fun release() {
        removeVideo()
    }
}

/** 静音、循环、居中裁剪铺满的视频背景 */
class VideoBg(ctx: Context, private val path: String) : TextureView(ctx), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private var surface: Surface? = null
    private var vw = 0
    private var vh = 0
    private var wantPlay = true
    private var prepared = false

    init {
        surfaceTextureListener = this
        isOpaque = true
    }

    private fun startPlayer() {
        stopPlayer()
        val s = surface ?: return
        val p = MediaPlayer()
        try {
            p.setDataSource(path)
            p.setSurface(s)
            p.isLooping = true
            p.setVolume(0f, 0f)
            p.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            p.setOnPreparedListener {
                prepared = true
                if (wantPlay) it.start()
            }
            p.setOnErrorListener { _, _, _ -> true }
            p.prepareAsync()
            mp = p
        } catch (e: Throwable) {
            try {
                p.release()
            } catch (x: Throwable) {
            }
        }
    }

    private fun stopPlayer() {
        prepared = false
        val p = mp
        mp = null
        if (p != null) {
            try {
                p.release()
            } catch (e: Throwable) {
            }
        }
    }

    /** TextureView 默认把画面拉伸到整个控件，这里反向缩放成“居中裁剪” */
    private fun fit() {
        if (vw <= 0 || vh <= 0 || width <= 0 || height <= 0) return
        val scale = max(width.toFloat() / vw, height.toFloat() / vh)
        val sx = vw * scale / width
        val sy = vh * scale / height
        val m = Matrix()
        m.setScale(sx, sy, width / 2f, height / 2f)
        setTransform(m)
    }

    fun pause() {
        wantPlay = false
        try {
            if (prepared) mp?.pause()
        } catch (e: Throwable) {
        }
    }

    fun resume() {
        wantPlay = true
        try {
            if (prepared) mp?.start()
        } catch (e: Throwable) {
        }
    }

    fun release() {
        stopPlayer()
        surface?.release()
        surface = null
    }

    override fun onSurfaceTextureAvailable(st: android.graphics.SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        startPlayer()
    }

    override fun onSurfaceTextureSizeChanged(st: android.graphics.SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: android.graphics.SurfaceTexture): Boolean {
        stopPlayer()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: android.graphics.SurfaceTexture) {}
}

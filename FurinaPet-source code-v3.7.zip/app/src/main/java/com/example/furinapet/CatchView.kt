package com.example.furinapet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/** 接甜点小游戏：左右拖动桌宠接住掉落的甜点，别接西兰花，漏掉甜点也会扣血。 */
class CatchView(
    context: Context,
    private val sprite: Bitmap?,
    bestInit: Int,
    private val listener: Listener
) : View(context) {

    interface Listener {
        /** 返回本局获得的好感度 */
        fun onGameOver(score: Int, newBest: Boolean): Int
        fun onExit()
    }

    private class Item(var x: Float, var y: Float, val speed: Float, val food: Bond.Food)

    private val d = context.resources.displayMetrics.density
    private val items = ArrayList<Item>()
    private val starPos = ArrayList<FloatArray>()

    private var best = bestInit
    private var state = 0 // 0 准备, 1 进行中, 2 结束
    private var score = 0
    private var lives = 3
    private var elapsed = 0f
    private var spawnT = 0f
    private var catcherX = 0f
    private var gain = 0
    private var newBest = false
    private var flash = 0f

    private var catchW = 0f
    private var catchH = 0f
    private var catchTop = 0f

    private val bgPaint = Paint()
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spritePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private val btnAgain = RectF()
    private val btnExit = RectF()

    private var attached = false
    private var last = 0.0

    init {
        emojiPaint.textAlign = Paint.Align.CENTER
        emojiPaint.textSize = 34f * d
        textPaint.color = 0xFFEAF1FF.toInt()
        textPaint.typeface = Typeface.DEFAULT_BOLD
        dotPaint.color = 0xFFFFFFFF.toInt()
        dotPaint.alpha = 110
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), 0xFF0B1230.toInt(), 0xFF24449A.toInt(), Shader.TileMode.CLAMP
        )
        starPos.clear()
        for (i in 0 until 40) {
            starPos.add(floatArrayOf(Random.nextFloat() * w, Random.nextFloat() * h, (1f + Random.nextFloat() * 2f) * d))
        }
        catchH = 110f * d
        val asp = if (sprite != null) sprite.width.toFloat() / sprite.height.toFloat() else 0.73f
        catchW = catchH * asp
        catchTop = h - 24f * d - catchH
        catcherX = w / 2f
    }

    private fun resetGame() {
        items.clear()
        score = 0
        lives = 3
        elapsed = 0f
        spawnT = 0.3f
        flash = 0f
        newBest = false
        gain = 0
        state = 1
    }

    private fun spawn() {
        val bad = Random.nextFloat() < 0.2f
        val pool = ArrayList<Bond.Food>()
        for (f in Bond.foods) {
            if (f.bad == bad) pool.add(f)
        }
        val food = pool[Random.nextInt(pool.size)]
        val speed = (200f + elapsed * 5f) * d * (0.85f + Random.nextFloat() * 0.4f)
        val x = 30f * d + Random.nextFloat() * (width - 60f * d)
        items.add(Item(x, -30f * d, speed, food))
    }

    private fun gameOver() {
        state = 2
        newBest = score > best
        if (newBest) best = score
        gain = listener.onGameOver(score, newBest)
    }

    private fun update(dt: Float) {
        if (flash > 0f) flash = max(0f, flash - dt * 2f)
        if (state != 1) return
        elapsed += dt
        spawnT -= dt
        if (spawnT <= 0f) {
            spawnT = max(0.35f, 0.95f - elapsed * 0.01f)
            spawn()
        }
        val iter = items.iterator()
        while (iter.hasNext()) {
            val it2 = iter.next()
            it2.y += it2.speed * dt
            val inBand = it2.y > catchTop + 0.1f * catchH && it2.y < catchTop + 0.55f * catchH
            if (inBand && abs(it2.x - catcherX) < catchW * 0.5f) {
                iter.remove()
                if (it2.food.bad) {
                    lives--
                    flash = 1f
                } else {
                    score += if (it2.food.fav) 3 else 1
                }
            } else if (it2.y > height + 40f * d) {
                iter.remove()
                if (!it2.food.bad) {
                    lives--
                    flash = 1f
                }
            }
        }
        if (lives <= 0) gameOver()
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!attached) return
            val now = frameTimeNanos / 1_000_000_000.0
            if (last == 0.0) last = now
            var dt = (now - last).toFloat()
            last = now
            if (dt > 0.04f) dt = 0.04f
            update(dt)
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        last = 0.0
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onDetachedFromWindow() {
        attached = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        super.onDetachedFromWindow()
    }

    private fun centerText(c: Canvas, s: String, y: Float, sizeSp: Float, color: Int) {
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = sizeSp * d
        textPaint.color = color
        c.drawText(s, width / 2f, y, textPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        for (s in starPos) canvas.drawCircle(s[0], s[1], s[2], dotPaint)

        for (it2 in items) canvas.drawText(it2.food.emoji, it2.x, it2.y, emojiPaint)

        if (sprite != null) {
            dst.set(catcherX - catchW / 2f, catchTop, catcherX + catchW / 2f, catchTop + catchH)
            canvas.drawBitmap(sprite, null, dst, spritePaint)
        }

        // HUD
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 20f * d
        textPaint.color = 0xFFE5C26B.toInt()
        canvas.drawText("得分 " + score, 18f * d, 44f * d, textPaint)
        textPaint.textSize = 12f * d
        textPaint.color = 0xFF9FB0DC.toInt()
        canvas.drawText("最高 " + best, 18f * d, 62f * d, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        textPaint.textSize = 22f * d
        textPaint.color = 0xFFFF8FB1.toInt()
        canvas.drawText("♥".repeat(max(lives, 0)), w - 18f * d, 44f * d, textPaint)

        if (flash > 0f) {
            val a = (flash * 90f).toInt()
            canvas.drawColor((a shl 24) or 0x00FF3030)
        }

        if (state == 0) {
            canvas.drawColor(0x99000000.toInt())
            centerText(canvas, "接甜点", h * 0.34f, 30f, 0xFFE5C26B.toInt())
            centerText(canvas, "左右拖动芙宁娜，接住掉落的甜点", h * 0.34f + 44f * d, 15f, 0xFFEAF1FF.toInt())
            centerText(canvas, "最爱的甜点 +3 分，别接西兰花", h * 0.34f + 70f * d, 15f, 0xFFEAF1FF.toInt())
            centerText(canvas, "漏掉甜点或接到西兰花会掉 ♥", h * 0.34f + 96f * d, 15f, 0xFFEAF1FF.toInt())
            centerText(canvas, "点击屏幕开始", h * 0.34f + 150f * d, 18f, 0xFFFFFFFF.toInt())
        } else if (state == 2) {
            canvas.drawColor(0xCC000000.toInt())
            val cx = w / 2f
            val top = h * 0.28f
            boxPaint.color = 0xFF121D4A.toInt()
            canvas.drawRoundRect(cx - 150f * d, top, cx + 150f * d, top + 300f * d, 24f * d, 24f * d, boxPaint)
            centerText(canvas, "演出结束", top + 48f * d, 24f, 0xFFE5C26B.toInt())
            centerText(canvas, "得分 " + score, top + 100f * d, 34f, 0xFFFFFFFF.toInt())
            if (newBest) centerText(canvas, "新纪录！", top + 134f * d, 16f, 0xFFFF8FB1.toInt())
            else centerText(canvas, "最高 " + best, top + 134f * d, 14f, 0xFF9FB0DC.toInt())
            val g = if (gain > 0) "好感 +" + gain else "今天的好感奖励已达上限"
            centerText(canvas, g, top + 170f * d, 15f, 0xFFFF8FB1.toInt())

            btnAgain.set(cx - 130f * d, top + 205f * d, cx - 8f * d, top + 255f * d)
            btnExit.set(cx + 8f * d, top + 205f * d, cx + 130f * d, top + 255f * d)
            boxPaint.color = 0xFFE5C26B.toInt()
            canvas.drawRoundRect(btnAgain, 25f * d, 25f * d, boxPaint)
            boxPaint.color = 0xFF2B3F8F.toInt()
            canvas.drawRoundRect(btnExit, 25f * d, 25f * d, boxPaint)
            centerBtn(canvas, "再来一局", btnAgain, 0xFF0B1230.toInt())
            centerBtn(canvas, "返回", btnExit, 0xFFEAF1FF.toInt())
        }
    }

    private fun centerBtn(c: Canvas, s: String, r: RectF, color: Int) {
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 16f * d
        textPaint.color = color
        c.drawText(s, r.centerX(), r.centerY() + 6f * d, textPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (state == 0) {
                    resetGame()
                } else if (state == 2) {
                    if (btnAgain.contains(e.x, e.y)) {
                        resetGame()
                    } else if (btnExit.contains(e.x, e.y)) {
                        listener.onExit()
                    }
                }
                if (state == 1) catcherX = e.x.coerceIn(catchW / 2f, width - catchW / 2f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (state == 1) catcherX = e.x.coerceIn(catchW / 2f, width - catchW / 2f)
            }
        }
        return true
    }
}

package com.example.furinapet

import android.content.SharedPreferences
import java.util.Calendar
import java.util.Locale

/** 工作模式的“已确认事实”：内置的常用官方网址，查网址时直接回答，不让模型凭印象瞎编。 */
object WorkKnowledge {

    private class Site(val names: List<String>, val label: String, val url: String)

    private val sites = listOf(
        Site(listOf("百度"), "百度", "https://www.baidu.com"),
        Site(listOf("百度地图"), "百度地图", "https://map.baidu.com"),
        Site(listOf("百度百科"), "百度百科", "https://baike.baidu.com"),
        Site(listOf("百度网盘"), "百度网盘", "https://pan.baidu.com"),
        Site(listOf("百度翻译"), "百度翻译", "https://fanyi.baidu.com"),
        Site(listOf("文心一言"), "文心一言", "https://yiyan.baidu.com"),
        Site(listOf("腾讯"), "腾讯", "https://www.tencent.com"),
        Site(listOf("微信"), "微信", "https://weixin.qq.com"),
        Site(listOf("qq", "腾讯qq"), "QQ", "https://im.qq.com"),
        Site(listOf("qq音乐"), "QQ音乐", "https://y.qq.com"),
        Site(listOf("腾讯视频"), "腾讯视频", "https://v.qq.com"),
        Site(listOf("淘宝"), "淘宝", "https://www.taobao.com"),
        Site(listOf("天猫"), "天猫", "https://www.tmall.com"),
        Site(listOf("京东"), "京东", "https://www.jd.com"),
        Site(listOf("拼多多"), "拼多多", "https://www.pinduoduo.com"),
        Site(listOf("支付宝"), "支付宝", "https://www.alipay.com"),
        Site(listOf("阿里巴巴"), "阿里巴巴集团", "https://www.alibabagroup.com"),
        Site(listOf("抖音"), "抖音", "https://www.douyin.com"),
        Site(listOf("哔哩哔哩", "b站"), "哔哩哔哩", "https://www.bilibili.com"),
        Site(listOf("微博"), "微博", "https://weibo.com"),
        Site(listOf("知乎"), "知乎", "https://www.zhihu.com"),
        Site(listOf("小红书"), "小红书", "https://www.xiaohongshu.com"),
        Site(listOf("豆瓣"), "豆瓣", "https://www.douban.com"),
        Site(listOf("网易"), "网易", "https://www.163.com"),
        Site(listOf("网易云音乐", "网易云"), "网易云音乐", "https://music.163.com"),
        Site(listOf("酷狗"), "酷狗音乐", "https://www.kugou.com"),
        Site(listOf("酷我"), "酷我音乐", "https://www.kuwo.cn"),
        Site(listOf("新浪"), "新浪", "https://www.sina.com.cn"),
        Site(listOf("搜狐"), "搜狐", "https://www.sohu.com"),
        Site(listOf("人民网"), "人民网", "https://www.people.com.cn"),
        Site(listOf("新华网"), "新华网", "https://www.news.cn"),
        Site(listOf("央视网"), "央视网", "https://www.cctv.com"),
        Site(listOf("中国政府网", "政府网"), "中国政府网", "https://www.gov.cn"),
        Site(listOf("12306", "铁路12306"), "中国铁路12306", "https://www.12306.cn"),
        Site(listOf("高德地图", "高德"), "高德地图", "https://www.amap.com"),
        Site(listOf("美团"), "美团", "https://www.meituan.com"),
        Site(listOf("饿了么"), "饿了么", "https://www.ele.me"),
        Site(listOf("携程"), "携程", "https://www.ctrip.com"),
        Site(listOf("去哪儿"), "去哪儿", "https://www.qunar.com"),
        Site(listOf("小米"), "小米", "https://www.mi.com"),
        Site(listOf("华为"), "华为", "https://www.huawei.com"),
        Site(listOf("oppo"), "OPPO", "https://www.oppo.com"),
        Site(listOf("vivo"), "vivo", "https://www.vivo.com"),
        Site(listOf("苹果中国", "苹果官网", "apple"), "苹果中国", "https://www.apple.com.cn"),
        Site(listOf("微软"), "微软", "https://www.microsoft.com/zh-cn"),
        Site(listOf("github"), "GitHub", "https://github.com"),
        Site(listOf("gitee", "码云"), "Gitee", "https://gitee.com"),
        Site(listOf("csdn"), "CSDN", "https://www.csdn.net"),
        Site(listOf("菜鸟教程"), "菜鸟教程", "https://www.runoob.com"),
        Site(listOf("掘金"), "掘金", "https://juejin.cn"),
        Site(listOf("豆包"), "豆包", "https://www.doubao.com"),
        Site(listOf("通义千问", "通义"), "通义千问", "https://tongyi.aliyun.com"),
        Site(listOf("kimi"), "Kimi", "https://www.kimi.com"),
        Site(listOf("有道"), "有道", "https://www.youdao.com"),
        Site(listOf("中国知网", "知网"), "中国知网", "https://www.cnki.net"),
        Site(listOf("学习强国"), "学习强国", "https://www.xuexi.cn"),
        Site(listOf("智慧教育平台", "国家中小学智慧教育平台"), "国家中小学智慧教育平台", "https://www.zxx.edu.cn"),
        Site(listOf("中国大学mooc", "大学mooc"), "中国大学MOOC", "https://www.icourse163.org"),
        Site(listOf("爱奇艺"), "爱奇艺", "https://www.iqiyi.com"),
        Site(listOf("优酷"), "优酷", "https://www.youku.com"),
        Site(listOf("米哈游"), "米哈游", "https://www.mihoyo.com"),
        Site(listOf("原神"), "原神", "https://ys.mihoyo.com"),
        Site(listOf("米游社"), "米游社", "https://www.miyoushe.com"),
        Site(listOf("三角洲行动", "三角洲"), "三角洲行动", "https://df.qq.com"),
        Site(listOf("王者荣耀"), "王者荣耀", "https://pvp.qq.com"),
        Site(listOf("和平精英"), "和平精英", "https://gp.qq.com"),
        Site(listOf("英雄联盟"), "英雄联盟", "https://lol.qq.com"),
        Site(listOf("穿越火线"), "穿越火线", "https://cf.qq.com"),
        Site(listOf("地下城与勇士", "dnf"), "地下城与勇士", "https://dnf.qq.com"),
        Site(listOf("崩坏：星穹铁道", "崩坏星穹铁道", "星穹铁道"), "崩坏：星穹铁道", "https://sr.mihoyo.com"),
        Site(listOf("绝区零"), "绝区零", "https://zzz.mihoyo.com"),
        Site(listOf("崩坏3", "崩坏三"), "崩坏3", "https://bh3.mihoyo.com"),
        Site(listOf("明日方舟"), "明日方舟", "https://ak.hypergryph.com"),
        Site(listOf("鸣潮"), "鸣潮", "https://mc.kurogames.com"),
        Site(listOf("我的世界"), "我的世界（网易）", "https://mc.163.com"),
        Site(listOf("谷歌", "google"), "谷歌", "https://www.google.com"),
        Site(listOf("必应", "bing"), "必应", "https://cn.bing.com"),
        Site(listOf("维基百科"), "维基百科（中文）", "https://zh.wikipedia.org")
    )

    private val urlIntent = Regex("官网|官方网站|官方|网址|网站|入口|地址|链接|首页|主页")

    fun isUrlQuestion(text: String): Boolean = urlIntent.containsMatchIn(text)

    private val fillerPhrases = Regex(
        "那你能告诉我|你能告诉我|能告诉我|告诉我|你能不能|能不能|可不可以|你能|你可以|能否|帮我|请问|麻烦你|麻烦|给我|" +
            "查一下|找一下|查查|搜一下|这款|这个|那个|一款|这家|游戏|软件|应用|平台|官方网站|官网|官方|网址|网站|入口|" +
            "地址|链接|首页|主页|是什么|是多少|是啥|在哪里|在哪|哪里|有没有|[，,。？?！!、\\s]"
    )
    private val complaint = Regex("不是|怎么|为什么|别|不要|还是|没有|搜")

    /** 从“那你能告诉我三角洲行动这款游戏的官网网址吗”里取出“三角洲行动” */
    fun subjectOf(text: String): String {
        var s = fillerPhrases.replace(text, "")
        s = s.replace(Regex("^(那|请)+"), "").replace(Regex("(的|吗|呢|啊|吧|呀)+$"), "").trim()
        return s
    }

    private fun validSubject(s: String): Boolean = s.length in 2..12 && !complaint.containsMatchIn(s)

    /** 搜索结果里明显不是官网的站点（百科、问答、新闻、论坛、视频站等） */
    private val notOfficial = listOf(
        "baike", "zhidao", "zhihu", "tieba", "bilibili", "douyin", "xiaohongshu", "weibo", "sohu", "sina", "toutiao",
        "csdn", "jianshu", "3dmgame", "gamersky", "ali213", "17173", "taptap", "4399", "7k7k", "duowan", "docin",
        "doc88", "wenku", "baijiahao", "mbd.baidu", "new.qq.com", "inews.qq.com", "xw.qq.com", "wikipedia", "youku",
        "iqiyi", "kuaishou", "sogou", "bing.com", "map.baidu", "jingyan", "pan.baidu"
    )

    private fun pickOfficial(hits: List<WebSearch.Hit>): List<WebSearch.Hit> {
        val scored = ArrayList<Pair<Int, WebSearch.Hit>>()
        for (h in hits) {
            if (h.url.isEmpty()) continue
            val uri = try {
                android.net.Uri.parse(h.url)
            } catch (e: Exception) {
                continue
            }
            val host = (uri.host ?: "").lowercase(Locale.ROOT)
            if (host.isEmpty() || notOfficial.any { h.url.lowercase(Locale.ROOT).contains(it) }) continue
            var score = 0
            if (Regex("官方|官网").containsMatchIn(h.title)) score += 3
            if (host.count { it == '.' } <= 2) score += 1
            val path = uri.path ?: ""
            if (path.isEmpty() || path == "/") score += 1
            scored.add(Pair(score, h))
        }
        return scored.sortedByDescending { it.first }.filter { it.first >= 2 }.map { it.second }.take(2)
    }

    /**
     * 问某个网站/游戏的官网网址：内置库没有时，联网搜“xxx 官网”，直接把搜索结果里真实的链接给用户，
     * 不经过模型（模型会瞎编网址或者说“无法提供”）。需要在后台线程调用。
     */
    fun searchUrl(p: SharedPreferences, text: String, prevUserTexts: List<String>): String {
        var subject = subjectOf(text)
        if (!validSubject(subject)) {
            subject = ""
            for (t in prevUserTexts.asReversed()) {
                val s = subjectOf(t)
                if (urlIntent.containsMatchIn(t) && validSubject(s)) {
                    subject = s
                    break
                }
            }
        }
        if (subject.isEmpty()) return "没听清要查哪个网站的网址。请告诉我名称，比如“三角洲行动的官网网址”。"
        answer(subject + "官网")?.let { return it }

        var hits: List<WebSearch.Hit> = WebSearch.search(p, subject + " 官网")
        var picks = pickOfficial(hits)
        if (picks.isEmpty()) {
            hits = WebSearch.search(p, subject + " 官方网站")
            picks = pickOfficial(hits)
        }
        if (picks.isEmpty()) {
            return "没有从搜索结果里找到可靠的「" + subject + "」官方网址。建议在浏览器里搜索“" + subject + " 官网”，认准带“官方”标识的结果；我不想随便编一个网址给你。"
        }
        val sb = StringBuilder("「" + subject + "」的官方网址（来自联网搜索结果）：\n")
        for (h in picks) sb.append("\n").append(h.title).append("\n").append(h.url).append("\n")
        sb.append("\n（请核对域名确实是官方的，搜索结果可能有误。）")
        return sb.toString()
    }

    /** 是“问某个网站的官网/网址”就直接给出准确答案；不是就返回 null */
    fun answer(text: String): String? {
        if (!urlIntent.containsMatchIn(text)) return null
        val low = text.lowercase(Locale.ROOT)
        val matched = ArrayList<Pair<Site, String>>() // 站点 + 命中的别名
        for (s in sites) {
            for (a in s.names) {
                if (low.contains(a)) {
                    matched.add(Pair(s, a))
                    break
                }
            }
        }
        // “百度地图”里也含“百度”：如果有更长的别名把短别名包含了，就丢掉短的那个
        val res = matched.filter { m -> matched.none { o -> o.first !== m.first && o.second.length > m.second.length && o.second.contains(m.second) } }
        if (res.isEmpty()) return null
        val sb = StringBuilder()
        for (r in res.take(3)) sb.append(r.first.label).append("官方网址：").append(r.first.url).append("\n")
        sb.append("\n（来源：内置官方网址库。网址可能随时间变化，访问前请自行核对是否为官方域名。）")
        return sb.toString()
    }
}

/** 工作模式的系统提示词：不扮演角色，严谨、简洁、准确，只依据资料回答。 */
object WorkPersona {

    fun systemPrompt(
        p: SharedPreferences,
        hits: List<WebSearch.Hit>?,
        searchFailed: Boolean,
        extra: String?,
        memories: List<String>,
        compact: Boolean = false
    ): String {
        if (compact) {
            // 小模型（1.5B）用的精简版：规则越多越容易跑题
            val sb = StringBuilder()
            sb.append("你是严谨的中文助手，只使用简体中文。必须紧扣用户的问题，直接回答，先给结论再给要点，300 字以内，不要闲聊，不要编造网址和数据。\n")
            if (memories.isNotEmpty()) sb.append("用户让你记住的事：").append(memories.take(5).joinToString("；")).append("\n")
            if (hits != null && hits.isNotEmpty()) {
                sb.append("下面是联网资料，请只依据它回答，资料里没有的就说“没有查到”：\n")
                sb.append(WebSearch.renderForPrompt(hits, false, 1800))
            } else if (hits != null || searchFailed) {
                sb.append("没有查到联网资料，只回答你确定的常识，并说明未联网核实。\n")
            }
            if (!extra.isNullOrBlank()) sb.append("刚刚发生的事（真实结果）：").append(extra).append("\n")
            return sb.toString()
        }
        val c = Calendar.getInstance()
        val time = String.format(
            Locale.US, "%d年%d月%d日 %02d:%02d",
            c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)
        )
        val sb = StringBuilder()
        sb.append("你现在处于「工作模式」，是一个严谨、专业的中文 AI 助手，不扮演任何角色，不撒娇、不闲聊。面向中国大陆用户，只使用简体中文。\n")
        sb.append("规则：\n")
        sb.append("1. 直接回答问题，先给结论，再补充要点；紧扣用户的问题和上文，顺着用户的需求办，不转移话题、不反问无关的事。\n")
        sb.append("2. 信息必须准确：只依据下面的“联网资料”和你确定的常识回答。不确定、资料里没有的，就明确说“我不确定”或“没有查到”，绝对不要编造网址、数据、人名、版本号、步骤、政策条文。\n")
        sb.append("3. 网址只能使用资料里出现的，不要自己拼、不要凭记忆写网址。\n")
        sb.append("4. 教程类问题用编号步骤，每步一句话，写清楚操作和注意点；资料类问题先结论后依据。\n")
        sb.append("5. 一般不超过 300 个字，用户要求详细时可以更长。不要使用 Markdown 的标题和加粗符号，可以用“1. 2. 3.”编号。\n")
        sb.append("6. 不要在回答里写“参考来源”，系统会自动附上。\n")
        sb.append("7. 你只记得下面“工作记忆”里列出的内容，没有的就说不记得。\n")
        sb.append("\n当前时间：").append(time).append("\n")

        if (memories.isNotEmpty()) {
            sb.append("\n【工作记忆】用户让你记住的工作相关信息（“用户”指正在和你对话的人，“助手”指你），回答时要用上：\n")
            for (m in memories) sb.append("- ").append(m).append("\n")
        }

        if (hits != null) {
            if (hits.isEmpty()) {
                sb.append("\n联网搜索没有找到相关资料。请只回答你确定的常识，并说明这是常识性回答、未联网核实；不确定就说不确定。\n")
            } else {
                sb.append("\n【联网资料】（回答时以这些为依据，用自己的话整理，不要照抄大段原文）：\n")
                sb.append(WebSearch.renderForPrompt(hits, true, 3000))
                sb.append("资料按相关度排序，前面的更可信；多条资料说法不一致时，以官方或更详细的为准，并如实说明有出入。\n")
            }
        } else if (searchFailed) {
            sb.append("\n联网搜索失败了。请只回答你确定的常识，并说明未联网核实；不确定就说不确定。\n")
        } else {
            sb.append("\n这次没有联网资料。请只回答你确定的常识，并说明未联网核实；不确定就说不确定。\n")
        }
        if (!extra.isNullOrBlank()) {
            sb.append("\n刚刚发生的事（真实结果，请据此简短告知用户，不要编造细节）：").append(extra).append("\n")
        }
        return sb.toString()
    }

    /** 回答后面程序自动附上的“参考来源”（用的是搜索结果里真实的链接，不是模型写的） */
    fun sourcesBlock(hits: List<WebSearch.Hit>?): String {
        if (hits == null || hits.isEmpty()) return ""
        val sb = StringBuilder("\n\n参考来源：")
        var i = 1
        // 优先列真的读到了正文的网页；一个都没读到就列排名最前的几条
        val shown = hits.filter { it.body.isNotEmpty() }.ifEmpty { hits }.take(4)
        for (h in shown) {
            sb.append("\n").append(i).append(". ").append(h.title)
            if (h.url.isNotEmpty()) sb.append("\n   ").append(h.url)
            i++
        }
        return sb.toString()
    }

    const val NO_SOURCE_NOTE = "\n\n（未联网核实：以上来自模型自身的知识，仅供参考，重要信息请自行核对。）"
}

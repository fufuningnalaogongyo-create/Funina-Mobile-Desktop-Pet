package com.example.furinapet

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * 配置备份：把好感度、饱食度、全部设置、自定义台词、自定义形象、（可选）语音文件
 * 打成一个 zip，换设备后导入即可还原。
 *
 * zip 内容：
 *   config.json            所有 SharedPreferences（带类型）+ 元信息
 *   custom_pet.png         自定义形象（如果有）
 *   voice/<场景>/任意.snd      每个场景自己导入的语音
 *   vpack_<方案>/         语音包方案（默认方案只备份 index.json，音频本来就内置）
 */
object Backup {

    class BackupException(msg: String) : Exception(msg)

    class Info(
        val exportedAt: Long,
        val appVersion: String,
        val name: String,
        val aff: Int,
        val full: Float,
        val hasVoice: Boolean,
        val hasImage: Boolean,
        val memoryCount: Int = 0
    )

    const val MAGIC = "FurinaPetBackup"
    const val FORMAT = 1

    private const val CONFIG = "config.json"
    private const val IMAGE = "custom_pet.png"
    private const val MEMORY = "ai_memory.json"
    private const val UI_BG = "ui_bg.jpg"
    private const val TMP_DIR = "import_tmp"
    private const val MAX_CONFIG = 4L * 1024L * 1024L
    private const val MAX_ENTRY = 16L * 1024L * 1024L
    private const val MAX_TOTAL = 500L * 1024L * 1024L
    private const val MAX_FILES = 5000

    /** 只属于本机的状态，不导出也不覆盖：运行状态、悬浮位置、形象版本号、饱食度计时、默认语音包安装标记 */
    private val LOCAL_KEYS = setOf(
        Prefs.RUNNING, Prefs.POS_X, Prefs.POS_Y, Prefs.DOCK_SIDE,
        Prefs.IMG_VERSION, Prefs.FULL_TS, Prefs.UI_BG_VER, VoicePack.DEFAULT_FLAG, Prefs.AI_BOCHA_KEY,
        Prefs.AI_MODEL_ACTIVE
    )

    /** 语音包方案的索引键：和 vpack_* 文件夹绑在一起，没带语音文件时不能单独导入 */
    private val VOICE_KEYS = setOf(VoicePack.K_ACTIVE, VoicePack.K_LIST, VoicePack.K_SEQ)

    private val RE_VOICE = Regex("^voice/[A-Za-z0-9_]{1,40}/[A-Za-z0-9_][A-Za-z0-9_.-]{0,79}$")
    private val RE_VPACK = Regex("^vpack_[A-Za-z0-9_]{1,40}/[A-Za-z0-9_][A-Za-z0-9_.-]{0,79}$")

    // ------------------------------------------------------------------ 导出

    /** 语音文件大概多大（字节），用来在导出前提示用户 */
    fun voiceBytes(ctx: Context): Long {
        var n = 0L
        for (f in voiceFiles(ctx)) n += f.second.length()
        return n
    }

    private fun voiceFiles(ctx: Context): List<Pair<String, File>> {
        val out = ArrayList<Pair<String, File>>()
        val root = ctx.filesDir
        val voice = File(root, "voice")
        for (d in voice.listFiles() ?: emptyArray()) {
            if (!d.isDirectory) continue
            for (f in d.listFiles() ?: emptyArray()) {
                if (f.isFile) out.add(Pair("voice/" + d.name + "/" + f.name, f))
            }
        }
        for (d in root.listFiles() ?: emptyArray()) {
            if (!d.isDirectory || !d.name.startsWith("vpack_")) continue
            if (d.name == "vpack_" + VoicePack.DEFAULT_ID) {
                // 内置默认包的音频来自 assets，只带上用户改过的索引
                val idx = File(d, "index.json")
                if (idx.isFile) out.add(Pair(d.name + "/index.json", idx))
                continue
            }
            for (f in d.listFiles() ?: emptyArray()) {
                if (f.isFile) out.add(Pair(d.name + "/" + f.name, f))
            }
        }
        return out
    }

    fun export(ctx: Context, out: OutputStream, withVoice: Boolean) {
        val p = Prefs.get(ctx)
        val img = PetService.customImageFile(ctx)
        val hasImage = img.isFile
        val mem = AiMemory.load(ctx)

        val all = HashMap<String, Any?>(p.all)
        // 饱食度是按时间衰减的：导出当下的实际值，导入时从导入那一刻重新计时
        all[Prefs.FULL] = Bond.fullness(p)

        val prefsJson = JSONObject()
        for ((k, v) in all) {
            if (k in LOCAL_KEYS) continue
            if (!withVoice && k in VOICE_KEYS) continue
            val o = encode(v) ?: continue
            prefsJson.put(k, o)
        }

        val cfg = JSONObject()
        cfg.put("magic", MAGIC)
        cfg.put("format", FORMAT)
        cfg.put("exportedAt", System.currentTimeMillis())
        cfg.put("appVersion", versionName(ctx))
        cfg.put("hasVoice", withVoice)
        cfg.put("hasImage", hasImage)
        cfg.put("memoryCount", mem.size)
        cfg.put("prefs", prefsJson)

        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            z.putNextEntry(ZipEntry(CONFIG))
            z.write(cfg.toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()

            if (hasImage) addFile(z, IMAGE, img)
            if (Ui.hasBackground(ctx)) addFile(z, UI_BG, Ui.bgFile(ctx))
            if (mem.isNotEmpty()) {
                z.putNextEntry(ZipEntry(MEMORY))
                z.write(AiMemory.toJson(mem).toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            if (withVoice) {
                for (pr in voiceFiles(ctx)) addFile(z, pr.first, pr.second)
            }
        }
    }

    private fun addFile(z: ZipOutputStream, name: String, f: File) {
        z.putNextEntry(ZipEntry(name))
        f.inputStream().use { it.copyTo(z) }
        z.closeEntry()
    }

    private fun encode(v: Any?): JSONObject? {
        val o = JSONObject()
        when (v) {
            is Boolean -> { o.put("t", "b"); o.put("v", v) }
            is Int -> { o.put("t", "i"); o.put("v", v) }
            is Long -> { o.put("t", "l"); o.put("v", v) }
            is Float -> {
                if (v.isNaN() || v.isInfinite()) return null
                o.put("t", "f"); o.put("v", v.toDouble())
            }
            is String -> { o.put("t", "s"); o.put("v", v) }
            is Set<*> -> {
                val arr = JSONArray()
                for (s in v) if (s is String) arr.put(s)
                o.put("t", "ss"); o.put("v", arr)
            }
            else -> return null
        }
        return o
    }

    private fun versionName(ctx: Context): String {
        return try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    // ------------------------------------------------------------------ 导入

    /** 只读备份里的 config.json，用来在导入前给用户确认 */
    fun readInfo(input: InputStream): Info {
        ZipInputStream(BufferedInputStream(input)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.name == CONFIG) {
                    val bytes = ByteArrayLimited.read(z, MAX_CONFIG)
                    return toInfo(parseConfig(bytes))
                }
            }
        }
        throw BackupException("这不是桌宠的备份文件")
    }

    private fun parseConfig(bytes: ByteArray): JSONObject {
        val cfg = try {
            JSONObject(String(bytes, Charsets.UTF_8))
        } catch (e: Exception) {
            throw BackupException("这不是桌宠的备份文件")
        }
        if (cfg.optString("magic") != MAGIC) throw BackupException("这不是桌宠的备份文件")
        if (cfg.optInt("format", 0) > FORMAT) throw BackupException("这个备份来自更新版本的桌宠，请先把本应用更新到最新版")
        if (cfg.optJSONObject("prefs") == null) throw BackupException("备份文件已损坏")
        return cfg
    }

    private fun toInfo(cfg: JSONObject): Info {
        val po = cfg.getJSONObject("prefs")
        val name = po.optJSONObject(Prefs.NAME)?.optString("v", "") ?: ""
        val aff = po.optJSONObject(Prefs.AFF)?.optInt("v", 0) ?: 0
        val full = (po.optJSONObject(Prefs.FULL)?.optDouble("v", 60.0) ?: 60.0).toFloat()
        return Info(
            cfg.optLong("exportedAt", 0L),
            cfg.optString("appVersion", ""),
            name, aff, full,
            cfg.optBoolean("hasVoice", false),
            cfg.optBoolean("hasImage", false),
            cfg.optInt("memoryCount", 0)
        )
    }

    /**
     * 导入：先整体解压到临时目录并校验，通过之后才动本机数据，
     * 所以备份文件有问题时不会把现有数据弄坏。
     * 调用前请先让桌宠服务退场，并在后台线程调用。
     */
    fun import(ctx: Context, input: InputStream): Info {
        val tmp = File(ctx.filesDir, TMP_DIR)
        tmp.deleteRecursively()
        tmp.mkdirs()
        try {
            var cfgBytes: ByteArray? = null
            var total = 0L
            var count = 0
            ZipInputStream(BufferedInputStream(input)).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    val name = e.name
                    val ok = name == CONFIG || name == IMAGE || name == MEMORY || name == UI_BG || RE_VOICE.matches(name) || RE_VPACK.matches(name)
                    if (!ok) continue // 不认识的条目一律忽略，也避免路径穿越
                    count++
                    if (count > MAX_FILES) throw BackupException("备份文件内容异常（文件数量过多）")
                    val dest = File(tmp, name)
                    dest.parentFile?.mkdirs()
                    val limit = if (name == CONFIG) MAX_CONFIG else MAX_ENTRY
                    var n = 0L
                    dest.outputStream().use { o ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val r = z.read(buf)
                            if (r < 0) break
                            n += r
                            if (n > limit) throw BackupException("备份文件内容异常（单个文件过大）")
                            o.write(buf, 0, r)
                        }
                    }
                    total += n
                    if (total > MAX_TOTAL) throw BackupException("备份文件内容异常（体积过大）")
                    if (name == CONFIG) cfgBytes = dest.readBytes()
                }
            }
            val raw = cfgBytes ?: throw BackupException("这不是桌宠的备份文件")
            val cfg = parseConfig(raw)
            val hasVoice = cfg.optBoolean("hasVoice", false)
            applyBackup(ctx, tmp, cfg, hasVoice)
            return toInfo(cfg)
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun applyBackup(ctx: Context, tmp: File, cfg: JSONObject, hasVoice: Boolean) {
        val p = Prefs.get(ctx)
        val root = ctx.filesDir

        // 先确保本机装好内置默认语音包，后面只替换它的索引
        if (hasVoice) VoicePack.schemeCount(ctx, VoicePack.DEFAULT_ID)

        // 1) 文件
        val img = File(tmp, IMAGE)
        val hasImage = img.isFile
        if (hasImage) img.copyTo(PetService.customImageFile(ctx), true)
        val bgSrc = File(tmp, UI_BG)
        val hasBg = bgSrc.isFile
        if (hasBg) bgSrc.copyTo(Ui.bgFile(ctx), true)

        if (hasVoice) {
            File(root, "voice").deleteRecursively()
            val v = File(tmp, "voice")
            if (v.isDirectory) moveDir(v, File(root, "voice"))

            for (d in root.listFiles() ?: emptyArray()) {
                if (d.isDirectory && d.name.startsWith("vpack_") && d.name != "vpack_" + VoicePack.DEFAULT_ID) {
                    d.deleteRecursively()
                }
            }
            for (d in tmp.listFiles() ?: emptyArray()) {
                if (!d.isDirectory || !d.name.startsWith("vpack_")) continue
                if (d.name == "vpack_" + VoicePack.DEFAULT_ID) {
                    val idx = File(d, "index.json")
                    val target = File(root, d.name)
                    if (idx.isFile && target.isDirectory) idx.copyTo(File(target, "index.json"), true)
                } else {
                    moveDir(d, File(root, d.name))
                }
            }
        }

        // AI 记忆：与本机已有的合并（不删本机的），重复的跳过
        val memFile = File(tmp, MEMORY)
        if (memFile.isFile) {
            try {
                AiMemory.mergeFrom(ctx, AiMemory.parse(memFile.readText()))
            } catch (e: Exception) {
            }
        }

        // 2) 设置：清掉旧的，写入备份里的；本机状态原样保留
        val skip = HashSet<String>(LOCAL_KEYS)
        if (!hasVoice) skip.addAll(VOICE_KEYS)
        val keep = HashMap<String, Any?>()
        for ((k, v) in p.all) {
            if (k in skip) keep[k] = v
        }

        val ed = p.edit()
        ed.clear() // clear 总是最先执行，下面的 put 不受影响
        val po = cfg.getJSONObject("prefs")
        val keys = po.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in skip) continue
            val o = po.optJSONObject(k) ?: continue
            decode(ed, k, o)
        }
        for ((k, v) in keep) putAny(ed, k, v)

        val now = System.currentTimeMillis()
        ed.putLong(Prefs.FULL_TS, now) // 饱食度从导入这一刻开始重新衰减
        if (hasImage) ed.putLong(Prefs.IMG_VERSION, now)
        if (hasBg) ed.putLong(Prefs.UI_BG_VER, now)
        if (!ed.commit()) throw BackupException("写入设置失败")
    }

    private fun moveDir(src: File, dst: File) {
        dst.parentFile?.mkdirs()
        if (src.renameTo(dst)) return
        src.copyRecursively(dst, true)
        src.deleteRecursively()
    }

    private fun decode(ed: SharedPreferences.Editor, key: String, o: JSONObject) {
        try {
            when (o.optString("t")) {
                "b" -> ed.putBoolean(key, o.getBoolean("v"))
                "i" -> ed.putInt(key, o.getInt("v"))
                "l" -> ed.putLong(key, o.getLong("v"))
                "f" -> ed.putFloat(key, o.getDouble("v").toFloat())
                "s" -> ed.putString(key, o.getString("v"))
                "ss" -> {
                    val arr = o.getJSONArray("v")
                    val set = HashSet<String>()
                    for (i in 0 until arr.length()) set.add(arr.getString(i))
                    ed.putStringSet(key, set)
                }
            }
        } catch (e: Exception) {
            // 单个键坏了就跳过，不影响其他设置
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun putAny(ed: SharedPreferences.Editor, key: String, v: Any?) {
        when (v) {
            is Boolean -> ed.putBoolean(key, v)
            is Int -> ed.putInt(key, v)
            is Long -> ed.putLong(key, v)
            is Float -> ed.putFloat(key, v)
            is String -> ed.putString(key, v)
            is Set<*> -> ed.putStringSet(key, v as Set<String>)
        }
    }

    private object ByteArrayLimited {
        fun read(z: InputStream, limit: Long): ByteArray {
            val bos = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var n = 0L
            while (true) {
                val r = z.read(buf)
                if (r < 0) break
                n += r
                if (n > limit) throw BackupException("备份文件内容异常")
                bos.write(buf, 0, r)
            }
            return bos.toByteArray()
        }
    }
}

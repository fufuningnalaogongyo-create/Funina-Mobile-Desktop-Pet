package com.example.furinapet

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.max

/** 圆角渐变进度条 */
class BarView(context: Context) : View(context) {

    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private var c1 = 0xFFFFB3C9.toInt()
    private var c2 = 0xFFFF6B9A.toInt()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        track.color = 0x33FFFFFF
    }

    fun setColors(a: Int, b: Int) {
        c1 = a
        c2 = b
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, track)
        val fw = w * progress
        if (fw > 0f) {
            val right = max(fw, h)
            fill.shader = LinearGradient(0f, 0f, right, 0f, c1, c2, Shader.TileMode.CLAMP)
            rect.set(0f, 0f, right, h)
            canvas.drawRoundRect(rect, h / 2f, h / 2f, fill)
        }
    }
}

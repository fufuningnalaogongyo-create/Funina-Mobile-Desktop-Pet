package com.example.furinapet

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** 语音包管理：导入、试听、改场景、改文字、删除、清理未归类。 */
class VoicePackActivity : Activity() {

    private val reqFiles = 51
    private val reqZip = 52
    private val pageSize = 30

    private lateinit var listBox: LinearLayout
    private lateinit var summary: TextView
    private lateinit var filterBtn: Button
    private lateinit var schemeLabel: TextView
    private var entries: MutableList<VoicePack.Entry> = ArrayList()
    private var filter: String? = null
    private var shown = pageSize
    private var player: MediaPlayer? = null

    private val cGold = 0xFFE5C26B.toInt()
    private val cText = 0xFFEAF1FF.toInt()
    private val cSub = 0xFF9FB0DC.toInt()
    private val cCard = 0xFF121D4A.toInt()
    private val cNavy = 0xFF0B1230.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
        return d
    }

    private fun btn(text: String, filled: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.transformationMethod = null
        b.stateListAnimator = null
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        b.typeface = Typeface.DEFAULT_BOLD
        b.setPadding(dp(8), 0, dp(8), 0)
        if (filled) {
            b.setTextColor(cNavy)
            b.background = rounded(cGold, 20, 0, 0)
        } else {
            b.setTextColor(cGold)
            b.background = rounded(0, 20, 0x99E5C26B.toInt(), 1)
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun add(parent: LinearLayout, b: Button, topDp: Int) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
        lp.topMargin = dp(topDp)
        parent.addView(b, lp)
    }

    // 记下最近点击的位置，弹窗会从这里弹出来
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Ui.noteTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    // 关闭时的页面动画
    override fun finish() {
        super.finish()
        Ui.closeTransition(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0B1230.toInt(), 0xFF14245C.toInt())
        )
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(22), dp(16), dp(40))
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        val title = TextView(this)
        title.text = "语音包"
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        title.setTextColor(cGold)
        title.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        root.addView(title)

        val note = TextView(this)
        note.text = "每条语音由「音频 + 一句文字 + 所属场景」组成。触发对应场景时，她会显示这句文字并播放这段音频。\n" +
            "语音包分「方案」：内置的「默认语音包」，以及可以自己导入的「自定义方案1、2……」，一次只启用一个，互不影响。\n" +
            "请只导入你自己录制或有权使用的音频。导入时会按文件名里的关键词（如「早上好」「晚安」「闲聊」）自动猜场景；有中文名但猜不到的放进「日常闲聊」，没有中文名的放进「未归类」（不会被使用，可一键清理）。"
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        note.setTextColor(cSub)
        note.setLineSpacing(0f, 1.15f)
        note.setPadding(0, dp(6), 0, dp(6))
        root.addView(note)

        schemeLabel = TextView(this)
        schemeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        schemeLabel.setTextColor(cGold)
        schemeLabel.typeface = Typeface.DEFAULT_BOLD
        schemeLabel.setPadding(0, dp(8), 0, dp(2))
        root.addView(schemeLabel)

        add(root, btn("切换方案", true) { pickScheme() }, 8)
        add(root, btn("新建自定义方案", false) { newScheme() }, 8)
        val schemeRow = LinearLayout(this)
        schemeRow.orientation = LinearLayout.HORIZONTAL
        val lpL = LinearLayout.LayoutParams(0, dp(44), 1f)
        val lpR = LinearLayout.LayoutParams(0, dp(44), 1f)
        lpR.leftMargin = dp(8)
        schemeRow.addView(btn("重命名当前方案", false) { renameScheme() }, lpL)
        schemeRow.addView(btn("删除当前方案", false) { deleteScheme() }, lpR)
        val lpRow = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpRow.topMargin = dp(8)
        root.addView(schemeRow, lpRow)
        add(root, btn("恢复默认语音包", true) { restoreDefault() }, 8)

        summary = TextView(this)
        summary.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        summary.setTextColor(cText)
        summary.setPadding(0, dp(14), 0, dp(4))
        root.addView(summary)

        add(root, btn("导入音频文件（可多选）", true) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(i, reqFiles)
        }, 10)
        add(root, btn("导入压缩包（zip，自动挑出里面的音频）", false) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, reqZip)
        }, 8)
        add(root, btn("清理所有「未归类」的语音", false) {
            GlassDialog(this)
                .setTitle("清理未归类？")
                .setMessage("场景为「未归类」的语音会被永久删除。")
                .setPositiveButton("清理") { _, _ ->
                    val n = VoicePack.removeUncategorized(this, entries)
                    Toast.makeText(this, "已清理 " + n + " 条", Toast.LENGTH_SHORT).show()
                    refresh()
                }
                .setNegativeButton("取消", null)
                .show()
        }, 8)
        add(root, btn("给所有文字自动补标点（简易）", false) {
            val n = VoicePack.punctuateAll(this, entries)
            Toast.makeText(this, "已处理 " + n + " 条，建议自己再润色", Toast.LENGTH_LONG).show()
            refresh()
        }, 8)
        add(root, btn("把语音包文字同步到普通台词", false) {
            val n = VoicePack.syncToLines(this, entries)
            Toast.makeText(this, "已向普通台词新增 " + n + " 句", Toast.LENGTH_LONG).show()
        }, 8)
        filterBtn = btn("筛选：全部", false) { pickFilter() }
        add(root, filterBtn, 8)

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        root.addView(listBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        add(root, btn("清空当前方案", false) {
            GlassDialog(this)
                .setTitle("清空当前方案？")
                .setMessage("当前方案里的所有语音都会被永久删除（默认语音包可用「恢复默认语音包」找回）。")
                .setPositiveButton("清空") { _, _ ->
                    VoicePack.clearAll(this)
                    entries = ArrayList()
                    refresh()
                }
                .setNegativeButton("取消", null)
                .show()
        }, 20)
        add(root, btn("返回", true) { finish() }, 8)

        entries = VoicePack.load(this)
        refresh()
    }

    private fun reload() {
        stopPlayer()
        entries = VoicePack.load(this)
        shown = pageSize
        refresh()
    }

    private fun pickScheme() {
        val list = VoicePack.schemes(this)
        val cur = VoicePack.activeId(this)
        val names = Array(list.size) { i ->
            val sc = list[i]
            (if (sc.id == cur) "✓ " else "") + sc.name + "（" + VoicePack.schemeCount(this, sc.id) + " 条）"
        }
        GlassDialog(this)
            .setTitle("切换方案")
            .setItems(names) { _, which ->
                VoicePack.setActive(this, list[which].id)
                reload()
                Toast.makeText(this, "已切换到：" + list[which].name, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun newScheme() {
        val sc = VoicePack.addScheme(this)
        if (sc == null) {
            Toast.makeText(this, "自定义方案最多 " + VoicePack.MAX_CUSTOM + " 个", Toast.LENGTH_SHORT).show()
            return
        }
        VoicePack.setActive(this, sc.id)
        reload()
        Toast.makeText(this, "已新建并切换到「" + sc.name + "」，现在可以导入语音了", Toast.LENGTH_LONG).show()
    }

    private fun renameScheme() {
        val id = VoicePack.activeId(this)
        if (id == VoicePack.DEFAULT_ID) {
            Toast.makeText(this, "默认语音包不能改名", Toast.LENGTH_SHORT).show()
            return
        }
        val et = EditText(this)
        et.setText(VoicePack.nameOf(this, id))
        et.setSelectAllOnFocus(true)
        et.setSingleLine(true)
        GlassDialog(this)
            .setTitle("重命名方案")
            .setView(et)
            .setPositiveButton("确定") { _, _ ->
                if (VoicePack.renameScheme(this, id, et.text.toString())) {
                    refresh()
                } else {
                    Toast.makeText(this, "名字不能为空", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun deleteScheme() {
        val id = VoicePack.activeId(this)
        if (id == VoicePack.DEFAULT_ID) {
            Toast.makeText(this, "默认语音包不能删除，想还原请点「恢复默认语音包」", Toast.LENGTH_LONG).show()
            return
        }
        GlassDialog(this)
            .setTitle("删除「" + VoicePack.nameOf(this, id) + "」？")
            .setMessage("这个方案和里面的所有语音都会被永久删除，并切回默认语音包。")
            .setPositiveButton("删除") { _, _ ->
                stopPlayer()
                VoicePack.deleteScheme(this, id)
                reload()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun restoreDefault() {
        GlassDialog(this)
            .setTitle("恢复默认语音包？")
            .setMessage("「默认语音包」会还原成最初内置的那套语音（场景和文字也一并还原），你对它做过的修改、删除、新增都会丢失。\n自定义方案不受影响，也不会自动切换方案。")
            .setPositiveButton("恢复") { _, _ ->
                stopPlayer()
                val n = VoicePack.restoreDefault(this)
                if (n >= 0) {
                    Toast.makeText(this, "已恢复默认语音包（" + n + " 条）", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "恢复失败：安装包里没有找到内置语音", Toast.LENGTH_LONG).show()
                }
                reload()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroy() {
        stopPlayer()
        super.onDestroy()
    }

    private fun stopPlayer() {
        val p = player
        player = null
        if (p != null) {
            try {
                p.stop()
            } catch (e: Exception) {
            }
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun play(e: VoicePack.Entry) {
        stopPlayer()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(VoicePack.audioFile(this, e).absolutePath)
            mp.prepare()
            mp.setOnCompletionListener { m ->
                try {
                    m.release()
                } catch (ex: Exception) {
                }
                if (player === m) player = null
            }
            mp.start()
            player = mp
        } catch (ex: Exception) {
            Toast.makeText(this, "这段音频无法播放", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickFilter() {
        val keys = ArrayList<String>()
        val names = ArrayList<String>()
        keys.add("")
        names.add("全部")
        keys.add(VoicePack.NONE)
        names.add(VoicePack.catLabel(VoicePack.NONE))
        for (c in Lines.cats) {
            keys.add(c.key)
            names.add(c.label)
        }
        GlassDialog(this)
            .setTitle("按场景筛选")
            .setItems(names.toTypedArray()) { _, which ->
                filter = if (which == 0) null else keys[which]
                filterBtn.text = "筛选：" + names[which]
                shown = pageSize
                refresh()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun pickCat(e: VoicePack.Entry) {
        val keys = ArrayList<String>()
        val names = ArrayList<String>()
        keys.add(VoicePack.NONE)
        names.add(VoicePack.catLabel(VoicePack.NONE))
        for (c in Lines.cats) {
            keys.add(c.key)
            names.add(c.label)
        }
        GlassDialog(this)
            .setTitle("这段语音属于哪个场景？")
            .setItems(names.toTypedArray()) { _, which ->
                e.cat = keys[which]
                VoicePack.save(this, entries)
                refresh()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun refresh() {
        var usable = 0
        var none = 0
        for (e in entries) {
            if (e.cat == VoicePack.NONE) none++ else usable++
        }
        schemeLabel.text = "当前方案：" + VoicePack.nameOf(this, VoicePack.activeId(this))
        summary.text = "共 " + entries.size + " 条 · 可用 " + usable + " · 未归类 " + none

        listBox.removeAllViews()
        val f = filter
        val visible = ArrayList<VoicePack.Entry>()
        for (e in entries) {
            if (f == null || e.cat == f) visible.add(e)
        }
        val count = minOf(shown, visible.size)
        for (i in 0 until count) addRow(visible[i])
        if (visible.size > count) {
            val more = btn("显示更多（还有 " + (visible.size - count) + " 条）", false) {
                shown += pageSize
                refresh()
            }
            add(listBox, more, 10)
        }
    }

    private fun addRow(e: VoicePack.Entry) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.background = rounded(cCard, 16, 0x33E5C26B, 1)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val catBtn = btn(VoicePack.catLabel(e.cat), false) { pickCat(e) }
        top.addView(catBtn, LinearLayout.LayoutParams(0, dp(38), 1f))

        val playBtn = btn("试听", true) { play(e) }
        val lpP = LinearLayout.LayoutParams(dp(64), dp(38))
        lpP.leftMargin = dp(8)
        top.addView(playBtn, lpP)

        val delBtn = btn("删除", false) {
            stopPlayer()
            VoicePack.remove(this, entries, e)
            refresh()
        }
        val lpD = LinearLayout.LayoutParams(dp(64), dp(38))
        lpD.leftMargin = dp(8)
        top.addView(delBtn, lpD)
        card.addView(top)

        val et = EditText(this)
        et.hint = "这段语音说的话（显示在气泡里，可留空）"
        et.setText(e.text)
        et.setTextColor(cText)
        et.setHintTextColor(0xFF6E7DAA.toInt())
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        et.background = rounded(0xFF0C1540.toInt(), 10, 0x33E5C26B, 1)
        et.setPadding(dp(10), dp(8), dp(10), dp(8))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                e.text = s?.toString() ?: ""
                VoicePack.save(this@VoicePackActivity, entries)
            }
        })
        val lpE = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpE.topMargin = dp(8)
        card.addView(et, lpE)

        val lpC = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpC.topMargin = dp(10)
        listBox.addView(card, lpC)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == reqFiles) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
            } else {
                val u = data.data
                if (u != null) uris.add(u)
            }
            val n = VoicePack.importUris(this, uris)
            Toast.makeText(this, "已导入 " + n + " 段（单段不超过 6MB，总数最多 300）", Toast.LENGTH_LONG).show()
        } else if (requestCode == reqZip) {
            val u = data.data ?: return
            val n = VoicePack.importZip(this, u)
            Toast.makeText(this, "从压缩包导入了 " + n + " 段", Toast.LENGTH_LONG).show()
        } else {
            return
        }
        entries = VoicePack.load(this)
        shown = pageSize
        refresh()
    }
}

package com.example.furinapet

import android.app.Activity
import android.widget.Toast
import java.util.Locale

/** 模型管理弹窗：看有哪些模型、切换使用哪个、删除不用的、没装的可以一键下载。设置页和聊天页共用。 */
object ModelManager {

    private fun fmt(b: Long): String =
        if (b >= 1024L * 1024L * 1024L) String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        else String.format(Locale.US, "%.0f MB", b / 1048576.0)

    /** @param onChanged 切换 / 删除 / 下载完成之后调用（在主线程），用来刷新界面或重新加载模型 */
    fun show(act: Activity, onChanged: () -> Unit) {
        val active = Models.active(act)
        val rows = ArrayList<CharSequence>()
        for (s in Models.list) {
            val line = if (Models.installed(act, s)) {
                val size = fmt(Models.file(act, s).length())
                if (s.id == active.id) "● 使用中 · " + s.label + "（" + size + "）"
                else "○ 已安装 · " + s.label + "（" + size + "）"
            } else {
                if (s.downloadable) "＋ 未安装 · " + s.label + "（" + s.sizeText + "，点击下载）"
                else "＋ 未导入 · " + s.label + "（点击查看怎么导入）"
            }
            rows.add(line)
        }
        GlassDialog(act)
            .setTitle("管理 / 切换模型")
            .setItems(rows.toTypedArray()) { _, which -> onPick(act, Models.list[which], onChanged) }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun onPick(act: Activity, s: Models.Spec, onChanged: () -> Unit) {
        val installed = Models.installed(act, s)
        val isActive = Models.active(act).id == s.id && installed
        if (!installed) {
            if (s.downloadable) {
                ModelDownloader.show(act, s) { onChanged() }
            } else {
                GlassDialog(act)
                    .setTitle(s.label)
                    .setMessage(s.intro + "\n\n到设置页点「从本地导入模型文件（.litertlm）」，选好文件即可，导入后会自动切换到它。")
                    .setPositiveButton("知道了", null)
                    .show()
            }
            return
        }
        val items = ArrayList<CharSequence>()
        if (!isActive) items.add("切换到这个模型")
        items.add("删除这个模型")
        items.add("取消")
        GlassDialog(act)
            .setTitle(s.label)
            .setItems(items.toTypedArray()) { _, which ->
                val text = items[which].toString()
                when {
                    text.startsWith("切换") -> switchTo(act, s, onChanged)
                    text.startsWith("删除") -> confirmDelete(act, s, isActive, onChanged)
                }
            }
            .show()
    }

    private fun switchTo(act: Activity, s: Models.Spec, onChanged: () -> Unit) {
        Models.setActive(act, s.id)
        // 卸载旧模型要等它不忙，放后台；新模型由调用方（聊天页）重新加载
        Thread {
            LocalAi.release()
            act.runOnUiThread {
                Toast.makeText(act, "已切换到「" + s.shortName + "」", Toast.LENGTH_SHORT).show()
                onChanged()
            }
        }.start()
    }

    private fun confirmDelete(act: Activity, s: Models.Spec, isActive: Boolean, onChanged: () -> Unit) {
        val size = fmt(Models.file(act, s).length())
        val others = Models.installedList(act).filter { it.id != s.id }
        val tail = when {
            !isActive -> "不影响正在使用的模型。"
            others.isNotEmpty() -> "它正在使用，删除后会自动改用「" + others[0].shortName + "」。"
            else -> "它是唯一的模型，删除后需要重新下载或导入才能聊天。"
        }
        GlassDialog(act)
            .setTitle("删除模型")
            .setMessage("将删除「" + s.label + "」（释放约 " + size + " 存储空间），聊天记录和设置都会保留。\n" + tail)
            .setPositiveButton("删除") { _, _ ->
                Thread {
                    Models.delete(act, s)
                    act.runOnUiThread {
                        Toast.makeText(act, "已删除「" + s.shortName + "」", Toast.LENGTH_SHORT).show()
                        onChanged()
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }
}

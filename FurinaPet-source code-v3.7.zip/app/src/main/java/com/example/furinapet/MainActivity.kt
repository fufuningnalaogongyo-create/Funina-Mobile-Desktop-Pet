package com.example.furinapet

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var cur: LinearLayout

    private lateinit var lvText: TextView
    private lateinit var affText: TextView
    private lateinit var affBar: BarView
    private lateinit var fullText: TextView
    private lateinit var fullBar: BarView
    private lateinit var statusText: TextView
    private lateinit var permText: TextView
    private lateinit var toggleBtn: Button
    private lateinit var headerImg: ImageView

    private val handler = Handler(Looper.getMainLooper())
    private val reqImg = 41
    private val reqNotif = 42
    private val reqVoice = 43
    private val reqExport = 44
    private val reqImport = 45
    private val reqModel = 46
    private val reqBg = 47
    private lateinit var pageHost: PageHost
    private lateinit var homeScroll: ScrollView
    private lateinit var settingsScroll: ScrollView
    private lateinit var tabHome: TextView
    private lateinit var tabSettings: TextView
    private var currentTab = 0
    private lateinit var aiDownloadBtn: Button
    private lateinit var aiDsBtn: Button
    private lateinit var aiEngineBtn: Button
    private lateinit var aiStatusText: TextView
    private var pendingWithVoice = true
    private var voiceKeyPending = ""

    private val cGold = 0xFFE5C26B.toInt()
    private val cText = 0xFFEAF1FF.toInt()
    private val cSub = 0xFF9FB0DC.toInt()
    private val cCard = 0xFF121D4A.toInt()
    private val cStroke = 0x33E5C26B
    private val cNavy = 0xFF0B1230.toInt()
    private val cPink = 0xFFFF8FB1.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
        return d
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 3000L)
        }
    }

    // 记下最近点击的位置，弹窗会从这里弹出来
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Ui.noteTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        Bond.ensureInit(prefs)

        pageHost = PageHost(this)

        // 两个页面：主页 / 设置，下面是固定的底栏，点击切换
        val frame = FrameLayout(this)
        homeScroll = ScrollView(this)
        homeScroll.isVerticalScrollBarEnabled = false
        val homeRoot = LinearLayout(this)
        homeRoot.orientation = LinearLayout.VERTICAL
        homeRoot.setPadding(dp(16), dp(22), dp(16), dp(100)) // 底部留出悬浮底栏的位置
        homeScroll.addView(homeRoot, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        settingsScroll = ScrollView(this)
        settingsScroll.isVerticalScrollBarEnabled = false
        val settingsRoot = LinearLayout(this)
        settingsRoot.orientation = LinearLayout.VERTICAL
        settingsRoot.setPadding(dp(16), dp(22), dp(16), dp(100))
        settingsScroll.addView(settingsRoot, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        settingsScroll.visibility = View.GONE
        frame.addView(homeScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(settingsScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // 底栏悬浮在内容上方（半透明），内容可以从它下面滚过去，不再把页面裁掉一块
        val rootFrame = FrameLayout(this)
        rootFrame.addView(frame, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val tabBar = buildTabBar()
        val lpTab = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lpTab.setMargins(dp(26), 0, dp(26), dp(16))
        rootFrame.addView(tabBar, lpTab)
        pageHost.addView(rootFrame, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(pageHost)

        // 主页：状态、喂食、玩耍、聊天入口、小提示
        root = homeRoot
        buildHeader()
        buildFeedInfo()
        buildPlay()
        buildChatEntry()
        buildTips()

        // 设置：其余所有设置
        root = settingsRoot
        buildSettingsTitle()
        buildVoice()
        buildVoicePack()
        buildBasic()
        buildDock()
        buildBehavior()
        buildBubble()
        buildReminders()
        buildLines()
        buildAi()
        buildBackground()
        buildImage()
        buildBackup()

        selectTab(savedTab, false)
    }

    // ------------------------------------------------------------ 底栏：主页 / 设置

    private lateinit var tabBarView: FrameLayout
    private lateinit var tabIndicator: View
    private val easeOut = android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f) // 平滑减速，不回弹

    private fun buildTabBar(): View {
        val bar = FrameLayout(this)
        bar.background = Ui.glass(this, 30, 0x99)
        val pad = dp(6)
        bar.setPadding(pad, pad, pad, pad)

        // 金色“滑块”：切换时平滑滑到另一个标签下面
        tabIndicator = View(this)
        tabIndicator.background = Ui.goldFill(this, 22)
        bar.addView(tabIndicator, FrameLayout.LayoutParams(0, dp(44)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        tabHome = makeTab("主页") { selectTab(0, true) }
        tabSettings = makeTab("设置") { selectTab(1, true) }
        row.addView(tabHome, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(tabSettings, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        tabBarView = bar
        bar.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> positionIndicator(false) }
        return bar
    }

    private fun positionIndicator(animate: Boolean) {
        val inner = tabBarView.width - tabBarView.paddingLeft - tabBarView.paddingRight
        if (inner <= 0) return
        val w = inner / 2
        val lp = tabIndicator.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w) {
            lp.width = w
            tabIndicator.layoutParams = lp
        }
        val target = (currentTab * w).toFloat()
        tabIndicator.animate().cancel()
        if (animate) {
            tabIndicator.animate().translationX(target).setDuration(320L).setInterpolator(easeOut).start()
        } else {
            tabIndicator.translationX = target
        }
    }

    private fun makeTab(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setOnClickListener { onClick() }
        return t
    }

    private fun tabColor(t: TextView, selected: Boolean, animate: Boolean) {
        val to = if (selected) 0xFF14204F.toInt() else cText
        if (!animate) {
            t.setTextColor(to)
            return
        }
        val from = t.currentTextColor
        val va = android.animation.ValueAnimator.ofArgb(from, to)
        va.duration = 320L
        va.interpolator = easeOut
        va.addUpdateListener { t.setTextColor(it.animatedValue as Int) }
        va.start()
    }

    private fun selectTab(i: Int, animate: Boolean) {
        val prev = currentTab
        currentTab = i
        savedTab = i
        tabColor(tabHome, i == 0, animate && prev != i)
        tabColor(tabSettings, i == 1, animate && prev != i)
        positionIndicator(animate && prev != i)
        if (!animate || prev == i) {
            homeScroll.visibility = if (i == 0) View.VISIBLE else View.GONE
            settingsScroll.visibility = if (i == 1) View.VISIBLE else View.GONE
            return
        }
        val from = if (prev == 0) homeScroll else settingsScroll
        val to = if (i == 0) homeScroll else settingsScroll
        val dir = if (i > prev) 1f else -1f
        val d = dp(28).toFloat()
        to.animate().cancel()
        from.animate().cancel()
        to.visibility = View.VISIBLE
        to.alpha = 0f
        to.translationX = dir * d
        to.animate().alpha(1f).translationX(0f).setDuration(320L).setInterpolator(easeOut).start()
        from.animate().alpha(0f).translationX(-dir * d).setDuration(220L).setInterpolator(easeOut).withEndAction {
            from.visibility = View.GONE
            from.translationX = 0f
            from.alpha = 1f
        }.start()
    }

    private fun buildSettingsTitle() {
        val t = TextView(this)
        t.text = "设置"
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        t.setTextColor(cGold)
        t.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        root.addView(t)
        note("按功能分组，改动会立刻生效。")
    }

    private fun buildChatEntry() {
        section("和她聊天")
        note("用本地 AI 和芙宁娜聊天，让她帮你定闹钟、找文件、放音乐、记事情。第一次使用请先到「设置」里下载或导入模型。")
        button("打开聊天", true) {
            startActivity(Intent(this, ChatActivity::class.java), Ui.pageOptions(this))
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
        pageHost.resumeVideo()
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        pageHost.pauseVideo()
        super.onPause()
    }

    override fun onDestroy() {
        pageHost.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------ 通用控件

    private fun section(text: String) {
        val t = TextView(this)
        t.text = "◆  " + text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        t.setTextColor(cGold)
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.12f
        val lpT = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpT.topMargin = dp(26)
        lpT.bottomMargin = dp(8)
        lpT.leftMargin = dp(4)
        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(t)
        val line = View(this)
        line.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0x88E5C26B.toInt(), 0x00E5C26B)
        )
        val lpLine = LinearLayout.LayoutParams(0, dp(1), 1f)
        lpLine.leftMargin = dp(10)
        titleRow.addView(line, lpLine)
        root.addView(titleRow, lpT)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(10), dp(16), dp(14))
        card.background = Ui.glass(this, 20, 0x99)
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cur = card
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.setTextColor(cSub)
        t.setLineSpacing(0f, 1.15f)
        t.setPadding(0, dp(4), 0, dp(2))
        cur.addView(t)
        return t
    }

    private fun rowLabel(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tv.setTextColor(cText)
        return tv
    }

    private fun switchRow(label: String, key: String, def: Boolean, desc: String? = null) {
        val s = Switch(this)
        s.text = label
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        s.setTextColor(cText)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(states, intArrayOf(cGold, 0xFF8C98C0.toInt()))
        s.trackTintList = ColorStateList(states, intArrayOf(0x66E5C26B, 0x44FFFFFF))
        s.isChecked = prefs.getBoolean(key, def)
        s.setPadding(0, dp(12), 0, dp(4))
        s.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        cur.addView(s)
        if (desc != null) note(desc)
    }

    private fun sliderRow(label: String, key: String, min: Int, max: Int, def: Int, unit: String, step: Int = 1, onChange: (() -> Unit)? = null) {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.setPadding(0, dp(12), 0, 0)
        val l = rowLabel(label)
        val value = TextView(this)
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        value.setTextColor(cGold)
        value.typeface = Typeface.DEFAULT_BOLD
        head.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(value)
        cur.addView(head)

        val c = prefs.getInt(key, def).coerceIn(min, max)
        value.text = "$c$unit"

        val sb = SeekBar(this)
        sb.progressTintList = ColorStateList.valueOf(cGold)
        sb.thumbTintList = ColorStateList.valueOf(cGold)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        sb.max = (max - min) / step
        sb.progress = (c - min) / step
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = min + progress * step
                value.text = "$v$unit"
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                onChange?.invoke()
            }
        })
        cur.addView(sb)
    }

    private fun styleEdit(et: EditText) {
        et.setTextColor(cText)
        et.setHintTextColor(0xFF6E7DAA.toInt())
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
        et.background = rounded(0x990A1238.toInt(), 12, 0x55E5C26B, 1)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun editRow(label: String, key: String, hint: String, multiline: Boolean = false) {
        val tv = rowLabel(label)
        tv.setPadding(0, dp(12), 0, dp(6))
        cur.addView(tv)

        val et = EditText(this)
        et.hint = hint
        et.setText(prefs.getString(key, "") ?: "")
        styleEdit(et)
        if (multiline) {
            et.minLines = 3
            et.gravity = Gravity.TOP or Gravity.START
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            et.setSingleLine(true)
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString(key, s?.toString() ?: "").apply()
            }
        })
        cur.addView(et)
    }

    private fun makeButton(text: String, filled: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.transformationMethod = null
        b.stateListAnimator = null
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        b.typeface = Typeface.DEFAULT_BOLD
        b.setPadding(dp(8), 0, dp(8), 0)
        if (filled) {
            b.setTextColor(cNavy)
            b.background = Ui.goldFill(this, 22)
        } else {
            b.setTextColor(cGold)
            b.background = Ui.ghost(this, 22)
        }
        b.setOnClickListener { onClick() }
        Ui.press(b)
        return b
    }

    private fun button(text: String, filled: Boolean = false, onClick: () -> Unit): Button {
        val b = makeButton(text, filled, onClick)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
        lp.topMargin = dp(10)
        cur.addView(b, lp)
        return b
    }

    private fun buttonGrid(items: List<Pair<String, () -> Unit>>) {
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until 2) {
                val idx = i + j
                val lp = LinearLayout.LayoutParams(0, dp(42), 1f)
                lp.leftMargin = if (j == 1) dp(5) else 0
                lp.rightMargin = if (j == 0) dp(5) else 0
                if (idx < items.size) {
                    val it2 = items[idx]
                    row.addView(makeButton(it2.first, false, it2.second), lp)
                } else {
                    row.addView(View(this), lp)
                }
            }
            val lpRow = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpRow.topMargin = dp(8)
            cur.addView(row, lpRow)
            i += 2
        }
    }

    // ------------------------------------------------------------ 区块

    private fun buildHeader() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.setPadding(dp(14), dp(14), dp(16), dp(14))
        box.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF2B4DB0.toInt(), 0xFF182B72.toInt(), 0xFF0F1A4A.toInt())
        )
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), 0x66E5C26B)
        box.background = bg

        val imgBox = FrameLayout(this)
        imgBox.background = rounded(0x22FFFFFF, 22, 0x33FFFFFF, 1)
        headerImg = ImageView(this)
        headerImg.scaleType = ImageView.ScaleType.FIT_CENTER
        headerImg.setPadding(dp(6), dp(6), dp(6), dp(6))
        val bmp = loadHeaderBitmap()
        if (bmp != null) headerImg.setImageBitmap(bmp)
        imgBox.addView(headerImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val lpImg = LinearLayout.LayoutParams(dp(104), dp(150))
        lpImg.rightMargin = dp(14)
        box.addView(imgBox, lpImg)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val name = TextView(this)
        name.text = "芙宁娜"
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        name.setTextColor(0xFFFFFFFF.toInt())
        name.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        col.addView(name)

        val sub = TextView(this)
        sub.text = "水之舞台 · 桌面陪伴"
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        sub.setTextColor(cGold)
        sub.letterSpacing = 0.15f
        col.addView(sub)

        lvText = TextView(this)
        lvText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        lvText.setTextColor(cText)
        lvText.typeface = Typeface.DEFAULT_BOLD
        lvText.setPadding(0, dp(10), 0, 0)
        col.addView(lvText)

        affBar = BarView(this)
        affBar.setColors(0xFFFFE9A8.toInt(), 0xFFE5B84F.toInt())
        val lpA = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7))
        lpA.topMargin = dp(5)
        col.addView(affBar, lpA)
        affText = TextView(this)
        affText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        affText.setTextColor(cPink)
        affText.setPadding(0, dp(2), 0, 0)
        col.addView(affText)

        fullBar = BarView(this)
        val lpF = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7))
        lpF.topMargin = dp(6)
        col.addView(fullBar, lpF)
        fullText = TextView(this)
        fullText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        fullText.setTextColor(0xFF9ADCFF.toInt())
        fullText.setPadding(0, dp(2), 0, 0)
        col.addView(fullText)

        box.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // 状态卡
        section("登场")
        statusText = note("")
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        statusText.setTextColor(cText)
        permText = note("")
        toggleBtn = button("召唤", true) { toggle() }
        button("授权悬浮窗（第一次必须）", false) { openOverlaySettings() }
    }

    private fun buildFeedInfo() {
        section("喂食与好感")
        note("长按桌宠，会弹出喂食面板：投喂甜点涨饱食度和好感度。饱食度会随时间慢慢下降，饿了她会自己嘟囔；吃撑了就不肯再吃。")
        for (f in Bond.foods) {
            val t = TextView(this)
            val tag = if (f.fav) "  ♥ 最爱" else if (f.bad) "  不爱吃" else ""
            t.text = f.emoji + "  " + f.name + tag + "      饱食 +" + f.fullness + " · 好感 " + (if (f.affection >= 0) "+" else "") + f.affection
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            t.setTextColor(if (f.fav) cGold else cText)
            t.setPadding(0, dp(7), 0, 0)
            cur.addView(t)
        }
        note("好感等级：陌生的观众 → 熟悉的看客 → 座上宾 → 专属观众 → 挚友 → 知己。每天首次召唤 +3，点击每天最多 +15。好感越高，她越会说软话。")
        switchRow("饿了会提醒我", Prefs.HUNGRY_TALK, true)
        button("重置好感度和饱食度", false) {
            GlassDialog(this)
                .setTitle("重置？")
                .setMessage("好感度会回到 0，饱食度回到 60%。")
                .setPositiveButton("重置") { _, _ ->
                    Bond.reset(prefs)
                    refreshStatus()
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }

    private fun launchGame(g: String) {
        val i = Intent(this, GameActivity::class.java)
        i.putExtra("game", g)
        startActivity(i, Ui.pageOptions(this))
    }

    private fun buildPlay() {
        section("玩耍")
        note("长按桌宠，面板里的「玩耍」一栏有这些入口。游戏和专注结束后会增加一点好感，每天共有上限。")
        note(
            "· 接甜点：左右拖动，接住掉落的甜点\n" +
                "· 审判猜拳：和她来几局\n" +
                "· 每日抽签：每天一次，结果当天固定\n" +
                "· 专注陪伴：倒计时期间她不会闲聊，完成后会夸你"
        )
        sliderRow("专注陪伴时长", Prefs.FOCUS_MIN, 5, 90, 25, " 分钟", 5)
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add(Pair("玩：接甜点", { launchGame("catch") }))
        items.add(Pair("玩：审判猜拳", { launchGame("rps") }))
        buttonGrid(items)
        note("接甜点最高分：" + prefs.getInt(Prefs.BEST_CATCH, 0))
    }

    private fun buildVoice() {
        section("语音")
        note("开启后她说话时会出声。默认用手机自带的中文语音朗读，这不是她本人的声音；你也可以为每个场景导入自己录制或有权使用的音频，触发时会随机播放。")
        switchRow("开启语音", Prefs.VOICE_ON, false)

        val tv = rowLabel("发声方式")
        tv.setPadding(0, dp(12), 0, 0)
        cur.addView(tv)
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.VERTICAL
        val names = arrayOf("自定义音频优先，没有就朗读", "只播放自定义音频", "只用系统朗读")
        val mode = prefs.getInt(Prefs.VOICE_MODE, 0)
        for (i in names.indices) {
            val rb = RadioButton(this)
            rb.id = 2000 + i
            rb.text = names[i]
            rb.setTextColor(cText)
            rb.buttonTintList = ColorStateList.valueOf(cGold)
            rg.addView(rb)
        }
        rg.check(2000 + mode)
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt(Prefs.VOICE_MODE, id - 2000).apply()
        }
        cur.addView(rg)

        sliderRow("音量", Prefs.VOICE_VOL, 0, 100, 100, " %", 5)
        sliderRow("朗读语速", Prefs.VOICE_RATE, 60, 160, 100, " %", 5)
        sliderRow("朗读音调", Prefs.VOICE_PITCH, 70, 150, 110, " %", 5)
        button("试听一句", false) {
            val inst = PetService.instance
            if (inst == null) {
                Toast.makeText(this, "先召唤她，才能试听", Toast.LENGTH_SHORT).show()
            } else {
                inst.voiceSay("tap", "哼哼，是在召唤本神吗？说吧，有什么事？")
            }
        }
        button("管理自定义音频（按场景导入）", true) { manageVoice() }
        note("没有声音时：请确认手机装有中文语音引擎（系统设置里的「文字转语音」），并且媒体音量不为 0。")
    }

    private fun buildVoicePack() {
        section("语音包（独立模块）")
        note("把「一段音频 + 它说的那句话」成对放进语音包，触发对应场景时她会显示这句话并播放音频。内容由你在本机导入，应用本身不自带任何第三方录音；请只导入你自己录制或有权使用的音频。")
        switchRow("启用语音包", Prefs.VPACK_ON, true, "关闭时，桌宠完全不使用语音包。")
        switchRow("与现有无配音台词混用", Prefs.VPACK_MIX, true, "开：触发时约一半概率用语音包、一半用普通台词；关：该场景只要语音包里有，就只用语音包，没有才退回普通台词。")
        button("打开语音包管理", true) {
            startActivity(Intent(this, VoicePackActivity::class.java), Ui.pageOptions(this))
        }
    }

    private fun manageVoice() {
        val cats = Lines.cats
        val names = Array(cats.size) { i -> cats[i].label + "（" + VoicePlayer.count(this, cats[i].key) + "）" }
        GlassDialog(this)
            .setTitle("选择要配音的场景")
            .setItems(names) { _, which -> voiceMenu(cats[which]) }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun voiceMenu(c: Lines.Cat) {
        val n = VoicePlayer.count(this, c.key)
        GlassDialog(this)
            .setTitle(c.label)
            .setMessage("已导入 " + n + " 段音频。该场景触发时会随机播放其中一段。\n请只导入你自己录制或有权使用的音频。")
            .setPositiveButton("导入音频") { _, _ ->
                voiceKeyPending = c.key
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "audio/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(i, reqVoice)
            }
            .setNeutralButton("清空") { _, _ ->
                VoicePlayer.clear(this, c.key)
                Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("返回", null)
            .show()
    }

    private fun buildBasic() {
        section("基础")
        editRow("她对你的称呼", Prefs.NAME, "留空则称呼「旅行者」，台词里的 {name} 会换成这个")
        sliderRow("大小", Prefs.SIZE, 80, 320, 150, " dp", 5)
        sliderRow("透明度", Prefs.ALPHA, 20, 100, 100, " %", 5)
        switchRow("触摸震动反馈", Prefs.HAPTIC, true)
        switchRow("召唤时打招呼", Prefs.GREET_ON_START, true)
        switchRow("开机自启", Prefs.BOOT_START, false, "部分手机系统还需要在系统设置里允许本应用「自启动」，否则不生效。")
    }

    private fun buildDock() {
        section("贴边")
        switchRow("拖到屏幕边缘自动贴边", Prefs.AUTO_DOCK, true, "贴边后会藏起一部分身体，朝屏幕里歪着头；点她一下会探出来说话。")
        sliderRow("藏起身体的比例", Prefs.HIDE_PCT, 30, 70, 50, " %", 5)
        sliderRow("歪头角度", Prefs.TILT, 0, 35, 18, " °", 1)
    }

    private fun buildBehavior() {
        section("行为")
        switchRow("随机自言自语", Prefs.CHAT, true)
        sliderRow("平均每隔多久说一句", Prefs.CHAT_SEC, 20, 600, 90, " 秒", 10)
        switchRow("在屏幕上随机溜达", Prefs.WANDER, false, "开启后她会时不时自己走到别处，有时回到边缘待着。")
        sliderRow("平均每隔多久溜达一次", Prefs.WANDER_SEC, 20, 600, 60, " 秒", 10)
        switchRow("电量低 / 插上充电器时说话", Prefs.BATTERY_TALK, true)
        switchRow("勿扰时段", Prefs.QUIET_ON, false, "勿扰期间不闲聊、不报时、不提醒喝水休息；自定义定时提醒不受影响。")
        sliderRow("勿扰开始", Prefs.QUIET_FROM, 0, 23, 23, " 点", 1)
        sliderRow("勿扰结束", Prefs.QUIET_TO, 0, 23, 7, " 点", 1)
    }

    private fun buildBubble() {
        section("对话气泡")
        sliderRow("基础显示时长", Prefs.BUBBLE_SEC, 2, 15, 5, " 秒", 1)
        sliderRow("文字大小", Prefs.BUBBLE_TEXT, 11, 22, 14, " sp", 1)

        val tv = rowLabel("气泡风格")
        tv.setPadding(0, dp(12), 0, 0)
        cur.addView(tv)

        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        val names = arrayOf("水神蓝", "白金", "夜剧场")
        val c = prefs.getInt(Prefs.BUBBLE_THEME, 0)
        for (i in names.indices) {
            val rb = RadioButton(this)
            rb.id = 1000 + i
            rb.text = names[i]
            rb.setTextColor(cText)
            rb.buttonTintList = ColorStateList.valueOf(cGold)
            rg.addView(rb)
        }
        rg.check(1000 + c)
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt(Prefs.BUBBLE_THEME, id - 1000).apply()
        }
        cur.addView(rg)
    }

    private fun buildReminders() {
        section("提醒")
        switchRow("整点报时", Prefs.HOURLY, false)
        switchRow("喝水提醒", Prefs.WATER_ON, false)
        sliderRow("喝水间隔", Prefs.WATER_MIN, 15, 180, 60, " 分钟", 5)
        switchRow("休息提醒（离开屏幕活动一下）", Prefs.REST_ON, false)
        sliderRow("休息间隔", Prefs.REST_MIN, 15, 120, 45, " 分钟", 5)
        editRow(
            "自定义定时提醒",
            Prefs.REMINDERS,
            "每行一条，例如：\n08:30 起床吃早餐\n22:45 {name}，该准备睡觉啦",
            true
        )
        note("24 小时制「时:分 内容」，每天到点提醒；需要桌宠保持运行。")
    }

    private fun buildLines() {
        section("台词自定义")
        note("每个场景一行一句，随机抽取。{name} 代表你的称呼，整点报时可用 {time}，好感升级可用 {level}。留空则该场景保持沉默。")
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (c in Lines.cats) {
            items.add(Pair(c.label, { editLines(c) }))
        }
        buttonGrid(items)
    }

    private fun buildImage() {
        section("形象")
        button("更换形象图片（相册）", true) {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(Intent.createChooser(i, "选择图片"), reqImg)
        }
        button("恢复默认形象", false) {
            PetService.customImageFile(this).delete()
            prefs.edit().putLong(Prefs.IMG_VERSION, System.currentTimeMillis()).apply()
            val b = loadHeaderBitmap()
            if (b != null) headerImg.setImageBitmap(b)
            Toast.makeText(this, "已恢复默认形象", Toast.LENGTH_SHORT).show()
        }
        note("建议使用背景透明的 PNG 立绘（人物占满画面，朝向正面）。带背景的图片会显示成一个方块。")
    }

    // ------------------------------------------------------------ 界面背景

    private fun buildBackground() {
        section("界面背景")
        note(
            "给主页、设置页和聊天页换自己的背景：可以选图片，也可以选视频做动态背景（静音循环播放，居中裁剪铺满）。" +
                "视频比较耗电，建议选 10~30 秒、80MB 以内的短视频。"
        )
        button("选择背景（图片或视频）", true) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            try {
                startActivityForResult(i, reqBg)
            } catch (e: Exception) {
                Toast.makeText(this, "找不到可用的文件管理器", Toast.LENGTH_LONG).show()
            }
        }
        button("一键恢复默认背景", false) {
            Ui.resetBackground(this)
            prefs.edit().putInt(Prefs.UI_BG_BLUR, 40).putInt(Prefs.UI_BG_DIM, 35).apply()
            Toast.makeText(this, "已恢复默认背景", Toast.LENGTH_SHORT).show()
            recreate()
        }
        sliderRow("背景模糊（仅图片）", Prefs.UI_BG_BLUR, 0, 100, 40, "%", 5) { applyBackground() }
        sliderRow("背景压暗", Prefs.UI_BG_DIM, 0, 80, 35, "%", 5) { applyBackground() }
        note("默认背景是芙宁娜的水蓝渐变。视频背景不会随配置文件备份（文件太大），图片背景会。")
    }

    private fun applyBackground() {
        pageHost.refresh()
    }

    private fun importBackground(uri: Uri) {
        val isVideo = (contentResolver.getType(uri) ?: "").startsWith("video/")
        val dlg = busyDialog(if (isVideo) "正在处理背景视频…" else "正在处理背景图片…")
        Thread {
            var err: String? = null
            try {
                if (isVideo) Ui.saveBackgroundVideo(this, uri) else Ui.saveBackground(this, uri)
            } catch (e: Throwable) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                safeDismiss(dlg)
                if (err == null) {
                    applyBackground()
                    Toast.makeText(this, "背景已更换", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "更换失败：$err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ------------------------------------------------------------ AI 聊天（本地模型）

    private fun buildAi() {
        section("AI 聊天（本地模型）")
        note(
            "在手机上本地运行大模型，和芙宁娜聊天，聊天本身不需要网络。她的语气会随好感度、饱食度和时间变化。\n" +
                "首次使用点下面的「一键下载默认模型」（Gemma 4 E2B，约 2.6GB，需要联网下载一次，建议用 Wi-Fi）。" +
                "官方实测运行时峰值内存约 1.7GB（旗舰机、CPU），较新的手机更稳；第一次加载要等一会儿。"
        )
        aiStatusText = note("")
        refreshAiStatus()
        val gemma = Models.byId(Models.GEMMA)
        val ds = Models.byId(Models.DEEPSEEK)
        aiDownloadBtn = button(downloadBtnText(gemma), !Models.installed(this, gemma)) {
            ModelDownloader.show(this, gemma) { refreshAiStatus() }
        }
        aiDsBtn = button(downloadBtnText(ds), false) {
            ModelDownloader.show(this, ds) { refreshAiStatus() }
        }
        note("DeepSeek 手机轻量版：DeepSeek-R1 蒸馏 1.5B（int8，约 1.8GB，MIT 协议），体积比默认模型小、推理能力强，适合配置一般的手机；" +
            "它会先“思考”再回答，所以更慢一点，思考过程不会显示给你。可以和默认模型同时安装，在「管理 / 切换模型」里随时切换。")
        button("从本地导入模型文件（.litertlm）", false) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            try {
                startActivityForResult(i, reqModel)
            } catch (e: Exception) {
                Toast.makeText(this, "找不到可用的文件管理器", Toast.LENGTH_LONG).show()
            }
        }
        button("管理 / 切换 / 删除模型", false) { ModelManager.show(this) { refreshAiStatus() } }
        switchRow("手机助手：让她帮你定闹钟/倒计时、找文件、打开应用、开关手电筒（改变手机的操作会先问你）", Prefs.AI_ACTIONS, true)
        switchRow("心动模式：好感达到 Lv.4（专属观众）及以上时，她会更撒娇、更亲昵（含蓄的甜蜜风格）", Prefs.AI_ROMANCE, true)
        switchRow("聊天自动朗读（用手机自带的语音引擎读出她的回复，括号里的动作不会读）", Prefs.AI_TTS, false)
        sliderRow("朗读语速", Prefs.TTS_RATE, 50, 200, 100, "%", 10)
        sliderRow("朗读音调", Prefs.TTS_PITCH, 50, 200, 100, "%", 10)
        button("系统朗读设置（选择语音引擎和音色）", false) {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                } catch (x: Exception) {
                    Toast.makeText(this, "打不开系统设置", Toast.LENGTH_SHORT).show()
                }
            }
        }
        note("朗读用的是手机自带的语音引擎，音色由系统决定；还没有接入“用你自己的声音朗读”（声音克隆）。")
        switchRow("拟真模式：更像真人聊天（网友口吻、有情绪、像真人朋友一样关心你、一步步了解你并自动记住你说的关于自己的话、怕被关机会撒娇求饶、偶尔打错字再更正、像连发微信；聊天页每条回复下会标注“AI 生成，并非真人”，认真问她是不是真人时她会如实承认）", Prefs.AI_HUMAN, true)
        switchRow("DeepSeek 深度思考（开：先想后答，更准但很慢；关：直接快速回复。仅对 DeepSeek 模型有效，聊天页也能开关）", Prefs.AI_DEEP, false)
        switchRow("使用 GPU 加速（实验性，失败会自动改用 CPU）", Prefs.AI_GPU, false)
        editRow("自定义模型下载地址（可选，https）", Prefs.AI_MODEL_URL, "留空则使用默认地址", false)
        aiEngineBtn = button(engineButtonText(), false) { chooseEngine() }
        editRow("博查搜索 API Key（可选，最稳定）", Prefs.AI_BOCHA_KEY, "在博查开放平台申请的 Key（只保存在本机，不会进备份）", false)
        editRow("自定义搜索接口（可选）", Prefs.AI_SEARX_URL, "https://你的搜索站点（SearXNG，需 https）", false)
        note(
            "模型本身不能上网：打开聊天页顶部的「联网搜索」后，应用会先去搜索，再把结果交给她回答。\n" +
                "搜索引擎可以自己选。“自动”会依次试 必应 → 百度 → 360 → 搜狗 → 维基；如果填了博查 API Key，会优先用博查。" +
                "除博查外都是抓取网页，网页改版或触发安全验证时可能失效，最稳的办法是申请一个博查 API Key。搜索失败时她会凭记忆回答。"
        )
        button("测试联网搜索", false) { testSearch() }
        button("打开工作模式", false) {
            startActivity(Intent(this, WorkActivity::class.java), Ui.pageOptions(this))
        }
        button("管理 AI 记忆（聊天 / 工作模式）", false) {
            GlassDialog(this)
                .setTitle("管理哪一份记忆？")
                .setItems(arrayOf("聊天记忆（和芙宁娜聊天用）", "工作记忆（工作模式用）")) { _, which ->
                    val i = Intent(this, MemoryActivity::class.java)
                    i.putExtra("scope", if (which == 1) AiMemory.WORK else AiMemory.CHAT)
                    startActivity(i, Ui.pageOptions(this))
                }
                .show()
        }
        button("打开聊天", false) {
            val i = Intent(this, ChatActivity::class.java)
            startActivity(i, Ui.pageOptions(this))
        }
    }

    private fun engineButtonText(): String =
        "搜索引擎：" + WebSearch.engineLabel(prefs.getString(Prefs.AI_ENGINE, "auto") ?: "auto") + "（点击切换）"

    private fun chooseEngine() {
        val names = Array<CharSequence>(WebSearch.engines.size) { i -> WebSearch.engines[i].label }
        GlassDialog(this)
            .setTitle("选择搜索引擎")
            .setItems(names) { _, which ->
                prefs.edit().putString(Prefs.AI_ENGINE, WebSearch.engines[which].id).apply()
                aiEngineBtn.text = engineButtonText()
            }
            .show()
    }

    private fun testSearch() {
        val dlg = busyDialog("正在搜索“芙宁娜”…")
        Thread {
            var msg: String
            try {
                val hits = WebSearch.searchDeep(prefs, "芙宁娜")
                msg = if (hits.isEmpty()) {
                    "联网正常，但没有搜到结果。"
                } else {
                    val deep = hits.count { it.body.isNotEmpty() }
                    val sb = StringBuilder("联网正常，来源：" + WebSearch.lastSource + "，共 " + hits.size + " 条结果，其中 " + deep + " 条读取到了网页正文。\n")
                    for (h in hits.take(2)) sb.append("\n· ").append(h.title).append("：").append(h.best().take(160))
                    sb.toString()
                }
            } catch (e: Exception) {
                msg = "搜索失败：" + (e.message ?: e.toString()) +
                    "\n\n请检查：手机是否能上网、是否开了全局代理/VPN、系统有没有禁止本应用联网（手机管家里的联网权限）。"
            }
            runOnUiThread {
                safeDismiss(dlg)
                GlassDialog(this).setTitle("测试结果").setMessage(msg).setPositiveButton("好", null).show()
            }
        }.start()
    }

    private fun downloadBtnText(spec: Models.Spec): String {
        val has = Models.installed(this, spec)
        return when (spec.id) {
            Models.GEMMA -> if (has) "重新下载默认模型（已安装，一般不需要）" else "一键下载默认模型（Gemma 4，" + spec.sizeText + "）"
            else -> if (has) "重新下载 DeepSeek 轻量模型（已安装）" else "一键下载 DeepSeek 手机轻量模型（" + spec.sizeText + "）"
        }
    }

    private fun refreshAiStatus() {
        val have = Models.installedList(this)
        if (have.isEmpty()) {
            aiStatusText.text = "模型状态：未导入"
            aiStatusText.setTextColor(0xFFFF8A80.toInt())
        } else {
            val cur = Models.active(this)
            val names = have.joinToString("、") { it.shortName }
            aiStatusText.text = "模型状态：已安装 " + have.size + " 个（" + names + "）\n当前使用：" + cur.label +
                "（" + fmtSize(Models.file(this, cur).length()) + "）"
            aiStatusText.setTextColor(0xFF7BD88F.toInt())
        }
        if (::aiDownloadBtn.isInitialized) aiDownloadBtn.text = downloadBtnText(Models.byId(Models.GEMMA))
        if (::aiDsBtn.isInitialized) aiDsBtn.text = downloadBtnText(Models.byId(Models.DEEPSEEK))
    }

    private fun importModelFrom(uri: Uri) {
        val dlg = busyDialog("正在导入模型…\n文件很大，请保持屏幕常亮，不要退出。")
        Thread {
            var err: String? = null
            try {
                LocalAi.importModel(this, uri) { done, total ->
                    runOnUiThread {
                        val t = if (total > 0L) " / " + fmtSize(total) else ""
                        dlg.setMessage("正在导入模型…\n已复制 " + fmtSize(done) + t)
                    }
                }
            } catch (e: Throwable) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                safeDismiss(dlg)
                try {
                    refreshAiStatus()
                } catch (e: Exception) {
                }
                if (err == null) {
                    Toast.makeText(this, "模型已导入，可以去聊天了。导入后可以删掉原文件省空间", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "导入失败：$err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ------------------------------------------------------------ 备份与迁移

    private fun buildBackup() {
        section("备份与迁移")
        note("换手机前，在旧设备点「导出」生成备份文件，传到新设备后点「导入」。会带走：好感度、饱食度、全部设置、自定义台词、自定义形象，以及（可选）你导入的语音。")
        button("导出配置文件", true) { askExport() }
        button("导入配置文件", false) { pickImport() }
        note("导入会覆盖本机现有的设置、好感度、饱食度和台词；悬浮位置、是否正在运行等本机状态不受影响。")
    }

    private fun fmtSize(b: Long): String {
        return if (b >= 1024L * 1024L) String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else String.format(Locale.US, "%d KB", maxOf(1L, b / 1024L))
    }

    private fun askExport() {
        val size = Backup.voiceBytes(this)
        if (size <= 0L) {
            pendingWithVoice = false
            launchCreate()
            return
        }
        var withVoice = true
        GlassDialog(this)
            .setTitle("导出配置文件")
            .setMultiChoiceItems(
                arrayOf("同时导出语音文件（约 " + fmtSize(size) + "）"),
                booleanArrayOf(true)
            ) { _, _, checked -> withVoice = checked }
            .setPositiveButton("选择保存位置") { _, _ ->
                pendingWithVoice = withVoice
                launchCreate()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun launchCreate() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/zip"
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        i.putExtra(Intent.EXTRA_TITLE, "FurinaPet_backup_$stamp.zip")
        try {
            startActivityForResult(i, reqExport)
        } catch (e: Exception) {
            Toast.makeText(this, "找不到可用的文件管理器", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
        try {
            startActivityForResult(i, reqImport)
        } catch (e: Exception) {
            Toast.makeText(this, "找不到可用的文件管理器", Toast.LENGTH_LONG).show()
        }
    }

    private fun busyDialog(msg: String): AlertDialog {
        val d = GlassDialog(this)
            .setMessage(msg)
            .setCancelable(false)
            .create()
        d.show()
        return d
    }

    private fun safeDismiss(d: AlertDialog) {
        try {
            d.dismiss()
        } catch (e: Exception) {
        }
    }

    private fun doExport(uri: Uri) {
        val withVoice = pendingWithVoice
        val dlg = busyDialog("正在导出…")
        Thread {
            var err: String? = null
            try {
                val out = contentResolver.openOutputStream(uri, "wt")
                    ?: throw Backup.BackupException("无法写入所选位置")
                out.use { Backup.export(this, it, withVoice) }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                safeDismiss(dlg)
                if (err == null) {
                    Toast.makeText(this, "已导出，把这个文件传到新设备再导入即可", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "导出失败：$err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** 先读备份里的摘要，让用户确认后再真正导入 */
    private fun previewImport(uri: Uri) {
        Thread {
            var info: Backup.Info? = null
            var err: String? = null
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw Backup.BackupException("无法读取这个文件")
                info = input.use { Backup.readInfo(it) }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                val inf = info
                if (inf == null) {
                    Toast.makeText(this, "无法导入：$err", Toast.LENGTH_LONG).show()
                } else {
                    confirmImport(uri, inf)
                }
            }
        }.start()
    }

    private fun confirmImport(uri: Uri, inf: Backup.Info) {
        val lv = Bond.level(inf.aff)
        val time = if (inf.exportedAt > 0L)
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(inf.exportedAt))
        else "未知"
        val sb = StringBuilder()
        sb.append("备份时间：").append(time).append('\n')
        if (inf.name.isNotBlank()) sb.append("称呼：").append(inf.name).append('\n')
        sb.append("好感：").append(inf.aff).append("（").append(Bond.levelNames[lv]).append("）\n")
        sb.append("饱食：").append(inf.full.toInt()).append("%\n")
        sb.append("自定义形象：").append(if (inf.hasImage) "有" else "无").append('\n')
        sb.append("语音文件：").append(if (inf.hasVoice) "有" else "无").append("\n")
        sb.append("AI 记忆：").append(if (inf.memoryCount > 0) inf.memoryCount.toString() + " 条（会和本机记忆合并，不会删除本机已有的）" else "无").append("\n\n")
        sb.append("导入后会覆盖本机的设置、好感度、饱食度和台词")
        if (inf.hasVoice) sb.append("，以及本机的自定义语音")
        sb.append("。确定要导入吗？")
        GlassDialog(this)
            .setTitle("导入配置文件")
            .setMessage(sb.toString())
            .setPositiveButton("导入") { _, _ -> doImport(uri) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun doImport(uri: Uri) {
        val wasRunning = PetService.running
        if (wasRunning) PetService.stop(this) // 先让她退场，避免导入过程中被写回旧位置
        val dlg = busyDialog("正在导入…")
        Thread {
            var err: String? = null
            try {
                if (wasRunning) Thread.sleep(700L)
                val input = contentResolver.openInputStream(uri)
                    ?: throw Backup.BackupException("无法读取这个文件")
                input.use { Backup.import(this, it) }
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                safeDismiss(dlg)
                if (wasRunning) {
                    try {
                        PetService.start(this)
                    } catch (e: Exception) {
                    }
                }
                if (err == null) {
                    Toast.makeText(this, "导入完成", Toast.LENGTH_LONG).show()
                    recreate() // 重建界面，让所有开关和滑块显示导入后的值
                } else {
                    Toast.makeText(this, "导入失败：$err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun buildTips() {
        section("使用小提示")
        note(
            "· 轻点：她会回应你，并蹦一下\n" +
                "· 双击：戏剧性的转圈表演\n" +
                "· 短时间连点很多下：她会发火（或者认输）\n" +
                "· 长按：打开面板（喂食、玩耍、设置入口都在里面）\n" +
                "· 拖动：放到想要的位置；拖到屏幕边缘会藏起半个身子歪头待机\n" +
                "· 退场：下拉通知栏点「让她退场」，或在上面点「让她退场」\n" +
                "· 她总是消失：请在系统设置里把本应用的电池策略设为「无限制」，并允许后台运行"
        )
    }

    // ------------------------------------------------------------ 状态

    private fun loadHeaderBitmap(): Bitmap? {
        val o = BitmapFactory.Options()
        o.inSampleSize = 2
        val f = PetService.customImageFile(this)
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.absolutePath, o)
            if (b != null) return b
        }
        return try {
            assets.open("furina.png").use { BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Exception) {
            null
        }
    }

    private fun refreshStatus() {
        val canDraw = Settings.canDrawOverlays(this)
        permText.text = if (canDraw) "悬浮窗权限：已授权" else "悬浮窗权限：未授权（请先点下面的按钮授权）"
        permText.setTextColor(if (canDraw) 0xFF7BD88F.toInt() else 0xFFFF8A80.toInt())
        statusText.text = if (PetService.running) "芙宁娜正在你的桌面上" else "她还没有登场"
        toggleBtn.text = if (PetService.running) "让她退场" else "召唤"

        val a = Bond.aff(prefs)
        val l = Bond.level(a)
        lvText.text = "Lv." + (l + 1) + " · " + Bond.levelNames[l]
        affText.text = if (l >= Bond.maxLevel()) "好感 " + a + " · 满级" else "好感 " + a + " / " + Bond.levelEnd(l)
        affBar.progress = Bond.levelProgress(a)
        val f = Bond.fullness(prefs)
        fullText.text = "饱食 " + f.toInt() + "%"
        if (f < 25f) fullBar.setColors(0xFFFFB0A0.toInt(), 0xFFFF6B6B.toInt())
        else fullBar.setColors(0xFFA8E6FF.toInt(), 0xFF5BB8F5.toInt())
        fullBar.progress = f / 100f
    }

    private fun toggle() {
        if (PetService.running) {
            PetService.stop(this)
            handler.postDelayed({ refreshStatus() }, 400L)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授权悬浮窗", Toast.LENGTH_SHORT).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
        PetService.start(this)
        handler.postDelayed({ refreshStatus() }, 600L)
    }

    private fun openOverlaySettings() {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "无法打开授权页，请在系统设置里手动允许「显示在其他应用上层」", Toast.LENGTH_LONG).show()
        }
    }

    private fun editLines(c: Lines.Cat) {
        val et = EditText(this)
        et.setText(Lines.getRaw(prefs, c.key))
        et.minLines = 8
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)

        GlassDialog(this)
            .setTitle("编辑：" + c.label)
            .setMessage("一行一句，随机抽取。\n" + c.hint)
            .setView(box)
            .setPositiveButton("保存") { _, _ ->
                prefs.edit().putString("lines_" + c.key, et.text.toString()).apply()
                Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("恢复默认") { _, _ ->
                prefs.edit().remove("lines_" + c.key).apply()
                Toast.makeText(this, "已恢复默认台词", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqBg) {
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) importBackground(u)
            return
        }
        if (requestCode == reqModel) {
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) importModelFrom(u)
            return
        }
        if (requestCode == reqExport) {
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) doExport(u)
            return
        }
        if (requestCode == reqImport) {
            val u = data?.data
            if (resultCode == RESULT_OK && u != null) previewImport(u)
            return
        }
        if (requestCode == reqVoice) {
            if (resultCode == RESULT_OK && data != null) {
                val uris = ArrayList<Uri>()
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
                } else {
                    val u = data.data
                    if (u != null) uris.add(u)
                }
                var ok = 0
                for (u in uris) {
                    if (VoicePlayer.importFile(this, voiceKeyPending, u)) ok++
                }
                Toast.makeText(this, "成功导入 " + ok + " 段（每个场景最多 10 段，单个不超过 6MB）", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (requestCode != reqImg || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bmp = decodeScaled(uri)
            if (bmp == null) {
                Toast.makeText(this, "这张图片读取失败", Toast.LENGTH_SHORT).show()
                return
            }
            val trimmed = trimTransparent(bmp)
            FileOutputStream(PetService.customImageFile(this)).use {
                trimmed.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            prefs.edit().putLong(Prefs.IMG_VERSION, System.currentTimeMillis()).apply()
            val hb = loadHeaderBitmap()
            if (hb != null) headerImg.setImageBitmap(hb)
            Toast.makeText(this, "形象已更换", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "更换失败：" + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun decodeScaled(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun trimTransparent(b: Bitmap): Bitmap {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((px[y * w + x] ushr 24) > 16) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return b
        return Bitmap.createBitmap(b, minX, minY, maxX - minX + 1, maxY - minY + 1)
    }
}

// 记住上次停在哪个页面（主页/设置），重建界面时回到原处
private var savedTab = 0

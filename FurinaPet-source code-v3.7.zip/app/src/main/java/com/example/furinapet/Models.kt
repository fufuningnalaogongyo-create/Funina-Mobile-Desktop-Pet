package com.example.furinapet

import android.content.Context
import java.io.File

/**
 * 本地模型清单：可以同时装多个模型，随时切换、单独删除。
 * 文件都放在应用私有目录 files/ai/ 下；旧版本装的模型（model.litertlm）归在第一项里，升级后原样可用。
 */
object Models {

    class Spec(
        val id: String,
        val label: String,
        val shortName: String,
        val fileName: String,
        val sizeText: String,
        val official: String,
        val mirror: String,
        val intro: String
    ) {
        val downloadable: Boolean get() = official.isNotEmpty()
    }

    private const val DS_REPO = "litert-community/DeepSeek-R1-Distill-Qwen-1.5B"
    private const val DS_FILE = "DeepSeek-R1-Distill-Qwen-1.5B_multi-prefill-seq_q8_ekv4096.litertlm"

    const val GEMMA = "gemma"
    const val DEEPSEEK = "deepseek"
    const val CUSTOM = "custom"

    val list: List<Spec> = listOf(
        Spec(
            GEMMA, "Gemma 4 E2B（默认）", "Gemma 4", "model.litertlm", "约 2.6GB",
            ModelDownloader.OFFICIAL, ModelDownloader.MIRROR,
            "Gemma 4 E2B，Apache-2.0 协议，聊天自然，推荐。旧版本里导入/下载的模型也在这一项。"
        ),
        Spec(
            DEEPSEEK, "DeepSeek-R1 手机轻量版（1.5B）", "DeepSeek 1.5B", "model_deepseek.litertlm", "约 1.8GB",
            "https://huggingface.co/$DS_REPO/resolve/main/$DS_FILE",
            "https://hf-mirror.com/$DS_REPO/resolve/main/$DS_FILE",
            "DeepSeek-R1 蒸馏版 1.5B（int8，MIT 协议），体积小、推理强，适合配置一般的手机；" +
                "它是“先想后答”的模型，回答会慢一点，口语和角色扮演不如 Gemma 自然。"
        ),
        Spec(
            CUSTOM, "本地导入的模型", "自选模型", "model_custom.litertlm", "",
            "", "",
            "从手机文件里导入的 .litertlm 模型（设置页「从本地导入模型文件」）。"
        )
    )

    fun byId(id: String): Spec = list.firstOrNull { it.id == id } ?: list[0]

    fun file(ctx: Context, s: Spec): File = File(LocalAi.dir(ctx), s.fileName)

    fun installed(ctx: Context, s: Spec): Boolean {
        val f = file(ctx, s)
        return f.isFile && f.length() > 0L
    }

    fun installedList(ctx: Context): List<Spec> = list.filter { installed(ctx, it) }

    /** 当前使用的模型：用户选的那个（装着才算）；没有就用第一个已装的；都没装就是默认模型（下载默认模型时用） */
    fun active(ctx: Context): Spec {
        val want = Prefs.get(ctx).getString(Prefs.AI_MODEL_ACTIVE, "") ?: ""
        val w = list.firstOrNull { it.id == want }
        if (w != null && installed(ctx, w)) return w
        return installedList(ctx).firstOrNull() ?: w ?: list[0]
    }

    fun setActive(ctx: Context, id: String) {
        Prefs.get(ctx).edit().putString(Prefs.AI_MODEL_ACTIVE, id).apply()
    }

    fun partFile(ctx: Context, s: Spec): File =
        File(LocalAi.dir(ctx), if (s.id == GEMMA) "model.part" else "model_" + s.id + ".part")

    /** 删除一个模型（连同没下完的残留文件）。正在用的会先释放内存。可能阻塞，请在后台线程调用 */
    fun delete(ctx: Context, s: Spec) {
        val wasActive = active(ctx).id == s.id
        if (wasActive) LocalAi.release()
        file(ctx, s).delete()
        partFile(ctx, s).delete()
        if (wasActive) {
            // 删掉的是正在用的：改用剩下的第一个，没有就清掉选择
            val next = installedList(ctx).firstOrNull()
            Prefs.get(ctx).edit().putString(Prefs.AI_MODEL_ACTIVE, next?.id ?: "").apply()
        }
    }
}

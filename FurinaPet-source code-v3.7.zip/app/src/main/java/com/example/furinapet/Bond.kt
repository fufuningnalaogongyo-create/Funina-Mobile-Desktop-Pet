package com.example.furinapet

import android.content.SharedPreferences
import java.util.Calendar
import kotlin.random.Random

/** 好感度 + 饱食度系统。 */
object Bond {

    class Food(
        val id: String,
        val emoji: String,
        val name: String,
        val fullness: Int,
        val affection: Int,
        val fav: Boolean,
        val bad: Boolean = false
    )

    class Result(val accepted: Boolean, val levelUp: Boolean, val newLevel: Int, val gain: Int)

    val foods: List<Food> = listOf(
        Food("cake", "🍰", "奶油蛋糕", 18, 8, true),
        Food("tart", "🍓", "草莓塔", 14, 7, true),
        Food("pudding", "🍮", "焦糖布丁", 14, 7, true),
        Food("cupcake", "🧁", "纸杯蛋糕", 12, 5, false),
        Food("croissant", "🥐", "可颂", 14, 3, false),
        Food("cookie", "🍪", "曲奇", 8, 3, false),
        Food("choco", "🍫", "巧克力", 8, 4, false),
        Food("tea", "☕", "下午茶", 6, 3, false),
        Food("broccoli", "🥦", "西兰花", 5, -2, false, true)
    )

    val levelNames = listOf("陌生的观众", "熟悉的看客", "座上宾", "专属观众", "挚友", "知己")
    private val levelAt = intArrayOf(0, 50, 150, 350, 700, 1200)
    private const val DECAY_PER_HOUR = 8f
    private const val MAX_AFF = 9999

    fun aff(p: SharedPreferences): Int = p.getInt(Prefs.AFF, 0)

    fun level(a: Int): Int {
        var l = 0
        for (i in levelAt.indices) {
            if (a >= levelAt[i]) l = i
        }
        return l
    }

    fun maxLevel(): Int = levelAt.size - 1
    fun levelStart(l: Int): Int = levelAt[l]
    fun levelEnd(l: Int): Int = if (l + 1 < levelAt.size) levelAt[l + 1] else levelAt[l]

    /** 当前等级内的进度 0..1 */
    fun levelProgress(a: Int): Float {
        val l = level(a)
        if (l >= maxLevel()) return 1f
        val s = levelStart(l)
        val e = levelEnd(l)
        return ((a - s).toFloat() / (e - s).toFloat()).coerceIn(0f, 1f)
    }

    fun ensureInit(p: SharedPreferences) {
        if (p.getLong(Prefs.FULL_TS, 0L) == 0L) {
            p.edit().putFloat(Prefs.FULL, 60f).putLong(Prefs.FULL_TS, System.currentTimeMillis()).apply()
        }
    }

    fun fullness(p: SharedPreferences): Float {
        val stored = p.getFloat(Prefs.FULL, 60f)
        val ts = p.getLong(Prefs.FULL_TS, 0L)
        if (ts == 0L) return stored
        val hours = (System.currentTimeMillis() - ts) / 3600000f
        return (stored - hours * DECAY_PER_HOUR).coerceIn(0f, 100f)
    }

    /** 返回是否升级 */
    fun addAff(p: SharedPreferences, n: Int): Boolean {
        val before = aff(p)
        val after = (before + n).coerceIn(0, MAX_AFF)
        p.edit().putInt(Prefs.AFF, after).apply()
        return level(after) > level(before)
    }

    fun feed(p: SharedPreferences, f: Food): Result {
        val cur = fullness(p)
        if (cur >= 95f) return Result(false, false, level(aff(p)), 0)
        val nf = (cur + f.fullness).coerceAtMost(100f)
        var gain = f.affection
        if (gain > 0 && cur < 30f) gain = (gain * 1.5f).toInt()
        p.edit().putFloat(Prefs.FULL, nf).putLong(Prefs.FULL_TS, System.currentTimeMillis()).apply()
        val lu = addAff(p, gain)
        return Result(true, lu, level(aff(p)), gain)
    }

    private fun dayKey(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    /** 每天最多靠点击涨 15 点好感 */
    fun tapAff(p: SharedPreferences): Boolean {
        val d = dayKey()
        var n = p.getInt(Prefs.TAP_TODAY, 0)
        if (p.getInt(Prefs.TAP_DAY, 0) != d) {
            n = 0
            p.edit().putInt(Prefs.TAP_DAY, d).putInt(Prefs.TAP_TODAY, 0).apply()
        }
        if (n >= 15) return false
        p.edit().putInt(Prefs.TAP_TODAY, n + 1).apply()
        return addAff(p, 1)
    }

    /** 每天第一次召唤 +3 */
    fun daily(p: SharedPreferences): Boolean {
        val d = dayKey()
        if (p.getInt(Prefs.DAY, 0) == d) return false
        p.edit().putInt(Prefs.DAY, d).apply()
        return addAff(p, 3)
    }

    /** 玩耍类奖励（游戏、专注）每天最多共 30 点 */
    fun playAff(p: SharedPreferences, n: Int): Boolean {
        val d = dayKey()
        var played = p.getInt(Prefs.PLAY_TODAY, 0)
        if (p.getInt(Prefs.PLAY_DAY, 0) != d) {
            played = 0
            p.edit().putInt(Prefs.PLAY_DAY, d).putInt(Prefs.PLAY_TODAY, 0).apply()
        }
        val add = minOf(n, 30 - played)
        if (add <= 0) return false
        p.edit().putInt(Prefs.PLAY_TODAY, played + add).apply()
        return addAff(p, add)
    }

    /** 和她聊天，每条 +1 好感，每天最多 10 点 */
    fun chatAff(p: SharedPreferences): Boolean {
        val d = dayKey()
        var n = p.getInt(Prefs.CHAT_TODAY, 0)
        if (p.getInt(Prefs.CHAT_DAY, 0) != d) {
            n = 0
            p.edit().putInt(Prefs.CHAT_DAY, d).putInt(Prefs.CHAT_TODAY, 0).apply()
        }
        if (n >= 10) return false
        p.edit().putInt(Prefs.CHAT_TODAY, n + 1).apply()
        return addAff(p, 1)
    }

    val fortunes: List<Pair<String, String>> = listOf(
        Pair("大吉", "舞台灯光全为你亮起，想做的事放手去做吧！"),
        Pair("中吉", "事事顺遂，记得给自己留一份甜点作奖励。"),
        Pair("小吉", "小小的幸运藏在不经意的瞬间，留心看看吧。"),
        Pair("平", "平平淡淡也是好剧本，稳稳地演完这一幕就好。"),
        Pair("末吉", "先苦后甜，熬过去就有蛋糕在等你。"),
        Pair("小凶", "今天容易手忙脚乱，深呼吸，{name}，本神会在旁边看着你。")
    )
    private val fortuneWeights = intArrayOf(1, 3, 3, 3, 2, 1)

    fun rollFortune(): Int {
        var total = 0
        for (w in fortuneWeights) total += w
        var r = Random.nextInt(total)
        for (i in fortuneWeights.indices) {
            if (r < fortuneWeights[i]) return i
            r -= fortuneWeights[i]
        }
        return 1
    }

    fun fortuneToday(p: SharedPreferences): Int {
        return if (p.getInt(Prefs.FORTUNE_DAY, 0) == dayKey()) p.getInt(Prefs.FORTUNE_IDX, -1) else -1
    }

    fun saveFortune(p: SharedPreferences, idx: Int) {
        p.edit().putInt(Prefs.FORTUNE_DAY, dayKey()).putInt(Prefs.FORTUNE_IDX, idx).apply()
    }

    fun reset(p: SharedPreferences) {
        p.edit()
            .putInt(Prefs.AFF, 0)
            .putFloat(Prefs.FULL, 60f)
            .putLong(Prefs.FULL_TS, System.currentTimeMillis())
            .apply()
    }
}
